"""License window: current tier, online check, and manual key entry."""

import tkinter as tk
from tkinter import messagebox, ttk
import webbrowser

import licensing


def open_license_dialog(app):
    """Open the upgrade / activation window. One window, reused if it is already open."""
    existing = getattr(app, "_license_dialog", None)
    if existing is not None:
        try:
            if existing.winfo_exists():
                existing.lift()
                existing.focus_force()
                entry = getattr(app, "_license_dialog_entry", None)
                if entry is not None:
                    entry.focus_set()
                return existing
        except tk.TclError:
            pass

    parent = app.root
    settings = getattr(app, "_settings_win", None)
    if settings is not None:
        try:
            if settings.winfo_exists():
                parent = settings
        except tk.TclError:
            parent = app.root

    win = tk.Toplevel(parent)
    win.title("ReadySetPDF License")
    win.geometry("480x490")
    win.configure(bg=app.color_white)
    win.transient(parent)
    win.grab_set()
    app._license_dialog = win

    status_var = tk.StringVar()
    sentence_var = tk.StringVar()
    key_var = tk.StringVar()
    feedback_var = tk.StringVar()

    def _refresh_copy():
        state = app.license_state
        status_var.set(licensing.status_line(state))
        sentence_var.set(licensing.status_sentence(state))

    def _apply_state():
        app.license_state = licensing.load_state()
        if hasattr(app, "_refresh_account_panel"):
            app._refresh_account_panel()
        if hasattr(app, "_refresh_tool_lock_styles"):
            app._refresh_tool_lock_styles()
        _refresh_copy()

    def _close():
        app._license_dialog = None
        app._license_dialog_entry = None
        try:
            win.destroy()
        except tk.TclError:
            pass

    win.protocol("WM_DELETE_WINDOW", _close)

    frame = ttk.Frame(win, padding=16)
    frame.pack(fill="both", expand=True)
    tk.Label(
        frame, textvariable=status_var,
        bg=app.color_white, fg=app.color_navy, font=("Arial", 12, "bold"), anchor="w",
    ).pack(anchor="w")
    tk.Label(
        frame, textvariable=sentence_var,
        bg=app.color_white, fg=app.color_navy, font=("Arial", 9),
        anchor="w", justify="left", wraplength=410,
    ).pack(anchor="w", pady=(4, 10))
    tk.Label(
        frame,
        text="Paste a Lemon Squeezy key, or an offline key issued for this app.",
        bg=app.color_white, fg=app.color_steel, font=("Arial", 9),
        anchor="w", justify="left", wraplength=410,
    ).pack(anchor="w", pady=(0, 8))

    row = tk.Frame(frame, bg=app.color_white)
    row.pack(fill="x")
    tk.Label(row, text="License:", bg=app.color_white, fg=app.color_navy, width=8, anchor="w").pack(side="left")
    entry = tk.Entry(row, textvariable=key_var, bg=app.color_pale)
    entry.pack(side="left", fill="x", expand=True, padx=5)
    app._license_dialog_entry = entry

    feedback = tk.Label(
        frame, textvariable=feedback_var,
        bg=app.color_white, fg=app.color_navy, font=("Arial", 9),
        anchor="w", justify="left", wraplength=430,
    )

    def _show_feedback(ok, message):
        feedback_var.set(message or "")
        feedback.configure(fg="#9b2c2c" if not ok else app.color_navy)

    def _activate():
        ok, message = licensing.activate(key_var.get())
        _show_feedback(ok, message)
        if not ok:
            messagebox.showerror("License", message, parent=win)
            entry.focus_set()
            return
        key_var.set("")
        _apply_state()
        messagebox.showinfo("License", message, parent=win)

    def _check():
        ok, message = licensing.refresh_saved_license()
        _apply_state()
        _show_feedback(ok, message)
        if not ok:
            messagebox.showerror("License", message, parent=win)
            return
        if message:
            messagebox.showinfo("License", message, parent=win)

    def _buy_monthly():
        webbrowser.open(licensing.MONTHLY_CHECKOUT_URL)

    def _buy_yearly():
        webbrowser.open(licensing.YEARLY_CHECKOUT_URL)

    app._create_btn(row, "Activate", app.color_lime, app.color_navy, _activate).pack(side="left")
    feedback.pack(anchor="w", pady=(10, 0))
    app._create_btn(
        frame, "Check license online", app.color_steel, app.color_white, _check,
    ).pack(fill="x", pady=(12, 4))
    app._create_btn(
        frame, "Purchase Monthly", app.color_lime, app.color_navy, _buy_monthly,
    ).pack(fill="x", pady=(8, 2))
    app._create_btn(
        frame, "Purchase Yearly", app.color_lime, app.color_navy, _buy_yearly,
    ).pack(fill="x", pady=(2, 0))
    tk.Label(
        frame,
        text="Monthly is $59.99/mo. Yearly is $599.99/yr.",
        bg=app.color_white, fg=app.color_steel, font=("Arial", 8),
        anchor="w", justify="left", wraplength=430,
    ).pack(anchor="w", pady=(8, 0))

    _refresh_copy()
    win.after(50, entry.focus_set)
    return win
