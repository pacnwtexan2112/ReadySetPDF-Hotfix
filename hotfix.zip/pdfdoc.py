"""PDF documents for page placement, marks, and saving.

pikepdf owns the file. Drawing and page stamps use the same top-left,
y-down page space the 3.54 engine used. Page-box properties match that
space so imposition math does not move.
"""

import io
import math
import os
import struct
import zlib
import builtins

import pikepdf
from PIL import Image

from pdfgeom import Point, Rect
from pageboxes import _boxes_from_pike, _quad, _rotation

PDF_ENCRYPT_KEEP = 0
PDF_ENCRYPT_NONE = 1
PDF_ENCRYPT_RC4_40 = 2
PDF_ENCRYPT_RC4_128 = 3
PDF_ENCRYPT_AES_128 = 4
PDF_ENCRYPT_AES_256 = 5
PDF_ENCRYPT_UNKNOWN = 6

PDF_PERM_PRINT = 4
PDF_PERM_MODIFY = 8
PDF_PERM_COPY = 16
PDF_PERM_ANNOTATE = 32
PDF_PERM_FORM = 256
PDF_PERM_ACCESSIBILITY = 512
PDF_PERM_ASSEMBLE = 1024
PDF_PERM_PRINT_HQ = 2048


def open(*args, **kwargs):
    return Document(*args)


def _ttf_metrics(data):
    """WinAnsi advance widths and ascent ratio from a TrueType file."""
    def u16(off):
        return struct.unpack_from(">H", data, off)[0]

    def u32(off):
        return struct.unpack_from(">I", data, off)[0]

    def i16(off):
        return struct.unpack_from(">h", data, off)[0]

    num_tables = u16(4)
    tables = {}
    cursor = 12
    for _ in range(num_tables):
        tag = data[cursor:cursor + 4].decode("latin-1")
        tables[tag] = u32(cursor + 8)
        cursor += 16
    units = u16(tables["head"] + 18) or 1000
    ascent = i16(tables["hhea"] + 4)
    n_metrics = u16(tables["hhea"] + 34)
    hmtx = tables["hmtx"]
    advances = [u16(hmtx + index * 4) for index in range(n_metrics)]
    last = advances[-1] if advances else units // 2
    glyphs = _ttf_cmap(data, tables.get("cmap"), u16, u32, i16)
    scale = 1000.0 / float(units)
    widths = []
    for code in range(256):
        try:
            char = bytes([code]).decode("cp1252")
        except UnicodeDecodeError:
            char = " "
        gid = glyphs.get(ord(char), 0)
        advance = advances[gid] if gid < len(advances) else last
        widths.append(int(round(advance * scale)))
    return widths, float(ascent) / float(units)


def _ttf_cmap(data, cmap, u16, u32, i16):
    if cmap is None:
        return {}
    count = u16(cmap + 2)
    chosen = None
    for index in range(count):
        platform = u16(cmap + 4 + index * 8)
        encoding = u16(cmap + 6 + index * 8)
        offset = cmap + u32(cmap + 8 + index * 8)
        if platform == 3 and encoding in (1, 10):
            chosen = offset
            break
        if platform == 0 and chosen is None:
            chosen = offset
    if chosen is None:
        return {}
    fmt = u16(chosen)
    glyphs = {}
    if fmt == 4:
        seg_count = u16(chosen + 6) // 2
        end_at = chosen + 14
        start_at = end_at + 2 * seg_count + 2
        delta_at = start_at + 2 * seg_count
        range_at = delta_at + 2 * seg_count
        for seg in range(seg_count):
            end = u16(end_at + 2 * seg)
            start = u16(start_at + 2 * seg)
            delta = i16(delta_at + 2 * seg)
            range_off = u16(range_at + 2 * seg)
            if start == 0xFFFF:
                break
            for code in range(start, end + 1):
                if range_off == 0:
                    gid = (code + delta) & 0xFFFF
                else:
                    pos = range_at + 2 * seg + range_off + 2 * (code - start)
                    gid = u16(pos)
                    if gid:
                        gid = (gid + delta) & 0xFFFF
                glyphs[code] = gid
    elif fmt == 12:
        groups = u32(chosen + 12)
        pos = chosen + 16
        for _ in range(groups):
            start, end, glyph = u32(pos), u32(pos + 4), u32(pos + 8)
            pos += 12
            for code in range(start, min(end + 1, start + 20000)):
                glyphs[code] = glyph + (code - start)
    return glyphs


def _encode_width(text, face):
    widths = face["widths"] if face else None
    total = 0
    for char in str(text):
        try:
            byte = char.encode("cp1252")
        except UnicodeEncodeError:
            byte = b"?"
        if len(byte) != 1:
            byte = b"?"
        if widths:
            total += widths[byte[0]]
        else:
            total += 520 if char != " " else 280
    return total


def _text_width(text, fontsize, face):
    return _encode_width(text, face) * float(fontsize) / 1000.0


def _wrap_text(text, fontsize, max_width, face):
    lines = []
    for paragraph in str(text).split("\n"):
        words = paragraph.split(" ")
        current = ""
        for word in words:
            trial = word if not current else current + " " + word
            if current and _text_width(trial, fontsize, face) > max_width:
                lines.append(current)
                current = word
            else:
                current = trial
        lines.append(current)
    return lines or [""]


class Document:
    is_pdfdoc = True

    def __init__(self, *args):
        self._closed = False
        self._image_meta = {}
        self._form_seq = 0
        self._embedded_fonts = {}
        if not args or args[0] is None or args[0] == "":
            self._pdf = pikepdf.Pdf.new()
            return
        if args[0] == "pdf":
            self._pdf = pikepdf.open(io.BytesIO(args[1]))
            return
        src = args[0]
        if isinstance(src, (bytes, bytearray)):
            self._pdf = pikepdf.open(io.BytesIO(src))
        else:
            self._pdf = pikepdf.open(src)

    @property
    def page_count(self):
        return len(self._pdf.pages)

    def __len__(self):
        return self.page_count

    def __iter__(self):
        for index in range(self.page_count):
            yield Page(self, index)

    def __getitem__(self, index):
        count = self.page_count
        if index < 0:
            index += count
        if index < 0 or index >= count:
            raise IndexError(index)
        return Page(self, index)

    def new_page(self, width=595, height=842, pno=-1):
        # A blank page with no size is A4 (595 x 842). Booklet padding
        # calls that form, and the blank leaf's size shifts the other leaf.
        self._pdf.add_blank_page(page_size=(float(width), float(height)))
        return self[-1]

    def delete_page(self, index=-1):
        count = self.page_count
        if index < 0:
            index += count
        del self._pdf.pages[index]

    def insert_pdf(self, src, from_page=0, to_page=-1, start_at=-1, rotate=0, links=True, annots=True):
        if src is None or len(src) == 0:
            return
        start = 0 if from_page is None or from_page < 0 else int(from_page)
        end = len(src) - 1 if to_page is None or to_page < 0 else int(to_page)
        end = min(end, len(src) - 1)
        for index in range(start, end + 1):
            self._pdf.pages.append(src[index]._pike)

    def tobytes(self, garbage=0, deflate=False, clean=False, **kwargs):
        buf = io.BytesIO()
        self._pdf.save(buf, min_version="1.7")
        return buf.getvalue()

    def save(self, path, garbage=0, deflate=False, clean=False, deflate_images=False,
             deflate_fonts=False, encryption=0, owner_pw=None, user_pw=None, permissions=0, **kwargs):
        save_kwargs = {}
        if encryption in (PDF_ENCRYPT_AES_128, PDF_ENCRYPT_AES_256) or owner_pw not in (None, ""):
            # Permissions is immutable in this pikepdf build; pass the flags in.
            allow = pikepdf.Permissions(
                accessibility=bool(permissions & PDF_PERM_ACCESSIBILITY),
                extract=bool(permissions & PDF_PERM_COPY),
                modify_annotation=bool(permissions & PDF_PERM_ANNOTATE),
                modify_assembly=bool(permissions & PDF_PERM_ASSEMBLE),
                modify_form=bool(permissions & PDF_PERM_FORM),
                modify_other=bool(permissions & PDF_PERM_MODIFY),
                print_lowres=bool(permissions & PDF_PERM_PRINT),
                print_highres=bool(permissions & PDF_PERM_PRINT_HQ),
            )
            revision = 6 if encryption == PDF_ENCRYPT_AES_256 else 4
            save_kwargs["encryption"] = pikepdf.Encryption(
                owner=owner_pw or "",
                user=user_pw or "",
                R=revision,
                allow=allow,
                aes=True,
            )
        save_kwargs["min_version"] = "1.7"
        self._pdf.save(path, **save_kwargs)

    def close(self):
        if not self._closed:
            self._pdf.close()
            self._closed = True

    def embed_truetype(self, path):
        """Share one embedded TrueType face across every page that stamps it."""
        key = os.path.abspath(path)
        cached = self._embedded_fonts.get(key)
        if cached:
            return cached
        data = builtins.open(key, "rb").read()
        try:
            widths, ascent = _ttf_metrics(data)
        except Exception:
            widths, ascent = [500] * 256, 0.8
        self._font_seq = getattr(self, "_font_seq", 0) + 1
        face = "Fnt%d" % self._font_seq
        base = pikepdf.Name("/" + os.path.splitext(os.path.basename(key))[0])
        program = pikepdf.Stream(self._pdf, data)
        program.Length1 = len(data)
        descriptor = pikepdf.Dictionary(
            Type=pikepdf.Name.FontDescriptor,
            FontName=base,
            Flags=32,
            FontBBox=pikepdf.Array([-200, -300, 1400, 1100]),
            ItalicAngle=0,
            Ascent=int(round(ascent * 1000)),
            Descent=-200,
            CapHeight=700,
            StemV=80,
            FontFile2=program,
        )
        font = pikepdf.Dictionary(
            Type=pikepdf.Name.Font,
            Subtype=pikepdf.Name.TrueType,
            BaseFont=base,
            Encoding=pikepdf.Name.WinAnsiEncoding,
            FirstChar=0,
            LastChar=255,
            Widths=pikepdf.Array(widths),
            FontDescriptor=descriptor,
        )
        cached = {"name": face, "font": self._pdf.make_indirect(font), "widths": widths, "ascent": ascent}
        self._embedded_fonts[key] = cached
        return cached

    def extract_image(self, xref):
        meta = self._image_meta.get(int(xref))
        if not meta:
            raise KeyError(xref)
        return {"image": meta["image"], "width": meta["width"], "height": meta["height"]}


class Page:
    def __init__(self, doc, index):
        self.parent = doc
        self._index = int(index)

    @property
    def number(self):
        return self._index

    @property
    def _pike(self):
        return self.parent._pdf.pages[self._index]

    def _pike_page(self):
        return self._pike

    def _boxes(self):
        return _boxes_from_pike(self._pike)

    @property
    def rect(self):
        return self._boxes()["rect"] or Rect(0, 0, 1, 1)

    @property
    def mediabox(self):
        return self._boxes()["mediabox"] or Rect(self.rect)

    @property
    def cropbox(self):
        return self._boxes()["cropbox"] or Rect(self.mediabox)

    @property
    def trimbox(self):
        return self._boxes()["trimbox"] or Rect(self.cropbox)

    @property
    def bleedbox(self):
        return self._boxes()["bleedbox"] or Rect(self.cropbox)

    @property
    def artbox(self):
        return self._boxes()["artbox"] or Rect(self.cropbox)

    @property
    def rotation(self):
        return _rotation(self._pike)

    def _raw_media(self):
        return _quad(self._pike.mediabox)

    def _raw_crop(self):
        return _quad(self._pike.cropbox)

    def _write_box(self, name, rect, flip):
        x0, y0, x1, y1 = (float(v) for v in rect)
        if flip:
            _mx0, _my0, _mx1, my1 = self._raw_media()
            y0, y1 = my1 - y1, my1 - y0
        if x1 < x0:
            x0, x1 = x1, x0
        if y1 < y0:
            y0, y1 = y1, y0
        self._pike.obj[pikepdf.Name(name)] = pikepdf.Array([x0, y0, x1, y1])

    def set_mediabox(self, rect):
        self._write_box("/MediaBox", rect, flip=False)

    def set_cropbox(self, rect):
        self._write_box("/CropBox", rect, flip=True)

    def set_trimbox(self, rect):
        self._write_box("/TrimBox", rect, flip=True)

    def set_bleedbox(self, rect):
        self._write_box("/BleedBox", rect, flip=True)

    def set_artbox(self, rect):
        self._write_box("/ArtBox", rect, flip=True)

    def _pdf_point(self, x, y):
        """Page-rect point (y down) to PDF user space (y up)."""
        cx0, cy0, cx1, cy1 = self._raw_crop()
        if self.rotation in (90, 270):
            # Displayed x runs along the unrotated Y axis.
            return cx0 + y, cy0 + x
        return cx0 + x, cy1 - y

    def _page_vector_to_pdf(self, vx, vy):
        """Same axis map as _pdf_point, for a direction rather than a point."""
        if self.rotation in (90, 270):
            return vy, vx
        return vx, -vy

    def _pdf_rect(self, rect):
        rect = Rect(rect)
        corners = (
            self._pdf_point(rect.x0, rect.y0),
            self._pdf_point(rect.x1, rect.y1),
        )
        xs = [p[0] for p in corners]
        ys = [p[1] for p in corners]
        return min(xs), min(ys), max(xs), max(ys)

    def _append(self, text):
        data = text.encode("latin-1", "replace")
        stream = pikepdf.Stream(self.parent._pdf, data)
        contents = self._pike.obj.get("/Contents")
        if contents is None:
            self._pike.obj.Contents = stream
        elif isinstance(contents, pikepdf.Array):
            contents.append(stream)
        else:
            self._pike.obj.Contents = pikepdf.Array([contents, stream])

    def _color(self, color):
        if not color:
            return "0 0 0"
        if len(color) >= 3:
            return f"{float(color[0]):.4f} {float(color[1]):.4f} {float(color[2]):.4f}"
        value = float(color[0])
        return f"{value:.4f} {value:.4f} {value:.4f}"

    def _dash(self, dashes):
        if not dashes:
            return ""
        body = str(dashes).strip()
        if body.startswith("["):
            return f"{body} 0 d\n"
        return ""

    def draw_line(self, p1, p2, color=(0, 0, 0), width=1, dashes=None):
        x1, y1 = self._pdf_point(p1.x, p1.y)
        x2, y2 = self._pdf_point(p2.x, p2.y)
        self._append(
            "q\n"
            f"{self._color(color)} RG\n"
            f"{float(width):.4f} w\n"
            f"{self._dash(dashes)}"
            f"{x1:.3f} {y1:.3f} m\n"
            f"{x2:.3f} {y2:.3f} l\n"
            "S\nQ\n"
        )

    def draw_rect(self, rect, color=None, fill=None, width=1, dashes=None):
        x0, y0, x1, y1 = self._pdf_rect(rect)
        ops = ["q"]
        if fill is not None:
            ops.append(f"{self._color(fill)} rg")
        if color is not None:
            ops.append(f"{self._color(color)} RG")
            ops.append(f"{float(width):.4f} w")
            ops.append(self._dash(dashes).strip())
        ops.append(f"{x0:.3f} {y0:.3f} {x1 - x0:.3f} {y1 - y0:.3f} re")
        if fill is not None and color is not None:
            ops.append("B")
        elif fill is not None:
            ops.append("f")
        else:
            ops.append("S")
        ops.append("Q\n")
        self._append("\n".join(part for part in ops if part) + "\n")

    def draw_circle(self, center, radius, color=(0, 0, 0), width=1, fill=None):
        cx, cy = self._pdf_point(center.x, center.y)
        radius = float(radius)
        k = 0.551784
        r = radius
        ops = [
            "q",
            f"{self._color(color)} RG",
            f"{float(width):.4f} w",
        ]
        if fill is not None:
            ops.append(f"{self._color(fill)} rg")
        ops.append(f"{cx + r:.3f} {cy:.3f} m")
        curves = (
            (cx + r, cy + k * r, cx + k * r, cy + r, cx, cy + r),
            (cx - k * r, cy + r, cx - r, cy + k * r, cx - r, cy),
            (cx - r, cy - k * r, cx - k * r, cy - r, cx, cy - r),
            (cx + k * r, cy - r, cx + r, cy - k * r, cx + r, cy),
        )
        for c1x, c1y, c2x, c2y, x, y in curves:
            ops.append(f"{c1x:.3f} {c1y:.3f} {c2x:.3f} {c2y:.3f} {x:.3f} {y:.3f} c")
        ops.append("B" if fill is not None else "S")
        ops.append("Q\n")
        self._append("\n".join(ops))

    def _ensure_font(self, face=None):
        resources = self._pike.obj.get("/Resources")
        if resources is None:
            resources = pikepdf.Dictionary()
            self._pike.obj.Resources = resources
        fonts = resources.get("/Font")
        if fonts is None:
            fonts = pikepdf.Dictionary()
            resources.Font = fonts
        if face is None:
            if "/Helv" not in fonts:
                fonts["/Helv"] = pikepdf.Dictionary(
                    Type=pikepdf.Name.Font,
                    Subtype=pikepdf.Name.Type1,
                    BaseFont=pikepdf.Name.Helvetica,
                )
            return "Helv"
        fonts[pikepdf.Name("/" + face["name"])] = face["font"]
        return face["name"]

    def _opacity_prefix(self, opacity):
        try:
            opacity = float(opacity)
        except (TypeError, ValueError):
            return ""
        if opacity >= 0.999:
            return ""
        resources = self._pike.obj.get("/Resources")
        if resources is None:
            resources = pikepdf.Dictionary()
            self._pike.obj.Resources = resources
        states = resources.get("/ExtGState")
        if states is None:
            states = pikepdf.Dictionary()
            resources.ExtGState = states
        states["/RSPA"] = pikepdf.Dictionary(
            Type=pikepdf.Name.ExtGState,
            ca=opacity,
            CA=opacity,
        )
        return "/RSPA gs\n"

    def _text_matrix(self, point, rotate):
        """Clockwise degrees in page space (y down). 0 stays left to right."""
        x, y = self._pdf_point(point.x, point.y)
        try:
            angle = float(rotate or 0) % 360.0
        except (TypeError, ValueError):
            angle = 0.0
        if angle < 0.01 or angle > 359.99:
            return f"1 0 0 1 {x:.3f} {y:.3f}"
        rad = math.radians(angle)
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)
        # Writing runs clockwise; glyph up stays perpendicular in page space.
        base_x, base_y = self._page_vector_to_pdf(cos_a, sin_a)
        up_x, up_y = self._page_vector_to_pdf(sin_a, -cos_a)

        def _unit(value):
            if abs(value) < 1e-9:
                return 0.0
            if abs(abs(value) - 1.0) < 1e-9:
                return 1.0 if value > 0 else -1.0
            return value

        a, b = _unit(base_x), _unit(base_y)
        c, d = _unit(up_x), _unit(up_y)
        return f"{a:.6f} {b:.6f} {c:.6f} {d:.6f} {x:.3f} {y:.3f}"

    def insert_text(self, point, text, fontsize=11, fontname="helv", color=(0, 0, 0), overlay=True, fill_opacity=1, face=None, rotate=0):
        if face:
            name = self._ensure_font(face)
        else:
            name = self._ensure_font()
        safe = str(text).replace("\\", "\\\\").replace("(", "\\(").replace(")", "\\)")
        self._append(
            "q\n"
            f"{self._opacity_prefix(fill_opacity)}"
            "BT\n"
            "0 Tr\n"
            f"/{name} {float(fontsize):.2f} Tf\n"
            f"{self._color(color)} rg\n"
            f"{self._text_matrix(point, rotate)} Tm\n"
            f"({safe}) Tj\n"
            "ET\nQ\n"
        )
        return 0

    def insert_textbox(self, rect, text, fontsize=12, fontfile=None, fontname="helv", color=(0, 0, 0), align=0, underline=False, autoscale=False, scale_low=0.12, overlay=True, rotate=0):
        """Draw wrapped text in a page-space rectangle. A TrueType file is embedded when given."""
        rect = Rect(rect)
        text = str(text or "").replace("\r\n", "\n").replace("\r", "\n")
        if not text.strip() or rect.width < 1 or rect.height < 1:
            return 0
        try:
            angle = float(rotate or 0) % 360.0
        except (TypeError, ValueError):
            angle = 0.0
        turned = abs((angle - 90.0) % 180.0) < 0.5
        layout_w = rect.height if turned else rect.width
        layout_h = rect.width if turned else rect.height
        face = None
        if fontfile and os.path.isfile(fontfile):
            try:
                face = self.parent.embed_truetype(fontfile)
            except Exception:
                face = None
        size = max(1.0, float(fontsize or 12))
        floor = max(1.0, size * float(scale_low or 0.12)) if autoscale else size
        while True:
            lines = _wrap_text(text, size, layout_w, face)
            ascent = size * (face["ascent"] if face else 0.8)
            line_h = size * 1.15
            block_h = ascent + max(0, len(lines) - 1) * line_h
            if not autoscale or block_h <= layout_h + 0.4 or size <= floor + 0.05:
                break
            size = max(floor, size * 0.92)
        center_x = rect.x0 + rect.width / 2.0
        center_y = rect.y0 + rect.height / 2.0
        local_cx = layout_w / 2.0
        local_cy = layout_h / 2.0
        rad = math.radians(angle)
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)

        def _map(local_x, local_y):
            dx = local_x - local_cx
            dy = local_y - local_cy
            rx = dx * cos_a - dy * sin_a
            ry = dx * sin_a + dy * cos_a
            return center_x + rx, center_y + ry

        y = ascent
        for line in lines:
            if y - ascent > layout_h + 0.5:
                break
            width = _text_width(line, size, face)
            if int(align) == 1:
                x = max(0.0, (layout_w - width) / 2.0)
            elif int(align) == 2:
                x = max(0.0, layout_w - width)
            else:
                x = 0.0
            px, py = _map(x, y)
            self.insert_text(Point(px, py), line, fontsize=size, color=color, face=face, rotate=angle)
            if underline and line.strip():
                underline_y = y + max(0.6, size * 0.08)
                ux0, uy0 = _map(x, underline_y)
                ux1, uy1 = _map(x + width, underline_y)
                self.draw_line(
                    Point(ux0, uy0), Point(ux1, uy1),
                    color=color, width=max(0.4, size * 0.04),
                )
            y += line_h
        return 0

    def _content_bytes(self, pike):
        contents = pike.obj.get("/Contents")
        if contents is None:
            return b""
        if isinstance(contents, pikepdf.Array):
            return b"\n".join(item.read_bytes() for item in contents)
        return contents.read_bytes()

    def show_pdf_page(self, dest_rect, src_doc, src_index, keep_proportion=True, rotate=0, clip=None, overlay=True):
        src = src_doc[int(src_index)]
        src_rect = Rect(src.rect)
        if clip is None:
            clip = src_rect
        else:
            clip = Rect(clip) & src_rect
        if clip.is_empty or clip.width < 0.5 or clip.height < 0.5:
            clip = src_rect
        dest = Rect(dest_rect)
        rotate = int(rotate or 0) % 360
        fit_w, fit_h = clip.width, clip.height
        if rotate in (90, 270):
            fit_w, fit_h = fit_h, fit_w
        if keep_proportion and fit_w > 0.5 and fit_h > 0.5 and dest.width > 0.5 and dest.height > 0.5:
            scale = min(dest.width / fit_w, dest.height / fit_h)
            fitted_w = fit_w * scale
            fitted_h = fit_h * scale
            dest = Rect(
                dest.x0 + (dest.width - fitted_w) / 2.0,
                dest.y0 + (dest.height - fitted_h) / 2.0,
                dest.x0 + (dest.width - fitted_w) / 2.0 + fitted_w,
                dest.y0 + (dest.height - fitted_h) / 2.0 + fitted_h,
            )

        bx0, by0, bx1, by1 = src._pdf_rect(clip)
        dx0, dy0, dx1, dy1 = self._pdf_rect(dest)
        bw = max(bx1 - bx0, 0.01)
        bh = max(by1 - by0, 0.01)
        dw = dx1 - dx0
        dh = dy1 - dy0
        if rotate == 90:
            # Page point (x, y) lands at (y, width - x).
            a, b, c, d = 0.0, dh / bw, -dw / bh, 0.0
            e = dx0 - c * (by0 + bh)
            f = dy0 - b * bx0
        elif rotate == 270:
            a, b, c, d = 0.0, -dh / bw, dw / bh, 0.0
            e = dx0 - c * by0
            f = dy1 - b * bx0
        elif rotate == 180:
            a, b, c, d = -dw / bw, 0.0, 0.0, -dh / bh
            e = dx1 - a * bx0
            f = dy0 - d * by1
        else:
            a, b, c, d = dw / bw, 0.0, 0.0, dh / bh
            e = dx0 - a * bx0
            f = dy0 - d * by0

        raw = self._content_bytes(src._pike)
        wrapped = (
            f"q\n{bx0:.3f} {by0:.3f} {bw:.3f} {bh:.3f} re\nW\nn\n".encode("ascii")
            + raw
            + b"\nQ\n"
        )
        form = pikepdf.Stream(self.parent._pdf, wrapped)
        form.Type = pikepdf.Name.XObject
        form.Subtype = pikepdf.Name.Form
        form.BBox = pikepdf.Array([bx0, by0, bx1, by1])
        resources = src._pike.obj.get("/Resources")
        if resources is not None:
            if not getattr(resources, "is_indirect", False):
                resources = src.parent._pdf.make_indirect(resources)
            form.Resources = self.parent._pdf.copy_foreign(resources)
        form.FormType = 1

        self.parent._form_seq += 1
        name = f"Fm{self.parent._form_seq}"
        dest_resources = self._pike.obj.get("/Resources")
        if dest_resources is None:
            dest_resources = pikepdf.Dictionary()
            self._pike.obj.Resources = dest_resources
        xobjects = dest_resources.get("/XObject")
        if xobjects is None:
            xobjects = pikepdf.Dictionary()
            dest_resources.XObject = xobjects
        xobjects[pikepdf.Name("/" + name)] = form
        self._append(
            "q\n"
            f"{a:.6f} {b:.6f} {c:.6f} {d:.6f} {e:.3f} {f:.3f} cm\n"
            f"/{name} Do\n"
            "Q\n"
        )
        self._copy_pieceinfo_if_full_page(src, clip, dest)

    def _copy_pieceinfo_if_full_page(self, src, clip, dest):
        """Keep Illustrator / RIP private image data on a 1:1 page rebuild.

        A placement onto a larger sheet does not copy it, so an imposed layout
        does not duplicate the private payload into every cell.
        """
        try:
            piece = src._pike.obj.get("/PieceInfo")
        except Exception:
            return
        if piece is None or self._pike.obj.get("/PieceInfo") is not None:
            return
        src_rect = Rect(src.rect)
        if abs(clip.width - src_rect.width) > 1.5 or abs(clip.height - src_rect.height) > 1.5:
            return
        if abs(self.rect.width - dest.width) > 1.5 or abs(self.rect.height - dest.height) > 1.5:
            return
        if abs(dest.width - clip.width) > 1.5 or abs(dest.height - clip.height) > 1.5:
            return
        try:
            if not getattr(piece, "is_indirect", False):
                piece = src.parent._pdf.make_indirect(piece)
            self._pike.obj.PieceInfo = self.parent._pdf.copy_foreign(piece)
        except Exception:
            return

    def insert_image(self, rect, filename=None, stream=None, pil=None, **kwargs):
        own = pil is None
        image = pil if pil is not None else Image.open(filename if filename else io.BytesIO(stream))
        try:
            if image.mode == "CMYK":
                self._place_sampled_image(rect, image)
            elif image.mode in ("RGBA", "LA") or (image.mode == "P" and "transparency" in image.info):
                self._place_sampled_image(rect, image.convert("RGBA"))
            else:
                if image.mode not in ("RGB", "L"):
                    image = image.convert("RGB")
                self._place_jpeg_image(rect, image)
        finally:
            if own:
                image.close()

    def _image_resources(self):
        resources = self._pike.obj.get("/Resources")
        if resources is None:
            resources = pikepdf.Dictionary()
            self._pike.obj.Resources = resources
        xobjects = resources.get("/XObject")
        if xobjects is None:
            xobjects = pikepdf.Dictionary()
            resources.XObject = xobjects
        self.parent._form_seq += 1
        name = f"Im{self.parent._form_seq}"
        return xobjects, name

    def _paint_image(self, rect, name, width, height, colorspace, payload):
        x0, y0, x1, y1 = self._pdf_rect(rect)
        self._append(
            "q\n"
            f"{x1 - x0:.3f} 0 0 {y1 - y0:.3f} {x0:.3f} {y0:.3f} cm\n"
            f"/{name} Do\nQ\n"
        )
        try:
            xref = int(self._pike.obj.Resources.XObject[pikepdf.Name("/" + name)].objgen[0])
        except Exception:
            xref = 1000 + self.parent._form_seq
        self.parent._image_meta[xref] = {
            "image": payload,
            "width": width,
            "height": height,
            "bbox": Rect(rect),
            "colorspace": colorspace,
            "page": self._index,
        }

    def _place_jpeg_image(self, rect, image):
        buf = io.BytesIO()
        image.save(buf, format="JPEG", quality=90)
        payload = buf.getvalue()
        width, height = image.size
        mode = image.mode
        xobjects, name = self._image_resources()
        xobj = pikepdf.Stream(self.parent._pdf, payload)
        xobj.Type = pikepdf.Name.XObject
        xobj.Subtype = pikepdf.Name.Image
        xobj.Width = width
        xobj.Height = height
        xobj.ColorSpace = pikepdf.Name.DeviceGray if mode == "L" else pikepdf.Name.DeviceRGB
        xobj.BitsPerComponent = 8
        xobj.Filter = pikepdf.Name.DCTDecode
        xobjects[pikepdf.Name("/" + name)] = xobj
        self._paint_image(rect, name, width, height, 1 if mode == "L" else 3, payload)

    def _place_sampled_image(self, rect, image):
        width, height = image.size
        xobjects, name = self._image_resources()
        if image.mode == "CMYK":
            raw = image.tobytes()
            colorspace = pikepdf.Name.DeviceCMYK
            channels = 4
            smask = None
        else:
            rgba = image.convert("RGBA")
            red, green, blue, alpha = rgba.split()
            raw = Image.merge("RGB", (red, green, blue)).tobytes()
            colorspace = pikepdf.Name.DeviceRGB
            channels = 3
            smask = pikepdf.Stream(self.parent._pdf, zlib.compress(alpha.tobytes()))
            smask.Type = pikepdf.Name.XObject
            smask.Subtype = pikepdf.Name.Image
            smask.Width = width
            smask.Height = height
            smask.ColorSpace = pikepdf.Name.DeviceGray
            smask.BitsPerComponent = 8
            smask.Filter = pikepdf.Name.FlateDecode
        xobj = pikepdf.Stream(self.parent._pdf, zlib.compress(raw))
        xobj.Type = pikepdf.Name.XObject
        xobj.Subtype = pikepdf.Name.Image
        xobj.Width = width
        xobj.Height = height
        xobj.ColorSpace = colorspace
        xobj.BitsPerComponent = 8
        xobj.Filter = pikepdf.Name.FlateDecode
        if smask is not None:
            xobj.SMask = smask
        xobjects[pikepdf.Name("/" + name)] = xobj
        self._paint_image(rect, name, width, height, channels, raw)

    def get_image_info(self, xrefs=False):
        from modules.preflight.inspect import page_image_placements
        infos = []
        for item in page_image_placements(self):
            infos.append({
                "width": item["width"],
                "height": item["height"],
                "bbox": Rect(item["bbox"]),
                "xref": item["xref"],
                "colorspace": item["colorspace"],
            })
        return infos

    def get_image_rects(self, xref):
        rects = []
        for item in self.get_image_info():
            if int(item.get("xref") or 0) == int(xref):
                rects.append(Rect(item["bbox"]))
        return rects or [Rect(self.rect)]

    def get_fonts(self):
        from modules.preflight.inspect import page_font_names
        return [(0, "n/a", "Type1", name, name, "") for name in page_font_names(self)]

    def get_xobjects(self):
        return []

    def flatten_annotations(self):
        return None

    def clean_contents(self):
        return None
