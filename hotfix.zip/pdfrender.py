"""Rasterize PDF pages for the Tk preview with pypdfium2.

Scale matches the previous pixmap path: a factor of ``s`` maps one
PDF point to ``s`` pixels (72 * s DPI). Document construction still uses the
existing engine; only the preview bitmap is produced here.
"""

import pypdfium2 as pdfium
from PIL import Image


def render_page_image(doc, page_index, scale, annots=True):
    """Return an RGB PIL image of ``doc[page_index]`` at ``scale``.

    ``doc`` must be able to serialize itself with ``tobytes()`` (the current
    preview documents do). Pixel size follows the page's visible rectangle so
    zoom, rulers, and VDP field boxes stay aligned with the canvas.
    """
    scale = float(scale)
    if scale <= 0:
        scale = 0.05
    page_index = int(page_index)
    src_page = doc[page_index]
    target_w = max(1, int(round(float(src_page.rect.width) * scale)))
    target_h = max(1, int(round(float(src_page.rect.height) * scale)))

    data = doc.tobytes(garbage=0, deflate=False, clean=False)
    pdf = pdfium.PdfDocument(data)
    bitmap = None
    try:
        page = pdf[page_index]
        bitmap = page.render(
            scale=scale,
            rev_byteorder=True,
            draw_annots=bool(annots),
            fill_color=(255, 255, 255, 255),
        )
        image = bitmap.to_pil()
        if image.mode != "RGB":
            image = image.convert("RGB")
        if image.size != (target_w, target_h):
            image = image.resize((target_w, target_h), Image.Resampling.LANCZOS)
        return image
    finally:
        if bitmap is not None:
            bitmap.close()
        pdf.close()
