"""Rectangles and points using the same fields the imposition code already uses."""


class Rect:
    def __init__(self, *args):
        if len(args) == 1:
            value = args[0]
            if isinstance(value, Rect):
                coords = (value.x0, value.y0, value.x1, value.y1)
            else:
                coords = tuple(value)
        elif len(args) == 4:
            coords = args
        else:
            raise ValueError("Rect needs four numbers or one rectangle")
        x0, y0, x1, y1 = (float(v) for v in coords[:4])
        if x1 < x0:
            x0, x1 = x1, x0
        if y1 < y0:
            y0, y1 = y1, y0
        self.x0 = x0
        self.y0 = y0
        self.x1 = x1
        self.y1 = y1

    @property
    def width(self):
        return self.x1 - self.x0

    @property
    def height(self):
        return self.y1 - self.y0

    @property
    def is_empty(self):
        return self.width <= 0 or self.height <= 0

    def intersects(self, other):
        return not (self & other).is_empty

    def __and__(self, other):
        other = other if isinstance(other, Rect) else Rect(other)
        ax0, ax1 = min(self.x0, self.x1), max(self.x0, self.x1)
        ay0, ay1 = min(self.y0, self.y1), max(self.y0, self.y1)
        bx0, bx1 = min(other.x0, other.x1), max(other.x0, other.x1)
        by0, by1 = min(other.y0, other.y1), max(other.y0, other.y1)
        rect = Rect.__new__(Rect)
        rect.x0 = max(ax0, bx0)
        rect.y0 = max(ay0, by0)
        rect.x1 = min(ax1, bx1)
        rect.y1 = min(ay1, by1)
        return rect

    def __iter__(self):
        yield self.x0
        yield self.y0
        yield self.x1
        yield self.y1

    def __repr__(self):
        return f"Rect({self.x0}, {self.y0}, {self.x1}, {self.y1})"


class Point:
    def __init__(self, x, y=None):
        if y is None:
            x, y = x
        self.x = float(x)
        self.y = float(y)

    def __iter__(self):
        yield self.x
        yield self.y

    def __repr__(self):
        return f"Point({self.x}, {self.y})"
