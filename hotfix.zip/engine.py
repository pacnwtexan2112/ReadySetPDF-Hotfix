"""ReadySetPDF processing engine: pipeline, OCR, Ghostscript, and save helpers."""

import os
import sys
import csv
import io
import html
import datetime
import zipfile
import xml.etree.ElementTree as ET
import subprocess
import tempfile
import glob

import pdfdoc
import pikepdf
from PIL import Image
from tkinter import filedialog, messagebox

IMAGE_EXTS = ("png", "jpg", "jpeg", "tif", "tiff")


from modules.vdp import (
    ADDRESS_BLOCK_FIELD_COUNT,
    apply_proof_stamp,
    apply_vdp_merge,
    build_address_block_spec,
    format_address_block,
    guess_address_columns,
    load_merge_rows,
    mapped_merge_columns,
    normalize_address_map,
    read_spreadsheet,
    row_has_merge_data,
    style_on,
    field_rotation,
    _field_template_page,
)

from modules.core.pageops import show_source_page
from modules.color import convert_colorspace, find_ghostscript
from modules.ocr import (
    extract_ocr_table,
    extract_ocr_text,
    find_tesseract,
    run_ocr_extraction,
    save_ocr_export,
)
from modules.impose import (
    ANCHOR_POINTS,
    FOLD_NEST_PT,
    FOLD_TYPES,
    anchored_origin,
    booklet_creep_shift,
    build_fold_proof_doc,
    build_impose_sheets,
    compute_fold_layout,
    crop_mark_inset,
    draw_fold_dielines,
    draw_perimeter_crop_marks,
    duplex_cell,
    duplex_flip_axes,
    fitted_dest_rect,
    map_src_rect_to_dest,
    mirror_anchor,
    normalize_anchor,
    nup_dest_on_slot,
    place_booklet_leaf,
    placed_trim_rect,
    resolve_source_trim_rect,
    source_layout_size,
)

def copy_clipped_page(dest_doc, src_doc, src_index, clip=None):
    """Copy one page's visible rectangle onto a page that is only that rectangle.

    The placed form is clipped to the kept region, then the new page's boxes
    are that region. Margins outside the clip are not on the new page.
    """
    src_page = src_doc[src_index]
    src_rect = pdfdoc.Rect(src_page.rect)
    keep = pdfdoc.Rect(src_rect if clip is None else clip) & src_rect
    if keep.is_empty or keep.width < 1.0 or keep.height < 1.0:
        keep = src_rect
    page = dest_doc.new_page(width=max(keep.width, 1.0), height=max(keep.height, 1.0))
    show_source_page(page, page.rect, src_doc, src_index, keep_proportion=False, clip=keep)
    box = (0.0, 0.0, float(page.rect.width), float(page.rect.height))
    for name in ("set_cropbox", "set_mediabox", "set_bleedbox", "set_trimbox", "set_artbox"):
        try:
            getattr(page, name)(box)
        except Exception:
            pass


def flatten_hidden_page_content(doc):
    """Rebuild any page whose Form XObjects are larger than the page box.

    Acrobat Save expands those XObjects and brings back clipped crop marks.
    """
    if doc is None or doc.page_count == 0:
        return doc
    dirty = False
    for page in doc:
        for xo in page.get_xobjects() or []:
            if len(xo) < 4:
                continue
            try:
                bbox = pdfdoc.Rect(xo[3])
            except Exception:
                continue
            if bbox.width > page.rect.width + 2 or bbox.height > page.rect.height + 2:
                dirty = True
                break
        if dirty:
            break
    if not dirty:
        return doc
    out = pdfdoc.open()
    try:
        for i in range(doc.page_count):
            copy_clipped_page(out, doc, i, doc[i].rect)
        doc.close()
        return out
    except Exception:
        out.close()
        return doc


def mark_rgb(value):
    """Printer's mark stroke. Default black so old recipes stay unchanged."""
    key = str(value or "black").strip().lower()
    if key in ("white", "1", "#fff", "#ffffff", "w"):
        return (1, 1, 1)
    if key in ("grey", "gray", "0.5", "#808080", "#888", "#888888"):
        return (0.55, 0.55, 0.55)
    return (0, 0, 0)



STANDARD_PAPER_PTS = (
    (612.0, 792.0),       # Letter
    (792.0, 612.0),
    (612.0, 1008.0),      # Legal
    (1008.0, 612.0),
    (792.0, 1224.0),      # Tabloid 11x17
    (1224.0, 792.0),
    (864.0, 1296.0),      # 12x18
    (1296.0, 864.0),
    (1224.0, 1584.0),     # 17x22
    (1584.0, 1224.0),
    (595.276, 841.89),    # A4
    (841.89, 595.276),
    (1190.55, 841.89),    # A3
    (841.89, 1190.55),
    (459.213, 649.134),   # A5
    (649.134, 459.213),
)
PREFERRED_SCAN_DPI = (300.0, 600.0, 400.0, 200.0, 1200.0, 150.0)


def _dpi_pair(value, fallback=72.0):
    try:
        if isinstance(value, (tuple, list)) and len(value) >= 2:
            x, y = float(value[0] or 0), float(value[1] or 0)
        else:
            x = y = float(value or 0)
    except (TypeError, ValueError):
        return fallback, fallback
    if x < 2:
        x = fallback
    if y < 2:
        y = fallback
    return x, y


def image_file_page_size_pts(path, max_dpi=None):
    with Image.open(path) as img:
        px_w, px_h = img.size
        dpi_x, dpi_y = _dpi_pair(img.info.get("dpi"), 72.0)
        unit = img.info.get("jfif_unit")
        density = img.info.get("jfif_density")
        if unit == 1 and density:
            dpi_x, dpi_y = _dpi_pair(density, dpi_x)
        elif unit == 2 and density:
            dx, dy = _dpi_pair(density, 0)
            if dx >= 2 and dy >= 2:
                dpi_x, dpi_y = dx * 2.54, dy * 2.54
        w_pt = px_w * 72.0 / dpi_x
        h_pt = px_h * 72.0 / dpi_y
        if (w_pt / 72.0 > 20 or h_pt / 72.0 > 20) and max(dpi_x, dpi_y) < 96:
            if not max_dpi:
                return w_pt, h_pt
            snapped = paper_size_from_pixels(px_w, px_h, prefer_dpi=max_dpi)
            if snapped:
                return snapped
            return px_w * 72.0 / float(max_dpi), px_h * 72.0 / float(max_dpi)
        return w_pt, h_pt


def parse_max_dpi(value):
    """None means Original: do not resample and do not invent a DPI."""
    text = str(value or "").strip().lower()
    if text in ("", "original", "none", "off", "rip", "native"):
        return None
    try:
        dpi = float(text)
    except (TypeError, ValueError):
        return None
    if dpi < 72:
        return None
    return dpi


def paper_size_from_pixels(px_w, px_h, prefer_dpi=None):
    if not px_w or not px_h:
        return None
    prefs = (float(prefer_dpi),) if prefer_dpi else PREFERRED_SCAN_DPI
    best = None
    best_score = 0.28
    for sw, sh in STANDARD_PAPER_PTS:
        dpi_x = px_w / (sw / 72.0)
        dpi_y = px_h / (sh / 72.0)
        if dpi_x < 80 or dpi_y < 80:
            continue
        if abs(dpi_x / dpi_y - 1.0) > 0.08:
            continue
        for pref in prefs:
            err = abs(dpi_x - pref) / pref + abs(dpi_y - pref) / pref
            if err < best_score:
                best_score = err
                best = (sw, sh)
    return best


def _image_dpi_from_xref(doc, xref):
    try:
        meta = doc.extract_image(xref)
        img = Image.open(io.BytesIO(meta["image"]))
        dpi_x, dpi_y = _dpi_pair(img.info.get("dpi"), 0)
        unit = img.info.get("jfif_unit")
        density = img.info.get("jfif_density")
        if unit == 1 and density:
            dpi_x, dpi_y = _dpi_pair(density, dpi_x)
        elif unit == 2 and density:
            dx, dy = _dpi_pair(density, 0)
            if dx >= 2 and dy >= 2:
                dpi_x, dpi_y = dx * 2.54, dy * 2.54
        img.close()
        if dpi_x >= 96 and dpi_y >= 96:
            return dpi_x, dpi_y
    except Exception:
        pass
    return None, None


def infer_true_page_size_pts(page, max_dpi=None):
    """Return the print page size in PDF points, not raster pixels at 72 DPI.

    max_dpi None (Original) keeps the PDF page box. A number is used only when
    the page box is really a pixel count and the image has no usable DPI tag.
    """
    rect = page.rect
    w, h = float(rect.width), float(rect.height)
    infos = []
    try:
        infos = page.get_image_info() or []
    except Exception:
        infos = []
    if not infos:
        return w, h

    info = max(infos, key=lambda item: int(item.get("width") or 0) * int(item.get("height") or 0))
    px_w = int(info.get("width") or 0)
    px_h = int(info.get("height") or 0)
    if px_w < 32 or px_h < 32:
        return w, h

    bbox = info.get("bbox")
    if bbox is not None:
        try:
            box = pdfdoc.Rect(bbox)
            coverage = (box.width * box.height) / max(w * h, 1.0)
            if coverage < 0.85:
                return w, h
        except Exception:
            pass

    implied_x = px_w / max(w / 72.0, 0.01)
    implied_y = px_h / max(h / 72.0, 0.01)
    stored_as_pixels = 50 <= implied_x <= 96 and 50 <= implied_y <= 96
    if not stored_as_pixels:
        return w, h

    dpi_x, dpi_y = _image_dpi_from_xref(page.parent, info.get("xref"))
    if dpi_x and dpi_y and dpi_x >= 140 and dpi_y >= 140:
        return px_w * 72.0 / dpi_x, px_h * 72.0 / dpi_y

    if not max_dpi:
        return w, h

    if w / 72.0 > 20 or h / 72.0 > 20:
        snapped = paper_size_from_pixels(px_w, px_h, prefer_dpi=max_dpi)
        if snapped:
            return snapped
        return px_w * 72.0 / float(max_dpi), px_h * 72.0 / float(max_dpi)

    return w, h


def correct_raster_page_sizes(doc, max_dpi=None):
    if doc is None or doc.page_count == 0:
        return
    sizes = [infer_true_page_size_pts(doc[i], max_dpi=max_dpi) for i in range(doc.page_count)]
    needs = False
    for i, (nw, nh) in enumerate(sizes):
        page = doc[i]
        if abs(page.rect.width - nw) > 1.0 or abs(page.rect.height - nh) > 1.0:
            needs = True
            break
    if not needs:
        return
    rebuilt = pdfdoc.open()
    try:
        for i, (nw, nh) in enumerate(sizes):
            new_p = rebuilt.new_page(width=max(nw, 1.0), height=max(nh, 1.0))
            show_source_page(new_p, new_p.rect, doc, i, keep_proportion=False)
        while doc.page_count:
            doc.delete_page(-1)
        doc.insert_pdf(rebuilt)
    finally:
        rebuilt.close()

class UnlockError(Exception):
    """A ReadySetPDF permission lock could not be cleared.

    This is not a search for an unknown open password. A PDF that will not
    open until a password is typed stays locked.
    """


def unlock_password_from_steps(steps):
    """Owner password stored on an Unlock PDF step, or None when the stack has none."""
    for step in steps or []:
        if step.get("type") != "Unlock PDF":
            continue
        params = step.get("params") or {}
        if "password" in params and params.get("password") is not None:
            return str(params.get("password"))
        return "readysetpdf"
    return None


def open_unlocked_document(path, owner_password):
    """Open a PDF for ReadySetPDF unlock.

    Returns (document, lock_cleared). Permission locks are rewritten only
    when owner_password is the owner password. An open password is refused.
    """
    try:
        probe = pikepdf.open(path)
    except pikepdf.PasswordError as exc:
        raise UnlockError(
            f"{os.path.basename(path)} will not open until a password is typed, so it stays locked."
        ) from exc
    encrypted = bool(probe.is_encrypted)
    probe.close()
    if not encrypted:
        return pdfdoc.open(path), False
    try:
        owned = pikepdf.open(path, password="" if owner_password is None else str(owner_password))
    except pikepdf.PasswordError as exc:
        raise UnlockError(f"{os.path.basename(path)}: the master password was invalid.") from exc
    if not owned.owner_password_matched:
        owned.close()
        raise UnlockError(f"{os.path.basename(path)}: the master password was invalid.")
    clean = pikepdf.Pdf.new()
    clean.pages.extend(owned.pages)
    buffer = io.BytesIO()
    clean.save(buffer)
    owned.close()
    clean.close()
    return pdfdoc.open(buffer.getvalue()), True


def save_unlocked_copy(src_path, out_path, owner_password):
    """Write a copy with ReadySetPDF Print Lock and Edit Lock removed."""
    doc, cleared = open_unlocked_document(src_path, owner_password)
    try:
        doc.save(out_path, garbage=4, deflate=True, clean=True)
    finally:
        doc.close()
    return cleared


def insert_source_file(active_doc, path, max_dpi=None, owner_password=None):
    ext = path.lower().split(".")[-1]
    if ext in IMAGE_EXTS:
        w_pt, h_pt = image_file_page_size_pts(path, max_dpi=max_dpi)
        page = active_doc.new_page(width=max(w_pt, 1.0), height=max(h_pt, 1.0))
        page.insert_image(page.rect, filename=path)
    else:
        if owner_password is None:
            src = pdfdoc.open(path)
        else:
            src, _cleared = open_unlocked_document(path, owner_password)
        active_doc.insert_pdf(src)
        src.close()
    correct_raster_page_sizes(active_doc, max_dpi=max_dpi)


def _page_boxes_are_origin_aligned(page):
    """True when MediaBox and CropBox already share origin (0, 0) and size."""
    mb = pdfdoc.Rect(page.mediabox)
    cb = pdfdoc.Rect(page.cropbox)
    return (
        abs(mb.x0) <= 0.25 and abs(mb.y0) <= 0.25
        and abs(cb.x0) <= 0.25 and abs(cb.y0) <= 0.25
        and abs(mb.width - cb.width) <= 0.25
        and abs(mb.height - cb.height) <= 0.25
    )


def normalize_page_boxes(doc, flattening=False, max_dpi=None):
    """Make the visible crop the real page box without shifting artwork.

    Calling set_mediabox(cropbox) is unsafe when the crop sits at the page
    origin (0, 0) but MediaBox still has a PDF-space offset. That shift
    clips the top of files like imposed badges and leaves extra white at the
    bottom. Rebuild onto a clean page.rect instead.
    """
    if doc is None or doc.page_count == 0:
        return
    if flattening:
        for page in doc:
            try:
                page.flatten_annotations()
            except Exception:
                pass

    if not all(_page_boxes_are_origin_aligned(page) for page in doc):
        rebuilt = pdfdoc.open()
        try:
            for i, page in enumerate(doc):
                r = pdfdoc.Rect(page.rect)
                new_p = rebuilt.new_page(width=max(r.width, 1.0), height=max(r.height, 1.0))
                show_source_page(new_p, new_p.rect, doc, i, keep_proportion=False, clip=r)
            while doc.page_count:
                doc.delete_page(-1)
            doc.insert_pdf(rebuilt)
        finally:
            rebuilt.close()
    correct_raster_page_sizes(doc, max_dpi=max_dpi)


def _flatten_page_annotations(doc):
    if doc is None:
        return
    for page in doc:
        try:
            page.flatten_annotations()
        except Exception:
            pass


def prepare_imported_doc(doc, page_box_mode="keep", flattening=False, max_dpi=None):
    """Apply import Page Geometry, then the origin-safe box rebuild when needed.

    keep: existing normalize_page_boxes (Crop/Media origin alignment).
    crop_to_trim: CropBox = TrimBox, MediaBox unchanged — skip the rebuild
    so bleed in the media box is not thrown away.
    normalize_to_trim: physically clip to TrimBox (fallback CropBox/MediaBox).
    """
    from pageboxes import (
        normalize_page_box_mode,
        PAGE_BOX_CROP_TO_TRIM,
        PAGE_BOX_NORMALIZE_TO_TRIM,
        set_cropbox_to_trim,
        trim_in_page_space,
    )

    if doc is None or doc.page_count == 0:
        return doc
    mode = normalize_page_box_mode(page_box_mode)
    if mode == PAGE_BOX_CROP_TO_TRIM:
        set_cropbox_to_trim(doc)
        if flattening:
            _flatten_page_annotations(doc)
        return doc
    if mode == PAGE_BOX_NORMALIZE_TO_TRIM:
        # Rebuild onto a clean trim-sized page. copy_clipped_page redacts the
        # margin strips; a full-bleed fill that overlaps those strips is deleted
        # and the preview goes white. show_source_page(clip=trim) keeps the art.
        rebuilt = pdfdoc.open()
        try:
            for i, page in enumerate(doc):
                trim = trim_in_page_space(page)
                new_p = rebuilt.new_page(
                    width=max(trim.width, 1.0), height=max(trim.height, 1.0),
                )
                show_source_page(
                    new_p, new_p.rect, doc, i, keep_proportion=False, clip=trim,
                )
            while doc.page_count:
                doc.delete_page(-1)
            doc.insert_pdf(rebuilt)
        finally:
            rebuilt.close()
        if flattening:
            _flatten_page_annotations(doc)
        return doc
    normalize_page_boxes(doc, flattening=flattening, max_dpi=max_dpi)
    return doc


def _device_image_mode(colorspace):
    if colorspace is None or isinstance(colorspace, (list, tuple)):
        return None
    try:
        import pikepdf
        if isinstance(colorspace, pikepdf.Array):
            return None
    except Exception:
        return None
    name = str(colorspace)
    if name == "/DeviceGray":
        return "L"
    if name == "/DeviceRGB":
        return "RGB"
    if name == "/DeviceCMYK":
        return "CMYK"
    return None


def _filter_names(filt):
    if filt is None:
        return []
    try:
        import pikepdf
        if isinstance(filt, pikepdf.Array):
            return [str(item) for item in filt]
    except Exception:
        pass
    return [str(filt)]


def _prepare_resample(obj, new_w, new_h):
    """Return a resized image, or None when this XObject should be left alone."""
    if obj is None or obj.get("/ImageMask") is not None:
        return None
    bits = int(obj.get("/BitsPerComponent") or 8)
    mode = _device_image_mode(obj.get("/ColorSpace"))
    if bits != 8 or mode is None:
        return None
    width = int(obj.get("/Width") or 0)
    height = int(obj.get("/Height") or 0)
    channels = {"L": 1, "RGB": 3, "CMYK": 4}[mode]
    if width < 2 or height < 2 or new_w >= width or new_h >= height:
        return None
    try:
        names = _filter_names(obj.get("/Filter"))
        if len(names) == 1 and "DCTDecode" in names[0]:
            image = Image.open(io.BytesIO(obj.read_raw_bytes()))
            image.load()
            if image.mode != mode or image.size != (width, height):
                return None
        elif names and not all("FlateDecode" in name for name in names):
            return None
        else:
            data = obj.read_bytes()
            image = Image.frombytes(mode, (width, height), data[: width * height * channels])
        return image.resize((new_w, new_h), Image.Resampling.LANCZOS)
    except Exception:
        return None


def _rewrite_image_samples(obj, image):
    import pikepdf
    obj.write(image.tobytes(), filter=pikepdf.Name.FlateDecode)
    obj.Width = image.size[0]
    obj.Height = image.size[1]
    obj.BitsPerComponent = 8
    obj.ColorSpace = {
        "L": pikepdf.Name.DeviceGray,
        "RGB": pikepdf.Name.DeviceRGB,
        "CMYK": pikepdf.Name.DeviceCMYK,
    }[image.mode]
    if "/DecodeParms" in obj:
        del obj["/DecodeParms"]


def _resample_image_obj(obj, scale, seen):
    """Shrink one image XObject. Leave it unchanged when the samples cannot be read safely."""
    try:
        ident = tuple(obj.objgen)
    except Exception:
        ident = id(obj)
    if ident in seen or scale >= 0.999:
        return
    if str(obj.get("/Subtype") or "") not in ("/Image", ""):
        return
    width = int(obj.get("/Width") or 0)
    height = int(obj.get("/Height") or 0)
    new_w = max(1, int(round(width * scale)))
    new_h = max(1, int(round(height * scale)))
    image = _prepare_resample(obj, new_w, new_h)
    if image is None:
        return
    smask = obj.get("/SMask")
    mask_image = None
    if smask is not None:
        mask_image = _prepare_resample(smask, new_w, new_h)
        if mask_image is None:
            return
    try:
        if mask_image is not None:
            _rewrite_image_samples(smask, mask_image)
        _rewrite_image_samples(obj, image)
    except Exception:
        return
    seen.add(ident)
    if smask is not None:
        try:
            seen.add(tuple(smask.objgen))
        except Exception:
            pass


def cap_image_resolution(doc, max_dpi):
    """Downsample placed images whose effective PPI is above max_dpi.

    Illustrator private data and any image that cannot be decoded stay as they are.
    Images already at or below the cap are not touched.
    """
    max_dpi = parse_max_dpi(max_dpi) if not isinstance(max_dpi, (int, float)) else float(max_dpi)
    if not max_dpi or doc is None or getattr(doc, "page_count", 0) == 0:
        return
    from modules.preflight.inspect import page_image_placements

    lowest = {}
    objects = {}
    for page in doc:
        pike = page._pike
        for item in page_image_placements(page):
            xref = int(item.get("xref") or 0)
            if not xref:
                continue
            hi = max(float(item.get("dpi_x") or 0), float(item.get("dpi_y") or 0))
            if hi <= 1:
                continue
            prev = lowest.get(xref)
            if prev is None or hi < prev:
                lowest[xref] = hi
        seen_walk = set()

        def walk(resources):
            if resources is None:
                return
            xobjects = resources.get("/XObject")
            if xobjects is None:
                return
            for key in list(xobjects.keys()):
                obj = xobjects[key]
                try:
                    ident = tuple(obj.objgen)
                except Exception:
                    continue
                if ident in seen_walk:
                    continue
                seen_walk.add(ident)
                subtype = str(obj.get("/Subtype") or "")
                if subtype == "/Form":
                    walk(obj.get("/Resources"))
                elif subtype == "/Image":
                    objects[ident[0]] = obj

        walk(pike.obj.get("/Resources"))

    seen = set()
    for xref, hi in lowest.items():
        if hi <= max_dpi + 0.5:
            continue
        obj = objects.get(xref)
        if obj is None:
            continue
        _resample_image_obj(obj, max_dpi / hi, seen)


def save_optimized_pdf(doc, out_path):
    doc.save(
        out_path,
        garbage=4,
        deflate=True,
        deflate_images=True,
        deflate_fonts=True,
        clean=True,
    )


def save_production_pdf(doc, out_path, save_flags, lock_print=False, lock_edit=False, owner_pw="readysetpdf"):
    owner_pw = (owner_pw or "").strip()
    if lock_print or lock_edit or owner_pw != "readysetpdf":
        perm_mask = pdfdoc.PDF_PERM_ACCESSIBILITY
        if not lock_print:
            perm_mask |= pdfdoc.PDF_PERM_PRINT
        if not lock_edit:
            perm_mask |= (pdfdoc.PDF_PERM_MODIFY | pdfdoc.PDF_PERM_ANNOTATE | pdfdoc.PDF_PERM_COPY)
        owner_pass = owner_pw or "readysetpdf"
        doc.save(
            out_path,
            owner_pw=owner_pass,
            user_pw="",
            permissions=perm_mask,
            encryption=pdfdoc.PDF_ENCRYPT_AES_128,
            **save_flags,
        )
    else:
        doc.save(out_path, **save_flags)


def apply_cutter_marks(page, w, h, c_size, c_thick, c_margin, placement="Inside",
                       draw_l_marks=True, collate_mark="None", collate_corner="Top Left",
                       color=(0, 0, 0)):
    m_l, m_r = c_margin, w - c_margin
    m_t, m_b = c_margin, h - c_margin
    d = c_size if placement == "Inside" else -c_size
    rgb = tuple(color) if color is not None else (0, 0, 0)
    if draw_l_marks:
        page.draw_line(pdfdoc.Point(m_l, m_t), pdfdoc.Point(m_l + d, m_t), width=c_thick, color=rgb)
        page.draw_line(pdfdoc.Point(m_l, m_t), pdfdoc.Point(m_l, m_t + d), width=c_thick, color=rgb)
        page.draw_line(pdfdoc.Point(m_r, m_t), pdfdoc.Point(m_r - d, m_t), width=c_thick, color=rgb)
        page.draw_line(pdfdoc.Point(m_r, m_t), pdfdoc.Point(m_r, m_t + d), width=c_thick, color=rgb)
        page.draw_line(pdfdoc.Point(m_l, m_b), pdfdoc.Point(m_l + d, m_b), width=c_thick, color=rgb)
        page.draw_line(pdfdoc.Point(m_l, m_b), pdfdoc.Point(m_l, m_b - d), width=c_thick, color=rgb)
        page.draw_line(pdfdoc.Point(m_r, m_b), pdfdoc.Point(m_r - d, m_b), width=c_thick, color=rgb)
        page.draw_line(pdfdoc.Point(m_r, m_b), pdfdoc.Point(m_r, m_b - d), width=c_thick, color=rgb)

    # Extra marks use the same corner origin as the four-corner L marks.
    # An extra 0.55*size inset shifted Registration L / Cross / Dots 2–3 mm inward.
    corners = {
        "Top Left": (m_l, m_t),
        "Top Right": (m_r, m_t),
        "Bottom Left": (m_l, m_b),
        "Bottom Right": (m_r, m_b),
    }
    style = (collate_mark or "None").strip()
    if style in ("None", ""):
        return
    if style == "Round Dots":
        radius = max(c_size * 0.35, 1.0)
        for x, y in corners.values():
            dx = radius if x <= w / 2.0 else -radius
            dy = radius if y <= h / 2.0 else -radius
            page.draw_circle(
                pdfdoc.Point(x + dx, y + dy), radius,
                color=rgb, width=c_thick, fill=rgb,
            )
        return
    x, y = corners.get(collate_corner, corners["Top Left"])
    arm = abs(d) if d else max(c_size, 4.0)
    if style == "Registration Cross":
        page.draw_line(pdfdoc.Point(x - arm, y), pdfdoc.Point(x + arm, y), width=c_thick, color=rgb)
        page.draw_line(pdfdoc.Point(x, y - arm), pdfdoc.Point(x, y + arm), width=c_thick, color=rgb)
    elif style == "Registration L":
        sx = 1 if "Left" in collate_corner else -1
        sy = 1 if "Top" in collate_corner else -1
        page.draw_line(pdfdoc.Point(x, y), pdfdoc.Point(x + sx * arm, y), width=c_thick, color=rgb)
        page.draw_line(pdfdoc.Point(x, y), pdfdoc.Point(x, y + sy * arm), width=c_thick, color=rgb)


JOIN_STEP = "Join PDFs"
SPLIT_STEP = "Split PDFs"
JOIN_NAME_FIRST = "first_file"
JOIN_NAME_DATETIME = "datetime"
SPLIT_NAME_PAGE = "page"
_UNSAFE_FILENAME = '<>:"/\\|?*'


def steps_include_join_split(steps):
    for step in steps or []:
        if step.get("type") in (JOIN_STEP, SPLIT_STEP):
            return True
    return False


def _safe_filename_stem(stem):
    text = str(stem or "").strip()
    cleaned = "".join("_" if ch in _UNSAFE_FILENAME else ch for ch in text)
    cleaned = cleaned.strip(" .")
    return cleaned or "document"


def join_output_stem(naming, first_filename, when=None):
    """Stem for a Join step. first_file uses the first asset; datetime uses the clock."""
    if (naming or JOIN_NAME_FIRST) == JOIN_NAME_DATETIME:
        moment = when or datetime.datetime.now()
        return moment.strftime("Combined_%Y-%m-%d_%H%M%S")
    stem = _safe_filename_stem(os.path.splitext(os.path.basename(str(first_filename or "card")))[0])
    return f"Combined_{stem}"


def split_page_stem(source_stem, page_number):
    """One-page name: card.pdf page 1 becomes card_p1."""
    stem = _safe_filename_stem(os.path.splitext(os.path.basename(str(source_stem or "document")))[0])
    return f"{stem}_p{int(page_number)}"


def output_path_avoiding_sources(directory, stem, source_paths):
    """PDF path in directory. Never the same path as a source file."""
    stem = _safe_filename_stem(stem)
    blocked = set()
    for path in source_paths or []:
        if not path:
            continue
        try:
            blocked.add(os.path.normcase(os.path.abspath(path)))
        except Exception:
            continue
    for n in range(0, 1000):
        name = f"{stem}.pdf" if n == 0 else f"{stem}_{n + 1}.pdf"
        candidate = os.path.join(directory, name)
        try:
            key = os.path.normcase(os.path.abspath(candidate))
        except Exception:
            key = os.path.normcase(candidate)
        if key not in blocked:
            return candidate
    return os.path.join(directory, f"{stem}_copy.pdf")


def _close_doc_quiet(doc):
    if doc is None:
        return
    try:
        doc.close()
    except Exception:
        pass


def _execute_pipeline(self, active_doc, action_queue, preview_mode=False, output_dir=None, sidecar_stem=None, finalize=True):
    if isinstance(action_queue, dict):
        action_queue = action_queue.get("steps") or []
    for step in action_queue:
        stype = step["type"]
        params = step.get("params") or {}
        if stype == "Unlock PDF":
            # The owner password is applied when the source file is opened.
            continue
        if stype in (JOIN_STEP, SPLIT_STEP):
            # Join and Split change how many documents the stack is holding.
            # run_join_split_stack applies them between the other steps.
            continue

        if stype == "Crop Margin":
            next_doc = pdfdoc.open()
            for page in active_doc:
                left = max(0.0, self.to_points(params["left"], params.get("unit")))
                top = max(0.0, self.to_points(params["top"], params.get("unit")))
                right = max(0.0, self.to_points(params["right"], params.get("unit")))
                bottom = max(0.0, self.to_points(params["bottom"], params.get("unit")))
                r = page.rect
                clip = pdfdoc.Rect(r.x0 + left, r.y0 + top, r.x1 - right, r.y1 - bottom) & r
                if clip.is_empty or clip.width < 1.0 or clip.height < 1.0:
                    clip = pdfdoc.Rect(r)
                copy_clipped_page(next_doc, active_doc, page.number, clip=clip)
            active_doc.close(); active_doc = next_doc
            
        elif stype == "VDP Mail Merge":
            if preview_mode:
                continue
            fields = params.get("fields", [])
            rows = load_merge_rows(
                csv_path=params.get("csv_path", ""),
                generate_count=params.get("generate_count", 1),
                mapped_columns=mapped_merge_columns(fields),
            )
            if not rows:
                continue
            next_doc = apply_vdp_merge(active_doc, rows, fields, self.to_points, params.get("unit"))
            try:
                active_doc.close()
            except Exception:
                pass
            active_doc = next_doc
            
        elif stype == "OCR Extraction":
            active_doc = run_ocr_extraction(
                active_doc, params, preview_mode=preview_mode,
                output_dir=output_dir, sidecar_stem=sidecar_stem,
            )
        
        elif stype == "Insert Blank Page":
            next_doc = pdfdoc.open()
            pos = params.get("position", "End of Document")
            try: pnum = int(params.get("page_num", "1")) - 1
            except ValueError: pnum = len(active_doc) - 1
            if len(active_doc) == 0: next_doc.new_page(width=612, height=792)
            else:
                for p_idx, page in enumerate(active_doc):
                    w, h = page.rect.width, page.rect.height
                    if pos == "Beginning of Document" and p_idx == 0: next_doc.new_page(width=w, height=h)
                    new_p = next_doc.new_page(width=w, height=h)
                    show_source_page(new_p, new_p.rect, active_doc, page.number, keep_proportion=False)
                    if pos == "After Page #" and p_idx == pnum: next_doc.new_page(width=w, height=h)
                if pos == "End of Document":
                    last_p = active_doc[-1]
                    next_doc.new_page(width=last_p.rect.width, height=last_p.rect.height)
            active_doc.close(); active_doc = next_doc
            
        elif stype == "Color Conversion":
            mode = params.get("mode", "Grayscale")
            if mode == "Keep Original":
                continue
            active_doc = convert_colorspace(
                active_doc, mode, dpi=params.get("dpi", 300), preview_mode=preview_mode
            )

        elif stype == "Resize":
            next_doc = pdfdoc.open()
            for page in active_doc:
                w, h = page.rect.width, page.rect.height
                tw = self.to_points(params["w"], params.get("unit"))
                th = self.to_points(params["h"], params.get("unit"))
                if params.get("landscape", False) and tw < th: tw, th = th, tw
                new_p = next_doc.new_page(width=tw, height=th)
                
                if params.get("stretch", False):
                    dest = new_p.rect
                    show_source_page(new_p, dest, active_doc, page.number, keep_proportion=False)
                else:
                    sc = min(tw / w, th / h) if w and h else 1.0
                    fw, fh = w * sc, h * sc
                    dest = pdfdoc.Rect((tw - fw)/2, (th - fh)/2, (tw - fw)/2 + fw, (th - fh)/2 + fh)
                    show_source_page(new_p, dest, active_doc, page.number, keep_proportion=True)
                    
            active_doc.close(); active_doc = next_doc

        elif stype in ("Grid Imposition", "Monkey Imposition"):
            if stype == "Monkey Imposition":
                params = dict(params)
                params["auto_fit"] = True
            next_doc = pdfdoc.open()
            sw = self.to_points(params["sheet_w"], params.get("unit"))
            sh = self.to_points(params["sheet_h"], params.get("unit"))
            if params.get("landscape", False) and sw < sh: sw, sh = sh, sw
            g_h = self.to_points(params.get("gutter_h", 0), params.get("unit"))
            g_v = self.to_points(params.get("gutter_v", 0), params.get("unit"))
            m_l = self.to_points(params.get("margin_l", 0), params.get("unit"))
            m_t = self.to_points(params.get("margin_t", 0), params.get("unit"))
            center = params["center"]; draw_marks = params.get("draw_marks", True)
            m_dist = self.to_points(params.get("mark_dist", "0.125"), params.get("unit"))
            m_thick = self.to_points(params.get("mark_thick", "0.007"), params.get("unit"))
            m_overlap = self.to_points(params.get("mark_overlap", 0), params.get("unit"))
            m_color = mark_rgb(params.get("mark_color"))
            art_has_bleed = params.get("art_has_bleed", False)
            trim_w_pt = self.to_points(params.get("trim_w", 0) or 0, params.get("unit"))
            trim_h_pt = self.to_points(params.get("trim_h", 0) or 0, params.get("unit"))
            double_sided = params.get("double_sided", False)
            flip_edge = params.get("flip_edge", "long")
            anchor = normalize_anchor(params.get("anchor"), center=center)
            
            autoscale = params.get("autoscale", False)
            maintain_aspect = params.get("aspect", True)
            auto_fit = bool(params.get("auto_fit"))
            direction = params.get("direction", "LTR")
            if auto_fit and len(active_doc):
                step_w, step_h, _, _ = source_layout_size(
                    active_doc[0], trim_w_pt, trim_h_pt, art_has_bleed,
                )
                cols = max(1, int((sw - 2 * m_l + g_h) / (step_w + g_h + 0.001)))
                rows = max(1, int((sh - 2 * m_t + g_v) / (step_h + g_v + 0.001)))
                autoscale = False
            else:
                cols = int(round(float(str(params.get("cols") or 1).replace(",", "."))))
                rows = int(round(float(str(params.get("rows") or 1).replace(",", "."))))

            avail_w = sw - (2 * m_l) - ((cols - 1) * g_h)
            avail_h = sh - (2 * m_t) - ((rows - 1) * g_v)
            cell_w = avail_w / cols if cols > 0 else 0
            cell_h = avail_h / rows if rows > 0 else 0
            
            page_count = len(active_doc)
            cells_per_sheet = cols * rows
            sheets = build_impose_sheets(
                page_count, cells_per_sheet, params.get("repeat", 1),
                params.get("order", "Sequential"), double_sided,
            )
            if cells_per_sheet > 0:
                for chunk, is_back in sheets:
                    new_p = next_doc.new_page(width=sw, height=sh)
                    even_sheet = bool(is_back)
                    use_anchor = mirror_anchor(anchor, sw, sh, flip_edge, even_sheet)

                    cut_xs, cut_ys = set(), set()
                    grid_x0, grid_y0 = sw, sh
                    grid_x1, grid_y1 = 0, 0
                    usable = [p for p in chunk if p is not None]
                    first = usable[0] if usable else 0
                    first_step_w, first_step_h, _, _ = source_layout_size(
                        active_doc[first], trim_w_pt, trim_h_pt, art_has_bleed,
                    )
                    if autoscale and cell_w > 0 and cell_h > 0:
                        draw_w, draw_h = cell_w, cell_h
                    else:
                        draw_w, draw_h = first_step_w, first_step_h
                    total_grid_w = (draw_w * cols) + (g_h * (cols - 1))
                    total_grid_h = (draw_h * rows) + (g_v * (rows - 1))
                    start_x, start_y = anchored_origin(sw, sh, total_grid_w, total_grid_h, m_l, m_t, use_anchor)

                    for idx, src_page_num in enumerate(chunk):
                        if src_page_num is None:
                            continue
                        r, c = duplex_cell(idx, cols, rows, sw, sh, flip_edge, even_sheet)
                        if direction != "LTR":
                            c = cols - 1 - c
                        step_w, step_h, _, _ = source_layout_size(
                            active_doc[src_page_num], trim_w_pt, trim_h_pt, art_has_bleed,
                        )
                        
                        if autoscale and cell_w > 0 and cell_h > 0:
                            tile_w, tile_h = cell_w, cell_h
                        else:
                            tile_w, tile_h = step_w, step_h
                            
                        x0 = start_x + c * (draw_w + g_h)
                        y0 = start_y + r * (draw_h + g_v)
                        slot = pdfdoc.Rect(x0, y0, x0 + tile_w, y0 + tile_h)
                        dest = nup_dest_on_slot(
                            active_doc[src_page_num], slot, trim_w_pt, trim_h_pt,
                            art_has_bleed, autoscale and cell_w > 0 and cell_h > 0, maintain_aspect,
                        )
                        show_source_page(
                            new_p, dest, active_doc, src_page_num,
                            keep_proportion=False,
                        )

                        if draw_marks:
                            trim_r = placed_trim_rect(
                                active_doc[src_page_num], dest, False,
                                trim_w_pt, trim_h_pt, art_has_bleed,
                            )
                            cut_xs.update([trim_r.x0, trim_r.x1]); cut_ys.update([trim_r.y0, trim_r.y1])
                            grid_x0 = min(grid_x0, trim_r.x0); grid_y0 = min(grid_y0, trim_r.y0)
                            grid_x1 = max(grid_x1, trim_r.x1); grid_y1 = max(grid_y1, trim_r.y1)

                    if draw_marks:
                        draw_perimeter_crop_marks(
                            new_p, cut_xs, cut_ys, grid_x0, grid_y0, grid_x1, grid_y1, sw, sh, m_dist, m_thick,
                            overlap=m_overlap, color=m_color,
                        )

            active_doc.close(); active_doc = next_doc
            
        elif stype == "Booklet Spread":
            next_doc = pdfdoc.open()
            sw = self.to_points(params.get("sheet_w", 17), params.get("unit"))
            sh = self.to_points(params.get("sheet_h", 11), params.get("unit"))
            if params.get("landscape", False) and sw < sh: sw, sh = sh, sw
            center_gutter = self.to_points(params.get("center_gutter", 0), params.get("unit"))
            margin_l = self.to_points(params.get("margin_l", 0), params.get("unit"))
            margin_t = self.to_points(params.get("margin_t", 0), params.get("unit"))
            center_mode = params.get("center", True)
            creep_per_sheet = self.to_points(params.get("creep_val", 0), params.get("unit"))
            creep_dir = params.get("creep_dir", "Outward")
            art_has_bleed = params.get("art_has_bleed", False)
            trim_w_pt = self.to_points(params.get("trim_w", 0) or 0, params.get("unit"))
            trim_h_pt = self.to_points(params.get("trim_h", 0) or 0, params.get("unit"))
            draw_marks = params.get("draw_marks", False)
            m_dist = self.to_points(params.get("mark_dist", "0.125"), params.get("unit"))
            m_thick = self.to_points(params.get("mark_thick", "0.007"), params.get("unit"))
            m_overlap = self.to_points(params.get("mark_overlap", 0), params.get("unit"))
            m_color = mark_rgb(params.get("mark_color"))
            anchor = normalize_anchor(params.get("anchor"), center=center_mode)
            ay = ANCHOR_POINTS[anchor][1]

            if len(active_doc) % 4 != 0:
                for _ in range(4 - (len(active_doc) % 4)): active_doc.new_page()

            total_p = len(active_doc)

            for s_idx in range(total_p // 2):
                sheet_num = s_idx // 2
                is_back = (s_idx % 2 == 1)
                if not is_back: pl, pr = total_p - 1 - (sheet_num * 2), sheet_num * 2
                else: pl, pr = (sheet_num * 2) + 1, total_p - 2 - (sheet_num * 2)

                new_p = next_doc.new_page(width=sw, height=sh)
                shift = booklet_creep_shift(creep_per_sheet, sheet_num, creep_dir, center_gutter)

                tw_l, th_l, _, _ = source_layout_size(
                    active_doc[pl], trim_w_pt, trim_h_pt, art_has_bleed,
                )
                tw_r, th_r, _, _ = source_layout_size(
                    active_doc[pr], trim_w_pt, trim_h_pt, art_has_bleed,
                )
                block_w = max(tw_l + tw_r + (2.0 * shift), 1.0)
                block_h = max(th_l, th_r)
                start_x, start_y = anchored_origin(sw, sh, block_w, block_h, margin_l, margin_t, anchor)
                slot_x_l = start_x
                slot_x_r = start_x + tw_l + (2.0 * shift)
                if ay < 0.25:
                    slot_y_l, slot_y_r = start_y, start_y
                elif ay > 0.75:
                    slot_y_l = start_y + block_h - th_l
                    slot_y_r = start_y + block_h - th_r
                else:
                    slot_y_l = start_y + (block_h - th_l) / 2.0
                    slot_y_r = start_y + (block_h - th_r) / 2.0
                spine_x = start_x + tw_l + shift

                src_l_rect = pdfdoc.Rect(active_doc[pl].rect)
                tgt_l_rect = nup_dest_on_slot(
                    active_doc[pl],
                    pdfdoc.Rect(slot_x_l, slot_y_l, slot_x_l + tw_l, slot_y_l + th_l),
                    trim_w_pt, trim_h_pt, art_has_bleed, False, False,
                )
                tgt_l_rect, src_l_rect = place_booklet_leaf(
                    new_p, active_doc, pl, tgt_l_rect, src_l_rect, spine_x, True, sw, sh,
                    clip_spine=not art_has_bleed,
                )

                src_r_rect = pdfdoc.Rect(active_doc[pr].rect)
                tgt_r_rect = nup_dest_on_slot(
                    active_doc[pr],
                    pdfdoc.Rect(slot_x_r, slot_y_r, slot_x_r + tw_r, slot_y_r + th_r),
                    trim_w_pt, trim_h_pt, art_has_bleed, False, False,
                )
                tgt_r_rect, src_r_rect = place_booklet_leaf(
                    new_p, active_doc, pr, tgt_r_rect, src_r_rect, spine_x, False, sw, sh,
                    clip_spine=not art_has_bleed,
                )

                if draw_marks:
                    cut_xs, cut_ys = set(), set()
                    grid_x0, grid_y0 = sw, sh
                    grid_x1, grid_y1 = 0, 0
                    for page_i, tgt, src_clip in (
                        (pl, tgt_l_rect, src_l_rect),
                        (pr, tgt_r_rect, src_r_rect),
                    ):
                        if tgt.width <= 0 or tgt.height <= 0:
                            continue
                        trim_src = resolve_source_trim_rect(
                            active_doc[page_i], trim_w_pt, trim_h_pt, art_has_bleed,
                        ) & src_clip
                        if trim_src.is_empty:
                            continue
                        trim_r = map_src_rect_to_dest(src_clip, trim_src, tgt)
                        cut_xs.update([trim_r.x0, trim_r.x1]); cut_ys.update([trim_r.y0, trim_r.y1])
                        grid_x0 = min(grid_x0, trim_r.x0); grid_y0 = min(grid_y0, trim_r.y0)
                        grid_x1 = max(grid_x1, trim_r.x1); grid_y1 = max(grid_y1, trim_r.y1)
                    draw_perimeter_crop_marks(
                        new_p, cut_xs, cut_ys, grid_x0, grid_y0, grid_x1, grid_y1, sw, sh, m_dist, m_thick,
                        overlap=m_overlap, color=m_color,
                    )

            active_doc.close(); active_doc = next_doc

        elif stype == "Cutter Marks":
            next_doc = pdfdoc.open()
            targets = self.parse_page_selection(params["pages"], len(active_doc))
            c_size = self.to_points(params["size"], params.get("unit"))
            c_thick = self.to_points(params["thick"], params.get("unit"))
            c_margin = self.to_points(params["margin"], params.get("unit"))
            placement = params["placement"]; remove_art = params["remove_art"]
            draw_l = params.get("cut_l_marks", True)
            collate = params.get("collate_mark", "None")
            corner = params.get("collate_corner", "Top Left")
            c_color = mark_rgb(params.get("mark_color"))

            for r_idx, page in enumerate(active_doc):
                w, h = page.rect.width, page.rect.height
                new_p = next_doc.new_page(width=w, height=h)
                is_target = r_idx in targets
                if not (remove_art and is_target):
                    show_source_page(new_p, new_p.rect, active_doc, page.number, keep_proportion=False)
                if is_target:
                    apply_cutter_marks(
                        new_p, w, h, c_size, c_thick, c_margin, placement,
                        draw_l_marks=draw_l, collate_mark=collate, collate_corner=corner,
                        color=c_color,
                    )
            active_doc.close(); active_doc = next_doc
            
        elif stype == "Rotate Pages":
            next_doc = pdfdoc.open()
            try:
                angle = int(round(float(str(params.get("angle", 90)).replace(",", "."))))
            except (TypeError, ValueError):
                angle = 90
            angle = ((angle % 360) + 360) % 360
            if angle % 90:
                angle = int(round(angle / 90.0) * 90) % 360
            targets = self.parse_page_selection(params.get("pages", "all"), len(active_doc))
            for r_idx, page in enumerate(active_doc):
                src_w, src_h = page.rect.width, page.rect.height
                rot = angle if r_idx in targets else 0
                if rot in (90, 270):
                    nw, nh = src_h, src_w
                else:
                    nw, nh = src_w, src_h
                new_p = next_doc.new_page(width=nw, height=nh)
                show_source_page(
                    new_p, new_p.rect, active_doc, page.number,
                    keep_proportion=True, rotate=rot,
                )
            active_doc.close(); active_doc = next_doc
                
    if finalize and not preview_mode:
        max_dpi = None
        reader = getattr(self, "_export_max_dpi", None)
        if callable(reader):
            try:
                max_dpi = reader()
            except Exception:
                max_dpi = None
        if max_dpi:
            cap_image_resolution(active_doc, max_dpi)
        active_doc = flatten_hidden_page_content(active_doc)
    return active_doc


def run_join_split_stack(
    self,
    paths,
    steps,
    preview_mode=False,
    page_box_mode="keep",
    flattening=False,
    max_dpi=None,
    owner_password=None,
    output_dir=None,
    reassemble_for_preview=False,
):
    """Run a stack across asset files, honoring Join and Split in stack order.

    Steps before Join run on each file. Join makes one document, and later
    steps edit that combined file. Steps before Split run first. Split makes
    one document per page so a later step edits each page. Returns one
    document when reassemble_for_preview is set, otherwise a list of
    {"doc", "stem", "source"} records.
    """
    steps = list(steps or [])
    opened = []
    first_source = ""
    for path in list(paths or []):
        if not path:
            continue
        if not first_source:
            first_source = path
        doc = pdfdoc.open()
        try:
            insert_source_file(doc, path, max_dpi=max_dpi, owner_password=owner_password)
        except UnlockError:
            _close_doc_quiet(doc)
            for item in opened:
                _close_doc_quiet(item.get("doc"))
            raise
        except Exception:
            _close_doc_quiet(doc)
            continue
        try:
            prepare_imported_doc(doc, page_box_mode, flattening=flattening, max_dpi=max_dpi)
        except Exception:
            _close_doc_quiet(doc)
            continue
        stem = os.path.splitext(os.path.basename(path))[0]
        opened.append({"doc": doc, "stem": stem, "source": path})
    if not opened:
        return None

    docs = opened
    index = 0
    try:
        while index < len(steps):
            segment = []
            while index < len(steps) and steps[index].get("type") not in (JOIN_STEP, SPLIT_STEP):
                segment.append(steps[index])
                index += 1
            if segment:
                for item in docs:
                    item["doc"] = self._execute_pipeline(
                        item["doc"], segment, preview_mode=preview_mode,
                        output_dir=output_dir, sidecar_stem=item.get("stem"), finalize=False,
                    )
            if index >= len(steps):
                break
            mark = steps[index]
            index += 1
            kind = mark.get("type")
            params = mark.get("params") or {}
            if kind == JOIN_STEP:
                combined = pdfdoc.open()
                for item in docs:
                    source = item.get("doc")
                    if source is not None and len(source):
                        combined.insert_pdf(source)
                    _close_doc_quiet(source)
                stem = join_output_stem(params.get("naming"), first_source)
                docs = [{"doc": combined, "stem": stem, "source": first_source}]
            elif kind == SPLIT_STEP:
                pieces = []
                for item in docs:
                    source = item.get("doc")
                    count = len(source) if source is not None else 0
                    base = item.get("stem") or "document"
                    for page_index in range(count):
                        page_doc = pdfdoc.open()
                        page_doc.insert_pdf(source, from_page=page_index, to_page=page_index)
                        pieces.append({
                            "doc": page_doc,
                            "stem": split_page_stem(base, page_index + 1),
                            "source": item.get("source") or first_source,
                        })
                    _close_doc_quiet(source)
                docs = pieces
        if not preview_mode:
            for item in docs:
                item["doc"] = self._execute_pipeline(
                    item["doc"], [], preview_mode=False, finalize=True,
                )
    except Exception:
        for item in docs:
            _close_doc_quiet(item.get("doc"))
        raise

    if not docs:
        return None
    if reassemble_for_preview:
        if len(docs) == 1:
            return docs[0]["doc"]
        merged = pdfdoc.open()
        for item in docs:
            source = item.get("doc")
            if source is not None and len(source):
                merged.insert_pdf(source)
            _close_doc_quiet(source)
        return merged
    return docs
