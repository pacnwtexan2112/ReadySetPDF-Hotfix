"""PDF page-box helpers (MediaBox, CropBox, TrimBox, BleedBox, ArtBox).

Numbers come from pikepdf. MediaBox stays in PDF space. Crop, Trim, Bleed,
and Art are flipped on Y inside that MediaBox, which is the space 3.54 used.
A box the file never wrote falls back to Crop, then Media.
"""

import io

import pikepdf

from pdfgeom import Rect

PAGE_BOX_KEEP = "keep"
PAGE_BOX_CROP_TO_TRIM = "crop_to_trim"
PAGE_BOX_NORMALIZE_TO_TRIM = "normalize_to_trim"

PAGE_BOX_MODES = (
    PAGE_BOX_KEEP,
    PAGE_BOX_CROP_TO_TRIM,
    PAGE_BOX_NORMALIZE_TO_TRIM,
)

PAGE_BOX_LABELS = {
    PAGE_BOX_KEEP: "Do nothing (keep original boxes)",
    PAGE_BOX_CROP_TO_TRIM: "Set CropBox to match TrimBox",
    PAGE_BOX_NORMALIZE_TO_TRIM: "Remove extra margins / white space",
}

_MODE_ALIASES = {
    "keep": PAGE_BOX_KEEP,
    "keep original": PAGE_BOX_KEEP,
    "do nothing": PAGE_BOX_KEEP,
    "none": PAGE_BOX_KEEP,
    "crop_to_trim": PAGE_BOX_CROP_TO_TRIM,
    "crop to trim": PAGE_BOX_CROP_TO_TRIM,
    "cropbox_to_trimbox": PAGE_BOX_CROP_TO_TRIM,
    "set cropbox to match trimbox": PAGE_BOX_CROP_TO_TRIM,
    "normalize_to_trim": PAGE_BOX_NORMALIZE_TO_TRIM,
    "normalize to trim": PAGE_BOX_NORMALIZE_TO_TRIM,
    "normalize_to_trimbox": PAGE_BOX_NORMALIZE_TO_TRIM,
    "remove extra margins": PAGE_BOX_NORMALIZE_TO_TRIM,
    "remove extra margins / white space": PAGE_BOX_NORMALIZE_TO_TRIM,
}


def normalize_page_box_mode(value):
    key = str(value or PAGE_BOX_KEEP).strip().lower()
    return _MODE_ALIASES.get(key, PAGE_BOX_KEEP)


def _as_rect(value):
    try:
        rect = Rect(value)
    except Exception:
        return None
    if rect.is_empty or rect.width < 0.5 or rect.height < 0.5:
        return None
    return Rect(rect)


def _quad(box):
    x0, y0, x1, y1 = (float(v) for v in list(box)[:4])
    if x1 < x0:
        x0, x1 = x1, x0
    if y1 < y0:
        y0, y1 = y1, y0
    return x0, y0, x1, y1


def _flip_y(box, media):
    x0, y0, x1, y1 = _quad(box)
    _mx0, _my0, _mx1, my1 = _quad(media)
    return (x0, my1 - y1, x1, my1 - y0)


def _rotation(page):
    value = page.obj.get("/Rotate", 0) if hasattr(page, "obj") else getattr(page, "rotation", 0)
    try:
        return int(value or 0) % 360
    except (TypeError, ValueError):
        return 0


def _visible_rect(crop, rotation):
    width = crop[2] - crop[0]
    height = crop[3] - crop[1]
    if int(rotation or 0) % 360 in (90, 270):
        width, height = height, width
    return (0.0, 0.0, width, height)


def _boxes_from_pike(page):
    media = _quad(page.mediabox)
    crop = _flip_y(page.cropbox, media)
    trim = _flip_y(page.trimbox, media)
    bleed = _flip_y(page.bleedbox, media)
    art = _flip_y(page.artbox, media)
    return {
        "mediabox": _as_rect(media),
        "cropbox": _as_rect(crop),
        "trimbox": _as_rect(trim),
        "bleedbox": _as_rect(bleed),
        "artbox": _as_rect(art),
        "rect": _as_rect(_visible_rect(crop, _rotation(page))),
    }


def _pike_page(page):
    getter = getattr(page, "_pike_page", None)
    if getter is not None:
        return getter(), None
    parent = page.parent
    data = parent.tobytes(garbage=0, deflate=False, clean=False)
    pdf = pikepdf.open(io.BytesIO(data))
    return pdf.pages[int(page.number)], pdf


def read_page_boxes(page):
    """Return each named box, or None when it is not a usable rectangle."""
    pike, owned = _pike_page(page)
    try:
        return _boxes_from_pike(pike)
    finally:
        if owned is not None:
            owned.close()


def resolve_named_box(page, name):
    """Pick a named box with MediaBox / CropBox / visible-rect fallbacks."""
    boxes = read_page_boxes(page)
    key = str(name or "").strip().lower()
    order = {
        "trim": ("trimbox", "cropbox", "mediabox", "rect"),
        "trimbox": ("trimbox", "cropbox", "mediabox", "rect"),
        "art": ("artbox", "cropbox", "mediabox", "rect"),
        "artbox": ("artbox", "cropbox", "mediabox", "rect"),
        "bleed": ("bleedbox", "cropbox", "mediabox", "rect"),
        "bleedbox": ("bleedbox", "cropbox", "mediabox", "rect"),
        "crop": ("cropbox", "mediabox", "rect"),
        "cropbox": ("cropbox", "mediabox", "rect"),
        "media": ("mediabox", "cropbox", "rect"),
        "mediabox": ("mediabox", "cropbox", "rect"),
    }.get(key, ("cropbox", "mediabox", "rect"))
    for item in order:
        if boxes.get(item):
            return Rect(boxes[item])
    return Rect(boxes.get("rect") or (0, 0, 1, 1))


def resolve_trim_box(page):
    """TrimBox, falling back to CropBox then MediaBox."""
    return resolve_named_box(page, "trim")


def map_pdf_box_to_page_space(page, box):
    """Map a MediaBox-space rectangle into page.rect (visible crop) space."""
    boxes = read_page_boxes(page)
    page_rect = boxes.get("rect") or Rect(0, 0, 1, 1)
    src = _as_rect(box)
    if src is None:
        return page_rect
    mb = boxes.get("mediabox") or page_rect
    if mb.width < 0.5 or mb.height < 0.5:
        return src & page_rect if src.intersects(page_rect) else page_rect
    mapped = Rect(
        page_rect.x0 + (src.x0 - mb.x0) * (page_rect.width / mb.width),
        page_rect.y0 + (src.y0 - mb.y0) * (page_rect.height / mb.height),
        page_rect.x0 + (src.x1 - mb.x0) * (page_rect.width / mb.width),
        page_rect.y0 + (src.y1 - mb.y0) * (page_rect.height / mb.height),
    )
    clipped = mapped & page_rect
    if clipped.is_empty or clipped.width < 0.5 or clipped.height < 0.5:
        return page_rect
    return clipped


def trim_in_page_space(page):
    """Visible trim rectangle in page.rect space, always inside the page."""
    return map_pdf_box_to_page_space(page, resolve_trim_box(page))


def _box_tuple(rect):
    if hasattr(rect, "x0"):
        return (float(rect.x0), float(rect.y0), float(rect.x1), float(rect.y1))
    return tuple(float(v) for v in rect)


def set_cropbox_to_trim(doc):
    """Set CropBox = TrimBox on every page. MediaBox is left alone."""
    count = getattr(doc, "page_count", None)
    if doc is None or (count if count is not None else len(doc)) == 0:
        return
    for page in doc:
        try:
            page.set_cropbox(_box_tuple(resolve_trim_box(page)))
        except Exception:
            try:
                page.set_cropbox(_box_tuple(read_page_boxes(page)["rect"]))
            except Exception:
                pass


def _points_in_unit(points, unit):
    """Match the app's global unit: inches, mm, or points."""
    if unit == "points":
        return float(points)
    if unit == "mm":
        return float(points) / 72.0 * 25.4
    return float(points) / 72.0


def _unit_suffix(unit):
    if unit == "mm":
        return "mm"
    if unit == "points":
        return "pt"
    return "in"


def format_page_boxes_summary(path, page_index=0, unit="inches"):
    """One-line Media / Crop / Trim readout for the import panel.

    Sizes follow the global unit (inches, mm, or points). PDF boxes are stored
    in points; this only changes the label.
    """
    try:
        pdf = pikepdf.open(path)
    except Exception as exc:
        return f"Could not read boxes: {exc}"
    try:
        if len(pdf.pages) == 0:
            return "File has no pages."
        index = max(0, min(int(page_index), len(pdf.pages) - 1))
        boxes = _boxes_from_pike(pdf.pages[index])
        suffix = _unit_suffix(unit)

        def _fmt(rect):
            if rect is None:
                return "—"
            width = _points_in_unit(rect.width, unit)
            height = _points_in_unit(rect.height, unit)
            return f"{width:.2f}×{height:.2f} {suffix}"

        return (
            f"p{index + 1}: Media {_fmt(boxes['mediabox'])}  ·  "
            f"Crop {_fmt(boxes['cropbox'])}  ·  Trim {_fmt(boxes['trimbox'])}"
        )
    finally:
        pdf.close()
