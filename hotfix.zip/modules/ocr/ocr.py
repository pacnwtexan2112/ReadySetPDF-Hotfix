"""OCR extraction helpers extracted from engine.py."""

import csv
import os
import sys
import tempfile

import pdfdoc
import pytesseract
from PIL import Image
from tkinter import filedialog, messagebox

from modules.core.pageops import show_source_page
from pdfrender import render_page_image


def find_tesseract():
    """Return tesseract.exe from the frozen bundle, or from the project folder."""
    candidates = []
    if getattr(sys, "frozen", False):
        bundle_root = getattr(sys, "_MEIPASS", "")
        if bundle_root:
            candidates.append(os.path.join(bundle_root, "Tesseract-OCR", "tesseract.exe"))
    else:
        here = os.path.dirname(os.path.abspath(__file__))
        app_root = os.path.dirname(os.path.dirname(here))
        candidates.append(os.path.join(app_root, "Tesseract-OCR", "tesseract.exe"))
    pf = os.environ.get("ProgramFiles", "C:\\Program Files")
    candidates.append(os.path.join(pf, "Tesseract-OCR", "tesseract.exe"))
    for tess_path in candidates:
        if os.path.isfile(tess_path):
            tessdata = os.path.join(os.path.dirname(tess_path), "tessdata")
            if os.path.isdir(tessdata):
                os.environ["TESSDATA_PREFIX"] = tessdata
            return tess_path
    return None


OCR_RENDER_DPI = 300


def raster_to_searchable_pdf(img, dpi=OCR_RENDER_DPI, lang="eng"):
    """OCR a PIL image to PDF bytes at an explicit DPI so the page keeps its size.

    pytesseract re-saves PIL objects without DPI tags, and Tesseract then
    defaults to 70 DPI. Saving a PNG ourselves and passing --dpi keeps the
    source scan's physical size.
    """
    tmp_path = None
    try:
        fd, tmp_path = tempfile.mkstemp(prefix="rsp_ocr_", suffix=".png")
        os.close(fd)
        img.save(tmp_path, format="PNG", dpi=(int(dpi), int(dpi)))
        return pytesseract.image_to_pdf_or_hocr(
            tmp_path,
            extension="pdf",
            lang=lang or "eng",
            config=f"--dpi {int(dpi)}",
        )
    finally:
        if tmp_path:
            try:
                os.remove(tmp_path)
            except OSError:
                pass


def _image_file_to_doc(src_path):
    """Open a raster the way the old image importer did: pixels at the file DPI, else 96."""
    doc = pdfdoc.open()
    with Image.open(src_path) as image:
        frames = getattr(image, "n_frames", 1) or 1
        for index in range(frames):
            image.seek(index)
            frame = image.convert("RGB")
            dpi = image.info.get("dpi") or (96, 96)
            try:
                dpi_x = float(dpi[0] or 96)
                dpi_y = float(dpi[1] or 96)
            except (TypeError, ValueError, IndexError):
                dpi_x = dpi_y = 96.0
            dpi_x = dpi_x if dpi_x >= 2 else 96.0
            dpi_y = dpi_y if dpi_y >= 2 else 96.0
            page = doc.new_page(width=frame.width / dpi_x * 72.0, height=frame.height / dpi_y * 72.0)
            page.insert_image(page.rect, pil=frame)
    return doc


def write_searchable_pdf(src_path, out_path, lang="eng", dpi=OCR_RENDER_DPI):
    """Turn a PDF or image into a searchable PDF with the original page size."""
    if not _prepare_tesseract():
        raise RuntimeError("Tesseract OCR engine not found.")
    ext = str(src_path).lower().rsplit(".", 1)[-1]
    active = _image_file_to_doc(src_path) if ext in ("png", "jpg", "jpeg", "tif", "tiff") else pdfdoc.open(src_path)
    next_doc = pdfdoc.open()
    try:
        for page in active:
            orig = page.rect
            img = render_page_image(active, page.number, float(dpi) / 72.0, annots=True)
            pdf_bytes = raster_to_searchable_pdf(img, dpi=dpi, lang=lang)
            ocr_pdf = pdfdoc.open("pdf", pdf_bytes)
            out_page = next_doc.new_page(width=orig.width, height=orig.height)
            if ocr_pdf.page_count:
                out_page.show_pdf_page(out_page.rect, ocr_pdf, 0)
            ocr_pdf.close()
        folder = os.path.dirname(os.path.abspath(out_path))
        if folder:
            os.makedirs(folder, exist_ok=True)
        next_doc.save(
            out_path,
            garbage=4,
            deflate=True,
            deflate_images=True,
            deflate_fonts=True,
            clean=True,
        )
    finally:
        next_doc.close()
        active.close()
    return out_path


OCR_TARGET_DPI = 300
OCR_MAX_SIDE = 4200
OCR_MAX_PIXELS = 10_000_000


def _ocr_render_scale(page, target_dpi=OCR_TARGET_DPI):
    pw = max(float(page.rect.width), 1.0)
    ph = max(float(page.rect.height), 1.0)
    scale = float(target_dpi) / 72.0
    width, height = pw * scale, ph * scale
    factor = 1.0
    longest = max(width, height)
    if longest > OCR_MAX_SIDE:
        factor = min(factor, OCR_MAX_SIDE / longest)
    pixels = width * height * factor * factor
    if pixels > OCR_MAX_PIXELS:
        factor = min(factor, (OCR_MAX_PIXELS / max(width * height, 1.0)) ** 0.5)
    return max(scale * factor, 0.12)


def _fit_ocr_image(img):
    if img.mode != "RGB":
        img = img.convert("RGB")
    width, height = img.size
    factor = 1.0
    longest = max(width, height)
    if longest > OCR_MAX_SIDE:
        factor = min(factor, OCR_MAX_SIDE / float(longest))
    if width * height * factor * factor > OCR_MAX_PIXELS:
        factor = min(factor, (OCR_MAX_PIXELS / float(max(width * height, 1))) ** 0.5)
    if factor < 0.999:
        resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.LANCZOS)
        img = img.resize((max(1, int(width * factor)), max(1, int(height * factor))), resample)
    return img


def _page_to_pil(page, dpi=OCR_TARGET_DPI):
    image = render_page_image(page.parent, page.number, _ocr_render_scale(page, dpi), annots=True)
    return _fit_ocr_image(image)


def _tesseract_with_image(fn, img, **kwargs):
    img = _fit_ocr_image(img)
    try:
        return fn(img, **kwargs)
    except Exception as exc:
        msg = str(exc)
        if "pixCreateHeader" in msg or "2^31" in msg or "pix not made" in msg:
            resample = getattr(getattr(Image, "Resampling", Image), "LANCZOS", Image.LANCZOS)
            width, height = img.size
            img = img.resize((max(1, width // 2), max(1, height // 2)), resample)
            return fn(img, **kwargs)
        raise


def _prepare_tesseract():
    tess_exe = find_tesseract()
    if not tess_exe:
        return None
    pytesseract.pytesseract.tesseract_cmd = tess_exe
    return tess_exe


def _ocr_words_from_image(img, lang="eng"):
    data = _tesseract_with_image(
        pytesseract.image_to_data, img, lang=lang, output_type=pytesseract.Output.DICT
    )
    words = []
    count = len(data.get("text") or [])
    for i in range(count):
        text = str(data["text"][i] or "").strip()
        if not text:
            continue
        try:
            conf = float(data["conf"][i])
        except (TypeError, ValueError):
            conf = -1.0
        if conf < 30:
            continue
        words.append({
            "text": text,
            "left": int(data["left"][i]),
            "top": int(data["top"][i]),
            "width": int(data["width"][i]),
            "height": int(data["height"][i]),
            "block": int(data.get("block_num", [0] * count)[i]),
            "par": int(data.get("par_num", [0] * count)[i]),
            "line": int(data.get("line_num", [0] * count)[i]),
        })
    return words


def _split_line_cells(words):
    words = sorted(words, key=lambda item: item["left"])
    if not words:
        return []
    heights = sorted(item["height"] for item in words)
    med_h = heights[len(heights) // 2] if heights else 12
    gaps = [
        words[i + 1]["left"] - (words[i]["left"] + words[i]["width"])
        for i in range(len(words) - 1)
    ]
    positive = sorted(gap for gap in gaps if gap > 0)
    intra = [gap for gap in positive if gap <= max(med_h, 14)]
    typical = intra[len(intra) // 2] if intra else max(4, int(med_h * 0.35))
    threshold = max(14, med_h * 1.15, typical * 3.0)

    cells = []
    current = [words[0]]
    for prev, word in zip(words, words[1:]):
        gap = word["left"] - (prev["left"] + prev["width"])
        if gap > threshold:
            cells.append({
                "left": current[0]["left"],
                "text": " ".join(item["text"] for item in current),
            })
            current = [word]
        else:
            current.append(word)
    cells.append({
        "left": current[0]["left"],
        "text": " ".join(item["text"] for item in current),
    })
    return cells


def _cluster_column_starts(lefts):
    if not lefts:
        return []
    lefts = sorted(lefts)
    spans = [lefts[i + 1] - lefts[i] for i in range(len(lefts) - 1)]
    positive = sorted(span for span in spans if span > 0)
    threshold = max(28, (positive[len(positive) // 2] * 0.6) if positive else 28)
    clusters = [[lefts[0]]]
    for value in lefts[1:]:
        if value - clusters[-1][-1] <= threshold:
            clusters[-1].append(value)
        else:
            clusters.append([value])
    return [sum(cluster) / len(cluster) for cluster in clusters]


def _table_from_words(words):
    grouped = {}
    for word in words:
        key = (word["block"], word["par"], word["line"])
        grouped.setdefault(key, []).append(word)
    line_rows = []
    for key in sorted(grouped, key=lambda item: (min(w["top"] for w in grouped[item]), item)):
        cells = _split_line_cells(grouped[key])
        if cells:
            line_rows.append(cells)
    starts = _cluster_column_starts([cell["left"] for row in line_rows for cell in row])
    if not starts:
        return [[cell["text"] for cell in row] for row in line_rows]
    table = []
    for row in line_rows:
        values = [""] * len(starts)
        for cell in row:
            idx = min(range(len(starts)), key=lambda i: abs(cell["left"] - starts[i]))
            values[idx] = (values[idx] + " " + cell["text"]).strip() if values[idx] else cell["text"]
        table.append(values)
    return table


def extract_ocr_text(active_doc, lang="eng", dpi=300):
    if not _prepare_tesseract():
        raise RuntimeError("Tesseract OCR engine not found.")
    parts = []
    for page_idx, page in enumerate(active_doc):
        img = _page_to_pil(page, dpi=dpi)
        text = _tesseract_with_image(pytesseract.image_to_string, img, lang=lang)
        parts.append(f"--- Page {page_idx + 1} ---\n{text}")
    return "\n\n".join(parts).strip()


def extract_ocr_table(active_doc, lang="eng", dpi=300):
    if not _prepare_tesseract():
        raise RuntimeError("Tesseract OCR engine not found.")
    rows = []
    for page_idx, page in enumerate(active_doc):
        img = _page_to_pil(page, dpi=dpi)
        words = _ocr_words_from_image(img, lang=lang)
        table = _table_from_words(words)
        if not table:
            text = _tesseract_with_image(pytesseract.image_to_string, img, lang=lang).strip()
            if text:
                for line in text.splitlines():
                    if line.strip():
                        rows.append([page_idx + 1, line.strip()])
            continue
        for line in table:
            rows.append([page_idx + 1] + line)
    return rows


def save_ocr_export(path, payload, mode="csv"):
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    if mode == "csv":
        rows = payload or []
        width = max((len(row) for row in rows), default=1)
        headers = ["Page"] + [f"Column {i}" for i in range(1, width)]
        with open(path, "w", encoding="utf-8-sig", newline="") as handle:
            writer = csv.writer(handle)
            writer.writerow(headers)
            for row in rows:
                writer.writerow(list(row) + [""] * (width - len(row)))
        return path
    with open(path, "w", encoding="utf-8") as handle:
        handle.write(payload or "")
    return path


def run_ocr_extraction(active_doc, params, preview_mode=False, output_dir=None, sidecar_stem=None):
    tess_exe = find_tesseract()
    if not tess_exe:
        if not preview_mode:
            messagebox.showerror("Missing Engine", "Tesseract OCR engine not found.")
        return active_doc

    pytesseract.pytesseract.tesseract_cmd = tess_exe
    if preview_mode:
        return active_doc

    mode = params.get("mode", "txt")
    lang = params.get("lang", "eng")
    next_doc = pdfdoc.open()
    payload = "" if mode != "csv" else []

    for page_idx, page in enumerate(active_doc):
        img = _page_to_pil(page, dpi=300)
        if mode == "pdf":
            pdf_bytes = _tesseract_with_image(
                pytesseract.image_to_pdf_or_hocr, img, extension="pdf", lang=lang
            )
            ocr_pdf = pdfdoc.open("pdf", pdf_bytes)
            next_doc.insert_pdf(ocr_pdf)
            ocr_pdf.close()
            continue

        if mode == "csv":
            words = _ocr_words_from_image(img, lang=lang)
            table = _table_from_words(words)
            if table:
                payload.extend([[page_idx + 1] + line for line in table])
            else:
                text = _tesseract_with_image(pytesseract.image_to_string, img, lang=lang).strip()
                for line in text.splitlines():
                    if line.strip():
                        payload.append([page_idx + 1, line.strip()])
        else:
            text = _tesseract_with_image(pytesseract.image_to_string, img, lang=lang)
            payload += f"--- Page {page_idx + 1} ---\n{text}\n\n"

        new_p = next_doc.new_page(width=page.rect.width, height=page.rect.height)
        show_source_page(new_p, new_p.rect, active_doc, page.number, keep_proportion=False)

    if mode in ("txt", "csv") and payload:
        dest = params.get("output_path")
        if not dest and output_dir:
            stem = sidecar_stem or "OCR_Extraction"
            dest = os.path.join(output_dir, f"{stem}.{mode}")
        if not dest:
            dest = filedialog.asksaveasfilename(
                title="Save OCR Extract",
                defaultextension=f".{mode}",
                initialfile=f"OCR_Extraction.{mode}",
                filetypes=[("CSV Files", "*.csv")] if mode == "csv" else [("Text Files", "*.txt")],
            )
        if dest:
            save_ocr_export(dest, payload, mode=mode)

    active_doc.close()
    return next_doc


