"""OCR hot-folder tab: three searchable-PDF pipelines."""

import os
import shutil
import tempfile
import threading
import time
from datetime import datetime
from email.message import EmailMessage
import mimetypes

import tkinter as tk
from tkinter import filedialog, messagebox, ttk

from modules.core.intake import IntakeError, ensure_output_writable, prepare_input
from modules.ocr.ocr import find_tesseract, write_searchable_pdf


PIPELINE_COUNT = 3
_OCR_EXTS = (".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff")
_DEFAULT_BODY = "Your {date} OCR batch has finished processing.\n\nThe searchable PDF files are attached to this draft."


class OcrMixin:
    def build_ocr_tab(self):
        tab = ttk.Frame(self.tab_content_frame, padding=15)
        self.tabs["OCR"] = tab
        self.ocr_email_lists = self._load_ocr_email_lists()
        self.ocr_is_watching = False
        saved = self.settings.get("ocr_pipelines") or []
        self.ocr_pipelines = []

        tk.Label(
            tab,
            text="Three OCR hot folders. Drop scans in a watch folder and this writes a searchable PDF at the original page size.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 9, "italic"),
            wraplength=520, justify="left",
        ).pack(anchor="w", pady=(0, 8))

        notebook = ttk.Notebook(tab)
        notebook.pack(fill="x", pady=(0, 8))
        for index in range(PIPELINE_COUNT):
            row = saved[index] if index < len(saved) and isinstance(saved[index], dict) else {}
            pipe = {
                "in": tk.StringVar(value=str(row.get("in") or "")),
                "out": tk.StringVar(value=str(row.get("out") or "")),
                "prefix": tk.StringVar(value=str(row.get("prefix") if row.get("prefix") is not None else "Searchable_OCR_")),
                "suffix": tk.StringVar(value=str(row.get("suffix") or "")),
                "post_action": tk.StringVar(value=str(row.get("post_action") or "Do nothing")),
                "email_list": tk.StringVar(value=str(row.get("email_list") or "")),
                "lang": tk.StringVar(value=str(row.get("lang") or "eng")),
                "recipients": str(row.get("recipients") or ""),
                "body": str(row.get("body") or _DEFAULT_BODY),
                "status": tk.StringVar(value="Idle"),
                "is_processing": False,
                "index": index,
                "email_frame": None,
                "email_to_box": None,
                "email_body_box": None,
                "email_combo": None,
            }
            self.ocr_pipelines.append(pipe)
            frame = ttk.Frame(notebook, padding=10)
            notebook.add(frame, text=f" Pipeline {index + 1} ")
            self._build_ocr_pipeline_form(frame, pipe)
            for key in ("in", "out", "prefix", "suffix", "post_action", "email_list", "lang"):
                pipe[key].trace_add("write", lambda *_a: self._save_ocr_pipelines())

        action = ttk.LabelFrame(tab, text="Engine", padding=10)
        action.pack(fill="x", pady=(0, 8))
        self.btn_ocr_watch = self._create_btn(
            action, "🔥 Start OCR Hot Folders", self.color_lime, self.color_navy, self.toggle_ocr_watch,
        )
        self.btn_ocr_watch.pack(fill="x", pady=(0, 6))
        for pipe in self.ocr_pipelines:
            line = tk.Frame(action, bg=self.color_white)
            line.pack(fill="x", pady=1)
            tk.Label(
                line, text=f"Pipeline {pipe['index'] + 1}:", width=12, anchor="w",
                bg=self.color_white, fg=self.color_navy, font=("Arial", 9, "bold"),
            ).pack(side="left")
            tk.Label(
                line, textvariable=pipe["status"], anchor="w",
                bg=self.color_white, fg=self.color_steel, font=("Arial", 9),
            ).pack(side="left")

        log_frame = ttk.LabelFrame(tab, text="Processing Log", padding=8)
        log_frame.pack(fill="both", expand=True)
        self.ocr_log = tk.Listbox(
            log_frame, height=5, bg=self.color_pale, fg=self.color_navy,
            font=("Arial", 9), relief="flat", highlightthickness=1,
        )
        self.ocr_log.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(log_frame, orient="vertical", command=self.ocr_log.yview)
        scroll.pack(side="right", fill="y")
        self.ocr_log.config(yscrollcommand=scroll.set)

        for pipe in self.ocr_pipelines:
            self._toggle_ocr_email_frame(pipe["index"])

    def _load_ocr_email_lists(self):
        stored = self.settings.get("ocr_email_lists")
        if isinstance(stored, dict) and stored:
            return dict(stored)
        other = os.path.join(os.environ.get("LOCALAPPDATA", ""), "ReadySetOCR", "settings.json")
        try:
            import json
            with open(other, encoding="utf-8") as handle:
                data = json.load(handle)
            lists = data.get("email_lists") or {}
            if isinstance(lists, dict):
                return dict(lists)
        except Exception:
            pass
        return {}

    def _build_ocr_pipeline_form(self, parent, pipe):
        def folder_row(label, variable):
            line = tk.Frame(parent, bg=self.color_white)
            line.pack(fill="x", pady=3)
            tk.Label(line, text=label, bg=self.color_white, fg=self.color_navy, width=16, anchor="w").pack(side="left")
            tk.Entry(line, textvariable=variable, bg=self.color_pale).pack(side="left", fill="x", expand=True, padx=5)
            self._create_btn(
                line, "Browse", self.color_mint, self.color_navy,
                lambda v=variable: v.set(filedialog.askdirectory() or v.get()),
                compact=True,
            ).pack(side="left")

        folder_row("Watch Folder:", pipe["in"])
        folder_row("Output Folder:", pipe["out"])

        naming = tk.Frame(parent, bg=self.color_white)
        naming.pack(fill="x", pady=3)
        tk.Label(naming, text="File Naming:", bg=self.color_white, fg=self.color_navy, width=16, anchor="w").pack(side="left")
        tk.Entry(naming, textvariable=pipe["prefix"], bg=self.color_pale, width=16).pack(side="left")
        tk.Label(naming, text="[Original Name]", fg=self.color_steel, bg=self.color_white, font=("Arial", 8, "italic")).pack(side="left", padx=4)
        tk.Entry(naming, textvariable=pipe["suffix"], bg=self.color_pale, width=10).pack(side="left")
        tk.Label(naming, text=".pdf", fg=self.color_steel, bg=self.color_white).pack(side="left", padx=2)

        lang_row = tk.Frame(parent, bg=self.color_white)
        lang_row.pack(fill="x", pady=3)
        tk.Label(lang_row, text="Language:", bg=self.color_white, fg=self.color_navy, width=16, anchor="w").pack(side="left")
        ttk.Combobox(
            lang_row, values=["eng", "spa", "fra", "deu"], textvariable=pipe["lang"],
            state="readonly", width=8,
        ).pack(side="left")

        action_row = tk.Frame(parent, bg=self.color_white)
        action_row.pack(fill="x", pady=6)
        tk.Label(action_row, text="After Processing:", bg=self.color_white, fg=self.color_navy, width=16, anchor="w").pack(side="left")
        ttk.Combobox(
            action_row,
            values=["Do nothing", "Open output folder", "Attach newly processed files to email"],
            textvariable=pipe["post_action"], state="readonly", width=38,
        ).pack(side="left", padx=4)

        email = ttk.LabelFrame(parent, text="Email Template", padding=10)
        pipe["email_frame"] = email
        drop = tk.Frame(email, bg=self.color_white)
        drop.pack(fill="x", pady=(0, 6))
        tk.Label(drop, text="Distribution List:", bg=self.color_white, fg=self.color_navy, font=("Arial", 9, "bold")).pack(side="left")
        combo = ttk.Combobox(drop, textvariable=pipe["email_list"], state="normal", width=24)
        combo["values"] = list(self.ocr_email_lists.keys())
        combo.pack(side="left", padx=5)
        combo.bind("<<ComboboxSelected>>", lambda _e, p=pipe: self._apply_ocr_email_list(p))
        pipe["email_combo"] = combo
        self._create_btn(
            drop, "Save List", self.color_steel, self.color_white,
            lambda p=pipe: self._save_ocr_email_list(p), compact=True,
        ).pack(side="left")

        tk.Label(email, text="Recipients (comma separated):", bg=self.color_white, fg=self.color_navy, font=("Arial", 9, "bold")).pack(anchor="w")
        to_box = tk.Text(email, height=3, bg=self.color_pale, fg=self.color_navy, font=("Arial", 9), relief="flat")
        to_box.pack(fill="x", pady=(2, 6))
        if pipe["recipients"]:
            to_box.insert("1.0", pipe["recipients"])
        to_box.bind("<KeyRelease>", lambda _e: self._save_ocr_pipelines())
        pipe["email_to_box"] = to_box

        tk.Label(email, text="Message body ({date} becomes today's date):", bg=self.color_white, fg=self.color_navy, font=("Arial", 9, "bold")).pack(anchor="w")
        body = tk.Text(email, height=3, bg=self.color_pale, fg=self.color_navy, font=("Arial", 9), relief="flat")
        body.pack(fill="x", pady=(2, 2))
        body.insert("1.0", pipe["body"] or _DEFAULT_BODY)
        body.bind("<KeyRelease>", lambda _e: self._save_ocr_pipelines())
        pipe["email_body_box"] = body
        pipe["post_action"].trace_add("write", lambda *_a, p=pipe: self._toggle_ocr_email_frame(p["index"]))

    def _ocr_pipe_snapshot(self, pipe):
        to_box = pipe.get("email_to_box")
        body_box = pipe.get("email_body_box")
        recipients = ""
        body = pipe.get("body") or _DEFAULT_BODY
        try:
            if to_box is not None and to_box.winfo_exists():
                recipients = to_box.get("1.0", "end-1c")
            if body_box is not None and body_box.winfo_exists():
                body = body_box.get("1.0", "end-1c")
        except Exception:
            pass
        return {
            "in": pipe["in"].get().strip(),
            "out": pipe["out"].get().strip(),
            "prefix": pipe["prefix"].get(),
            "suffix": pipe["suffix"].get(),
            "post_action": pipe["post_action"].get(),
            "email_list": pipe["email_list"].get().strip(),
            "lang": pipe["lang"].get() or "eng",
            "recipients": recipients,
            "body": body,
        }

    def _save_ocr_pipelines(self):
        pipes = getattr(self, "ocr_pipelines", None)
        if not pipes:
            return
        self.settings["ocr_pipelines"] = [self._ocr_pipe_snapshot(pipe) for pipe in pipes]
        self.settings["ocr_email_lists"] = dict(getattr(self, "ocr_email_lists", {}) or {})
        self.save_settings()

    def _toggle_ocr_email_frame(self, index):
        pipe = self.ocr_pipelines[index]
        frame = pipe.get("email_frame")
        if frame is None:
            return
        try:
            if pipe["post_action"].get() == "Attach newly processed files to email":
                frame.pack(fill="x", pady=(6, 0))
            else:
                frame.pack_forget()
        except Exception:
            pass

    def _apply_ocr_email_list(self, pipe):
        name = pipe["email_list"].get()
        if name in self.ocr_email_lists and pipe.get("email_to_box") is not None:
            pipe["email_to_box"].delete("1.0", tk.END)
            pipe["email_to_box"].insert("1.0", self.ocr_email_lists[name])
            self._save_ocr_pipelines()

    def _save_ocr_email_list(self, pipe):
        name = pipe["email_list"].get().strip()
        recipients = pipe["email_to_box"].get("1.0", "end-1c").strip() if pipe.get("email_to_box") else ""
        if not name:
            messagebox.showwarning("Missing Name", "Enter a name for this distribution list.")
            return
        if not recipients:
            messagebox.showwarning("Missing Recipients", "Enter at least one email address.")
            return
        self.ocr_email_lists[name] = recipients
        keys = list(self.ocr_email_lists.keys())
        for other in self.ocr_pipelines:
            combo = other.get("email_combo")
            if combo is not None:
                combo["values"] = keys
        self._save_ocr_pipelines()
        messagebox.showinfo("Saved", f"Distribution list '{name}' saved.")

    def _ocr_log(self, text):
        def _add():
            box = getattr(self, "ocr_log", None)
            if box is None:
                return
            try:
                if not box.winfo_exists():
                    return
                box.insert(tk.END, text)
                box.yview(tk.END)
            except Exception:
                pass
        self.root.after(0, _add)

    def _ocr_ready(self, pipe):
        return bool(pipe["in"].get().strip() and pipe["out"].get().strip())

    def toggle_ocr_watch(self):
        if self.ocr_is_watching:
            self.ocr_is_watching = False
            self.btn_ocr_watch.config(text="🔥 Start OCR Hot Folders", bg=self.color_lime, fg=self.color_navy)
            self.remove_bg_task("🔥 OCR Hot Folders (Listening...)")
            for pipe in self.ocr_pipelines:
                if not pipe["is_processing"]:
                    pipe["status"].set("Stopped")
            return
        import licensing
        from license_dialog import open_license_dialog
        state = getattr(self, "license_state", None) or licensing.load_state()
        if not licensing.allows_multiple_files(state):
            messagebox.showinfo("Free", "OCR hot folders are part of Pro.", parent=self.root)
            open_license_dialog(self)
            return
        ready = [pipe for pipe in self.ocr_pipelines if self._ocr_ready(pipe)]
        if not ready:
            messagebox.showwarning("Missing Info", "Set the watch folder and output folder on at least one pipeline.")
            return
        if not find_tesseract():
            messagebox.showerror("Missing Engine", "Tesseract OCR engine not found.")
            return
        self.ocr_is_watching = True
        self.btn_ocr_watch.config(text="⏹ Stop OCR Hot Folders", bg=self.color_steel, fg=self.color_white)
        self.add_bg_task("🔥 OCR Hot Folders (Listening...)")
        for pipe in self.ocr_pipelines:
            pipe["status"].set("Listening..." if self._ocr_ready(pipe) else "Not configured")
        self._poll_ocr_folders()

    def _poll_ocr_folders(self):
        if not self.ocr_is_watching:
            return
        for pipe in self.ocr_pipelines:
            if pipe["is_processing"] or not self._ocr_ready(pipe):
                continue
            in_dir = pipe["in"].get().strip()
            if not os.path.isdir(in_dir):
                continue
            try:
                names = os.listdir(in_dir)
            except OSError as exc:
                self._ocr_log(f"Could not open {in_dir} ({exc})")
                continue
            files = [name for name in names if name.lower().endswith(_OCR_EXTS)]
            if not files:
                continue
            snap = self._ocr_pipe_snapshot(pipe)
            pipe["is_processing"] = True
            pipe["status"].set("Processing...")
            threading.Thread(target=self._ocr_process_batch, args=(pipe, snap, files), daemon=True).start()
        self.root.after(5000, self._poll_ocr_folders)

    def _ocr_process_batch(self, pipe, snap, files):
        in_dir = snap["in"]
        out_dir = snap["out"]
        outputs = []
        try:
            try:
                ensure_output_writable(out_dir)
            except IntakeError as exc:
                self._ocr_log(str(exc))
                return
            done_dir = os.path.join(in_dir, "Processed_Originals")
            try:
                os.makedirs(done_dir, exist_ok=True)
            except OSError as exc:
                self._ocr_log(f"Could not open {done_dir} ({exc})")
                return
            for fname in files:
                if not self.ocr_is_watching:
                    break
                self.root.after(0, lambda n=fname, p=pipe: p["status"].set(f"OCR: {n}"))
                src = os.path.join(in_dir, fname)
                base = os.path.splitext(fname)[0]
                out_name = f"{snap['prefix']}{base}{snap['suffix']}.pdf"
                out_path = os.path.join(out_dir, out_name)
                try:
                    ready = prepare_input(src)
                    write_searchable_pdf(ready, out_path, lang=snap["lang"])
                    dest = os.path.join(done_dir, fname)
                    if os.path.exists(dest):
                        os.remove(dest)
                    shutil.move(src, dest)
                    outputs.append(out_path)
                    stamp = datetime.now().strftime("%H:%M:%S")
                    self._ocr_log(f"[{stamp}] [P{pipe['index'] + 1}] {out_name}")
                except Exception as exc:
                    print(f"Failed to OCR {fname}: {exc}")
                    stamp = datetime.now().strftime("%H:%M:%S")
                    self._ocr_log(f"[{stamp}] [P{pipe['index'] + 1}] ERROR: {fname}")
            if outputs and self.ocr_is_watching:
                action = snap["post_action"]
                if action == "Open output folder" and os.name == "nt":
                    os.startfile(out_dir)
                elif action == "Attach newly processed files to email":
                    self._ocr_email_draft(pipe["index"], snap, outputs)
        finally:
            pipe["is_processing"] = False
            def _idle():
                if self.ocr_is_watching and self._ocr_ready(pipe):
                    pipe["status"].set("Listening...")
                else:
                    pipe["status"].set("Idle")
            self.root.after(0, _idle)

    def _ocr_email_draft(self, index, snap, file_paths):
        try:
            msg = EmailMessage()
            today = datetime.now().strftime("%B %d, %Y")
            msg["Subject"] = f"ReadySetPDF OCR {today}"
            msg["X-Unsent"] = "1"
            msg["To"] = snap.get("recipients") or ""
            msg.set_content((snap.get("body") or "").replace("{date}", today))
            for path in file_paths:
                if not os.path.exists(path):
                    continue
                ctype = mimetypes.guess_type(path)[0] or "application/pdf"
                maintype, subtype = ctype.split("/", 1)
                with open(path, "rb") as handle:
                    msg.add_attachment(
                        handle.read(), maintype=maintype, subtype=subtype,
                        filename=os.path.basename(path),
                    )
            eml_path = os.path.join(tempfile.gettempdir(), f"OCR_Batch_Draft_P{index + 1}_{int(time.time())}.eml")
            with open(eml_path, "wb") as handle:
                handle.write(bytes(msg))
            if os.name == "nt":
                os.startfile(eml_path)
        except Exception as exc:
            print(f"Failed to create email draft for OCR pipeline {index + 1}: {exc}")
            self._ocr_log(f"Email draft failed on pipeline {index + 1}")
