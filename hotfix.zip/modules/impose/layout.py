"""Monkey / Grid / Booklet / Folds helpers extracted from engine.py."""

import pdfdoc

from modules.core.pageops import show_source_page


ANCHOR_POINTS = {
    "nw": (0.0, 0.0), "n": (0.5, 0.0), "ne": (1.0, 0.0),
    "w": (0.0, 0.5), "c": (0.5, 0.5), "e": (1.0, 0.5),
    "sw": (0.0, 1.0), "s": (0.5, 1.0), "se": (1.0, 1.0),
}

_ANCHOR_ALIASES = {
    "top left": "nw", "top-left": "nw", "topleft": "nw",
    "top center": "n", "top-center": "n", "topcentre": "n", "top": "n",
    "top right": "ne", "top-right": "ne", "topright": "ne",
    "center left": "w", "centre left": "w", "left": "w", "middle left": "w",
    "center": "c", "centre": "c", "middle": "c",
    "center right": "e", "centre right": "e", "right": "e", "middle right": "e",
    "bottom left": "sw", "bottom-left": "sw", "bottomleft": "sw",
    "bottom center": "s", "bottom-center": "s", "bottomcentre": "s", "bottom": "s",
    "bottom right": "se", "bottom-right": "se", "bottomright": "se",
}


def normalize_anchor(value, center=None):
    key = str(value or "").strip().lower()
    if key in ANCHOR_POINTS:
        return key
    if key in _ANCHOR_ALIASES:
        return _ANCHOR_ALIASES[key]
    if center is False:
        return "nw"
    return "c"


def duplex_flip_axes(sheet_w, sheet_h, flip_edge):
    """Which axes reverse on the back when the sheet is flipped on that edge.

    Long-edge duplex on a portrait sheet mirrors left/right (columns).
    Long-edge on landscape mirrors top/bottom (rows). Short-edge is the opposite.
    """
    long_is_horizontal = float(sheet_w) >= float(sheet_h)
    want_long = str(flip_edge or "long").strip().lower().startswith("long")
    if want_long:
        return (not long_is_horizontal, long_is_horizontal)
    return (long_is_horizontal, not long_is_horizontal)


def mirror_anchor(anchor, sheet_w, sheet_h, flip_edge, even_sheet=False):
    key = normalize_anchor(anchor)
    if not even_sheet:
        return key
    mirror_h, mirror_v = duplex_flip_axes(sheet_w, sheet_h, flip_edge)
    ax, ay = ANCHOR_POINTS[key]
    if mirror_h:
        ax = 1.0 - ax
    if mirror_v:
        ay = 1.0 - ay
    for name, pair in ANCHOR_POINTS.items():
        if abs(pair[0] - ax) < 0.01 and abs(pair[1] - ay) < 0.01:
            return name
    return key


def duplex_cell(idx, cols, rows, sheet_w, sheet_h, flip_edge, even_sheet=False):
    r, c = divmod(int(idx), int(cols))
    if even_sheet:
        mirror_h, mirror_v = duplex_flip_axes(sheet_w, sheet_h, flip_edge)
        if mirror_h:
            c = int(cols) - 1 - c
        if mirror_v:
            r = int(rows) - 1 - r
    return r, c


def anchored_origin(sheet_w, sheet_h, block_w, block_h, margin_x, margin_y, anchor):
    """Top-left of the n-up block. Margins are offsets from the chosen anchor."""
    ax, ay = ANCHOR_POINTS[normalize_anchor(anchor)]
    leftover_x = float(sheet_w) - float(block_w)
    leftover_y = float(sheet_h) - float(block_h)
    if ax < 0.25:
        start_x = float(margin_x)
    elif ax > 0.75:
        start_x = leftover_x - float(margin_x)
    else:
        start_x = leftover_x / 2.0 + float(margin_x)
    if ay < 0.25:
        start_y = float(margin_y)
    elif ay > 0.75:
        start_y = leftover_y - float(margin_y)
    else:
        start_y = leftover_y / 2.0 + float(margin_y)
    return start_x, start_y


def fitted_dest_rect(dest_rect, src_w, src_h, keep_proportion):
    dest = pdfdoc.Rect(dest_rect)
    if not keep_proportion or src_w <= 0.5 or src_h <= 0.5 or dest.width <= 0.5 or dest.height <= 0.5:
        return dest
    scale = min(dest.width / float(src_w), dest.height / float(src_h))
    fw, fh = float(src_w) * scale, float(src_h) * scale
    x0 = dest.x0 + (dest.width - fw) / 2.0
    y0 = dest.y0 + (dest.height - fh) / 2.0
    return pdfdoc.Rect(x0, y0, x0 + fw, y0 + fh)


def resolve_source_trim_rect(page, trim_w_pt=0.0, trim_h_pt=0.0, art_has_bleed=False):
    """Finished trim on the source page. Bleed stays; marks follow this rectangle."""
    page_rect = pdfdoc.Rect(page.rect)
    if not art_has_bleed:
        return page_rect
    tw = float(trim_w_pt or 0.0)
    th = float(trim_h_pt or 0.0)
    if tw >= 2.0 and th >= 2.0:
        tw = min(tw, page_rect.width)
        th = min(th, page_rect.height)
        x0 = page_rect.x0 + (page_rect.width - tw) / 2.0
        y0 = page_rect.y0 + (page_rect.height - th) / 2.0
        return pdfdoc.Rect(x0, y0, x0 + tw, y0 + th)
    try:
        tb = pdfdoc.Rect(page.trimbox)
        if tb.width >= 2.0 and tb.height >= 2.0:
            if tb.width < page_rect.width - 0.5 or tb.height < page_rect.height - 0.5:
                return tb
    except Exception:
        pass
    return page_rect


def map_src_rect_to_dest(src_page_rect, src_sub, dest_placed):
    src = pdfdoc.Rect(src_page_rect)
    sub = pdfdoc.Rect(src_sub)
    dest = pdfdoc.Rect(dest_placed)
    if src.width < 0.5 or src.height < 0.5:
        return dest
    sx = dest.width / src.width
    sy = dest.height / src.height
    return pdfdoc.Rect(
        dest.x0 + (sub.x0 - src.x0) * sx,
        dest.y0 + (sub.y0 - src.y0) * sy,
        dest.x0 + (sub.x1 - src.x0) * sx,
        dest.y0 + (sub.y1 - src.y0) * sy,
    )


def placed_trim_rect(page, dest_rect, keep_proportion, trim_w_pt=0.0, trim_h_pt=0.0, art_has_bleed=False):
    src_rect = pdfdoc.Rect(page.rect)
    placed = fitted_dest_rect(dest_rect, src_rect.width, src_rect.height, keep_proportion)
    trim_src = resolve_source_trim_rect(page, trim_w_pt, trim_h_pt, art_has_bleed)
    return map_src_rect_to_dest(src_rect, trim_src, placed)


def source_layout_size(page, trim_w_pt=0.0, trim_h_pt=0.0, art_has_bleed=False):
    """(step_w, step_h, page_w, page_h). step is trim when artwork already has bleed."""
    page_rect = pdfdoc.Rect(page.rect)
    pw, ph = page_rect.width, page_rect.height
    if not art_has_bleed:
        return pw, ph, pw, ph
    trim = resolve_source_trim_rect(page, trim_w_pt, trim_h_pt, True)
    return max(trim.width, 1.0), max(trim.height, 1.0), pw, ph


def nup_dest_on_slot(page, slot, trim_w_pt, trim_h_pt, art_has_bleed, autoscale, maintain_aspect):
    """Place a source page on a layout slot.

    Without bleed the slot is the full page cell. With Source Trim the slot is
    the finished trim: gutters sit between trims, bleed hangs into the gutter
    (and can overlap a neighbor when gutter is smaller than 2× bleed).
    """
    slot = pdfdoc.Rect(slot)
    src = pdfdoc.Rect(page.rect)
    pw, ph = src.width, src.height
    if not art_has_bleed:
        if autoscale:
            return fitted_dest_rect(slot, pw, ph, maintain_aspect)
        return pdfdoc.Rect(slot.x0, slot.y0, slot.x0 + pw, slot.y0 + ph)
    trim = resolve_source_trim_rect(page, trim_w_pt, trim_h_pt, True)
    tw, th = max(trim.width, 1.0), max(trim.height, 1.0)
    if autoscale and slot.width > 0.5 and slot.height > 0.5:
        if maintain_aspect:
            s = min(slot.width / tw, slot.height / th)
            sx = sy = s
        else:
            sx, sy = slot.width / tw, slot.height / th
        trim_dw, trim_dh = tw * sx, th * sy
        ox = slot.x0 + (slot.width - trim_dw) / 2.0
        oy = slot.y0 + (slot.height - trim_dh) / 2.0
        pad_x = (trim.x0 - src.x0) * sx
        pad_y = (trim.y0 - src.y0) * sy
        return pdfdoc.Rect(ox - pad_x, oy - pad_y, ox - pad_x + pw * sx, oy - pad_y + ph * sy)
    pad_x = trim.x0 - src.x0
    pad_y = trim.y0 - src.y0
    return pdfdoc.Rect(slot.x0 - pad_x, slot.y0 - pad_y, slot.x0 - pad_x + pw, slot.y0 - pad_y + ph)


def build_impose_sheets(page_count, cells_per_sheet, repeat=1, order="Sequential", double_sided=False):
    """Build output sheets as (page_index_list, is_back).

    Sequential: pages run in order (repeat copies of each). Double sided uses
    even indices as fronts and odd indices as matching backs on the next sheet.
    Step and Repeat: each page fills a sheet (or `repeat` copies). Double sided
    pairs page N (front) with page N+1 (back).
    """
    try:
        repeat = max(1, int(repeat))
    except (TypeError, ValueError):
        repeat = 1
    cells = max(1, int(cells_per_sheet or 1))
    page_count = max(0, int(page_count or 0))
    step = str(order or "").lower().startswith("step")
    sheets = []
    if page_count <= 0:
        return sheets
    if not double_sided:
        seq = []
        for i in range(page_count):
            copies = cells if step and repeat <= 1 else repeat
            seq.extend([i] * copies)
        for i in range(0, len(seq), cells):
            sheets.append((seq[i:i + cells], False))
        return sheets
    if step:
        copies = cells if repeat <= 1 else repeat
        for i in range(0, page_count, 2):
            sheets.append(([i] * copies, False))
            if i + 1 < page_count:
                sheets.append(([i + 1] * copies, True))
        return sheets
    fronts = list(range(0, page_count, 2))
    fseq, bseq = [], []
    for f in fronts:
        fseq.extend([f] * repeat)
        bseq.extend([(f + 1) if (f + 1) < page_count else None] * repeat)
    for i in range(0, len(fseq), cells):
        sheets.append((fseq[i:i + cells], False))
        back_chunk = bseq[i:i + cells]
        if any(p is not None for p in back_chunk):
            sheets.append((back_chunk, True))
    return sheets


def crop_mark_inset(m_dist, overlap=0.0):
    """Distance from trim to the inner end of a crop mark.

    Gap (m_dist) is the control: positive keeps a space off the trim; negative
    crosses into live. overlap is only honored for older recipes that stored it.
    """
    return float(m_dist or 0.0) - float(overlap or 0.0)


def booklet_creep_shift(creep_per_sheet, sheet_num, creep_dir="Outward", center_gutter=0.0):
    """Spine offset for one signature.

    creep_per_sheet is paper thickness, applied again on each inner sheet.
    Cover (sheet 0) is 0; sheet N shifts by N × thickness.
    """
    creep_step = float(creep_per_sheet or 0.0) * max(0, int(sheet_num))
    half_gutter = float(center_gutter or 0.0) / 2.0
    if str(creep_dir or "Outward") == "Inward":
        return half_gutter + creep_step
    return half_gutter - creep_step


def place_booklet_leaf(dest_page, src_doc, src_index, tgt, src_clip, spine_x, is_left, sheet_w, sheet_h, clip_spine=True):
    """Place one booklet page. Spine clip is off when bleed may overlap a neighbor."""
    src_clip = pdfdoc.Rect(src_clip)
    tgt = pdfdoc.Rect(tgt)
    if tgt.x0 < 0:
        d = -tgt.x0
        tgt.x0 += d
        src_clip.x0 += d
    if tgt.x1 > sheet_w:
        d = tgt.x1 - sheet_w
        tgt.x1 -= d
        src_clip.x1 -= d
    if tgt.y0 < 0:
        d = -tgt.y0
        tgt.y0 += d
        src_clip.y0 += d
    if tgt.y1 > sheet_h:
        d = tgt.y1 - sheet_h
        tgt.y1 -= d
        src_clip.y1 -= d
    if clip_spine:
        if is_left and tgt.x1 > spine_x + 0.01:
            d = tgt.x1 - spine_x
            tgt.x1 -= d
            src_clip.x1 -= d
        if (not is_left) and tgt.x0 < spine_x - 0.01:
            d = spine_x - tgt.x0
            tgt.x0 += d
            src_clip.x0 += d
    if tgt.width > 0.5 and tgt.height > 0.5 and src_clip.width > 0.5 and src_clip.height > 0.5:
        show_source_page(dest_page, tgt, src_doc, src_index, keep_proportion=False, clip=src_clip)
    return tgt, src_clip


def draw_perimeter_crop_marks(page, cut_xs, cut_ys, grid_x0, grid_y0, grid_x1, grid_y1, sheet_w, sheet_h, m_dist, m_thick, overlap=0.0, color=(0, 0, 0)):
    if not cut_xs or not cut_ys:
        return
    inset = crop_mark_inset(m_dist, overlap)
    rgb = tuple(color) if color is not None else (0, 0, 0)
    for cx in cut_xs:
        page.draw_line(pdfdoc.Point(cx, grid_y0 - inset), pdfdoc.Point(cx, 0), color=rgb, width=m_thick)
        page.draw_line(pdfdoc.Point(cx, grid_y1 + inset), pdfdoc.Point(cx, sheet_h), color=rgb, width=m_thick)
    for cy in cut_ys:
        page.draw_line(pdfdoc.Point(grid_x0 - inset, cy), pdfdoc.Point(0, cy), color=rgb, width=m_thick)
        page.draw_line(pdfdoc.Point(grid_x1 + inset, cy), pdfdoc.Point(sheet_w, cy), color=rgb, width=m_thick)


FOLD_NEST_PT = 4.5  # 1/16" compensation so tucked panels fit

FOLD_TYPES = (
    ("half", "Single (half) Fold", "Two equal panels. Four faces: 2 front + 2 back."),
    ("zfold", "Z Fold", "Three equal panels that accordion in a Z."),
    ("gate", "Single Gate Fold", "Left and right flaps meet at the center (1/4 + 1/2 + 1/4)."),
    ("roll", "Roll (Barrel) Fold", "Outside two panels largest; from the 3rd each is 1/16\" smaller."),
    ("half_tri", "Half Fold & Tri Fold", "Fold in half, then tri-fold the other way (2 × 3 grid)."),
    ("trifold", "Tri-fold Brochure", "Three panels; the right panel is 1/16\" smaller so it tucks."),
    ("double_parallel", "Double Parallel", "Half, then half again the same way. Last two panels 1/16\" smaller."),
    ("double_gate", "Double Gate Fold", "Gate fold, then fold at the center. End panels 1/16\" smaller."),
    ("french", "Right Angle (French) Fold", "Half in one direction, then half the other (equal 2 × 2)."),
    ("accordion", "Accordion (M) Fold", "Three zigzag folds, four equal panels per side."),
)


def _fold_parts_equal(total, count):
    width = total / float(count)
    return [width] * count


def _fold_parts_tuck_last(total, count, delta):
    largest = (total + delta) / float(count)
    parts = [largest] * (count - 1) + [largest - delta]
    if min(parts) <= 1.0:
        return _fold_parts_equal(total, count)
    return parts


def _fold_parts_roll(total, count, delta):
    extras = (count - 2) * (count - 1) / 2.0
    largest = (total + delta * extras) / float(count)
    parts = [largest, largest]
    for step in range(1, count - 1):
        parts.append(largest - step * delta)
    if min(parts) <= 1.0:
        return _fold_parts_equal(total, count)
    return parts


def _fold_parts_last_half_smaller(total, count, delta):
    small_n = max(1, count // 2)
    large_n = count - small_n
    largest = (total + small_n * delta) / float(count)
    parts = [largest] * large_n + [largest - delta] * small_n
    if min(parts) <= 1.0:
        return _fold_parts_equal(total, count)
    return parts


def _fold_parts_double_gate(total, delta):
    largest = (total + 2 * delta) / 4.0
    parts = [largest - delta, largest, largest, largest - delta]
    if min(parts) <= 1.0:
        return _fold_parts_equal(total, 4)
    return parts


def _rects_from_widths(x0, y0, heights_or_width, parts, vertical=True):
    rects = []
    cursor = x0 if vertical else y0
    for part in parts:
        if vertical:
            rects.append(pdfdoc.Rect(cursor, y0, cursor + part, y0 + heights_or_width))
            cursor += part
        else:
            rects.append(pdfdoc.Rect(x0, cursor, x0 + heights_or_width, cursor + part))
            cursor += part
    return rects


def compute_fold_layout(fold_key, trim_w, trim_h, bleed=0.0, fold_along="width", nest_pt=FOLD_NEST_PT):
    """Return bleed/trim boxes, panel rects, and fold lines on the die sheet.

    Origin is top-left of the sheet (trim plus bleed on all sides). Fold lines
    sit on the trim; bleeds stay outside so artwork can print off the cut.
    """
    trim_w = max(float(trim_w), 2.0)
    trim_h = max(float(trim_h), 2.0)
    bleed = max(float(bleed or 0.0), 0.0)
    nest = max(float(nest_pt or 0.0), 0.0)
    sheet_w = trim_w + 2 * bleed
    sheet_h = trim_h + 2 * bleed
    tx0, ty0 = bleed, bleed
    trim = pdfdoc.Rect(tx0, ty0, tx0 + trim_w, ty0 + trim_h)
    along_width = (fold_along or "width") != "height"
    key = fold_key or "trifold"

    panels = []
    fold_lines = []

    def v_folds(widths):
        x = tx0
        rects = _rects_from_widths(tx0, ty0, trim_h, widths, vertical=True)
        for i, part in enumerate(widths[:-1]):
            x += part
            fold_lines.append((x, ty0, x, ty0 + trim_h))
        return rects

    def h_folds(heights):
        y = ty0
        rects = _rects_from_widths(tx0, ty0, trim_w, heights, vertical=False)
        for i, part in enumerate(heights[:-1]):
            y += part
            fold_lines.append((tx0, y, tx0 + trim_w, y))
        return rects

    if key == "half":
        span = trim_w if along_width else trim_h
        parts = _fold_parts_equal(span, 2)
        panels = v_folds(parts) if along_width else h_folds(parts)
    elif key == "zfold":
        span = trim_w if along_width else trim_h
        parts = _fold_parts_equal(span, 3)
        panels = v_folds(parts) if along_width else h_folds(parts)
    elif key == "gate":
        span = trim_w if along_width else trim_h
        parts = [span / 4.0, span / 2.0, span / 4.0]
        panels = v_folds(parts) if along_width else h_folds(parts)
    elif key == "roll":
        span = trim_w if along_width else trim_h
        parts = _fold_parts_roll(span, 4, nest)
        panels = v_folds(parts) if along_width else h_folds(parts)
    elif key == "trifold":
        span = trim_w if along_width else trim_h
        parts = _fold_parts_tuck_last(span, 3, nest)
        panels = v_folds(parts) if along_width else h_folds(parts)
    elif key == "double_parallel":
        span = trim_w if along_width else trim_h
        parts = _fold_parts_last_half_smaller(span, 4, nest)
        panels = v_folds(parts) if along_width else h_folds(parts)
    elif key == "double_gate":
        span = trim_w if along_width else trim_h
        parts = _fold_parts_double_gate(span, nest)
        panels = v_folds(parts) if along_width else h_folds(parts)
    elif key == "accordion":
        span = trim_w if along_width else trim_h
        parts = _fold_parts_equal(span, 4)
        panels = v_folds(parts) if along_width else h_folds(parts)
    elif key == "french":
        cols = _fold_parts_equal(trim_w, 2)
        rows = _fold_parts_equal(trim_h, 2)
        for row_i, rh in enumerate(rows):
            y = ty0 + sum(rows[:row_i])
            for col_i, cw in enumerate(cols):
                x = tx0 + sum(cols[:col_i])
                panels.append(pdfdoc.Rect(x, y, x + cw, y + rh))
        fold_lines.append((tx0 + cols[0], ty0, tx0 + cols[0], ty0 + trim_h))
        fold_lines.append((tx0, ty0 + rows[0], tx0 + trim_w, ty0 + rows[0]))
        parts = cols
    elif key == "half_tri":
        if along_width:
            cols = _fold_parts_tuck_last(trim_w, 3, nest)
            rows = _fold_parts_equal(trim_h, 2)
        else:
            cols = _fold_parts_equal(trim_w, 2)
            rows = _fold_parts_tuck_last(trim_h, 3, nest)
        for row_i, rh in enumerate(rows):
            y = ty0 + sum(rows[:row_i])
            for col_i, cw in enumerate(cols):
                x = tx0 + sum(cols[:col_i])
                panels.append(pdfdoc.Rect(x, y, x + cw, y + rh))
        x = tx0
        for part in cols[:-1]:
            x += part
            fold_lines.append((x, ty0, x, ty0 + trim_h))
        y = ty0
        for part in rows[:-1]:
            y += part
            fold_lines.append((tx0, y, tx0 + trim_w, y))
        parts = cols if along_width else rows
    else:
        span = trim_w if along_width else trim_h
        parts = _fold_parts_equal(span, 3)
        panels = v_folds(parts) if along_width else h_folds(parts)

    labels = []
    for idx, rect in enumerate(panels, start=1):
        labels.append({"rect": rect, "text": f"P{idx}"})

    return {
        "fold_key": key,
        "sheet_w": sheet_w,
        "sheet_h": sheet_h,
        "trim_w": trim_w,
        "trim_h": trim_h,
        "bleed": bleed,
        "trim": trim,
        "bleed_rect": pdfdoc.Rect(0, 0, sheet_w, sheet_h),
        "panels": panels,
        "fold_lines": fold_lines,
        "labels": labels,
        "parts": parts,
        "along_width": along_width,
    }


def draw_fold_dielines(page, layout, draw_labels=True):
    """Stroke bleed, trim, and fold guides onto a proof page (not a production PDF)."""
    trim = layout["trim"]
    bleed = layout["bleed"]
    magenta = (1, 0, 1)
    cyan = (0, 1, 1)
    fold_color = (0, 0.45, 0)
    page.draw_rect(layout["bleed_rect"], color=magenta, width=0.6)
    page.draw_rect(trim, color=cyan, width=0.75)
    if bleed > 0.5:
        mark = min(18.0, bleed * 0.85)
        corners = (
            (trim.x0, trim.y0, -1, -1),
            (trim.x1, trim.y0, 1, -1),
            (trim.x0, trim.y1, -1, 1),
            (trim.x1, trim.y1, 1, 1),
        )
        for x, y, sx, sy in corners:
            page.draw_line(pdfdoc.Point(x, y), pdfdoc.Point(x + sx * mark, y), color=magenta, width=0.5)
            page.draw_line(pdfdoc.Point(x, y), pdfdoc.Point(x, y + sy * mark), color=magenta, width=0.5)
    for x1, y1, x2, y2 in layout["fold_lines"]:
        page.draw_line(pdfdoc.Point(x1, y1), pdfdoc.Point(x2, y2), color=fold_color, width=0.6, dashes="[3 2]")
    if draw_labels:
        for item in layout["labels"]:
            rect = item["rect"]
            page.insert_text(
                pdfdoc.Point(rect.x0 + 4, rect.y0 + 12),
                item["text"],
                fontsize=8,
                color=(0.35, 0.35, 0.35),
                fontname="helv",
            )
    return page


def build_fold_proof_doc(layout, title=""):
    """One-page die-line proof at trim + bleed. No production content."""
    doc = pdfdoc.open()
    page = doc.new_page(width=layout["sheet_w"], height=layout["sheet_h"])
    page.draw_rect(page.rect, color=(1, 1, 1), fill=(1, 1, 1))
    draw_fold_dielines(page, layout, draw_labels=True)
    if title:
        page.insert_text(
            pdfdoc.Point(layout["bleed"] + 4, 10 if layout["bleed"] >= 12 else layout["trim"].y0 - 2),
            title,
            fontsize=7,
            color=(0.4, 0.4, 0.4),
            fontname="helv",
        )
    return doc


