"""VDP mail merge / stamp helpers extracted from engine.py."""

import os
import csv
import io
import html
import zipfile
import xml.etree.ElementTree as ET
import glob

import pdfdoc
from pdfgeom import Point, Rect

try:
    import qrcode
    QR_AVAILABLE = True
except ImportError:
    QR_AVAILABLE = False

def row_has_merge_data(row, mapped_columns=None):
    if not row:
        return False
    if mapped_columns:
        for col in mapped_columns:
            if col and str(row.get(col, "") or "").strip():
                return True
        return False
    return any(str(v or "").strip() for v in row.values())


def mapped_merge_columns(fields):
    cols = []
    for field in fields or []:
        source_type = field.get("source_type", "column")
        if source_type == "column" and field.get("column"):
            cols.append(field.get("column"))
        elif source_type == "address_block":
            for line in (field.get("block") or {}).get("lines", []):
                cols.extend([c for c in line.get("fields", []) if c])
                for key in ("city", "state", "zip"):
                    if line.get(key):
                        cols.append(line[key])
    return cols


ADDRESS_BLOCK_FIELD_COUNT = 4


def guess_address_columns(headers):
    normalized = [(h, h.lower().replace("_", " ").strip()) for h in (headers or [])]
    used = set()

    def pick(exact=(), contains=(), avoid=()):
        for header, name in normalized:
            if header in used:
                continue
            if name in exact:
                used.add(header)
                return header
        for header, name in normalized:
            if header in used:
                continue
            if any(token in name for token in avoid):
                continue
            if any(token in name for token in contains):
                used.add(header)
                return header
        return ""

    name = pick(contains=("last or business", "full name", "recipient", "contact", "naam"))
    if not name:
        name = pick(contains=("name", "naam"), avoid=("company", "business"))
    if not name:
        name = pick(contains=("name", "naam"))
    company = pick(exact=("business name", "company"), contains=("company", "business name", "organization"))
    line1 = pick(exact=("address 1", "address1", "street", "adres"), contains=("mailing line 1", "addr 1", "address", "adres", "straat"), avoid=("address 2", "addr 2", "line 2"))
    line2 = pick(
        exact=("address 2", "address2", "print postcode woonplaats"),
        contains=("mailing line 2", "addr 2", "suite", "apt", "woonplaats", "postcode woonplaats"),
    )
    stacked = [col for col in (name, company, line1, line2) if col]
    while len(stacked) < ADDRESS_BLOCK_FIELD_COUNT:
        stacked.append("")
    land = pick(exact=("land", "country"), contains=("land", "country"))
    if land and not stacked[-1]:
        stacked[-1] = land
    return {
        "fields": stacked[:ADDRESS_BLOCK_FIELD_COUNT],
        "city": pick(exact=("city", "woonplaats"), contains=("city", "woonplaats")),
        "state": pick(exact=("state", "st"), contains=("state", "province")),
        "zip": pick(exact=("zip", "zipcode", "zip code", "postcode"), contains=("zip", "postal", "postcode")),
    }


def normalize_address_map(picks, field_count=ADDRESS_BLOCK_FIELD_COUNT):
    picks = dict(picks or {})
    if isinstance(picks.get("fields"), list):
        stacked = list(picks.get("fields") or [])
    else:
        stacked = [picks.get("name", ""), picks.get("line1", ""), picks.get("line2", "")]
    stacked = [str(col or "").strip() for col in stacked]
    while len(stacked) < field_count:
        stacked.append("")
    return {
        "fields": stacked[:field_count],
        "city": str(picks.get("city", "") or "").strip(),
        "state": str(picks.get("state", "") or "").strip(),
        "zip": str(picks.get("zip", "") or "").strip(),
    }


def format_city_state_zip(city="", state="", zip_code=""):
    city = str(city or "").strip()
    state = str(state or "").strip()
    zip_code = str(zip_code or "").strip()
    if city and state:
        local = f"{city}, {state}"
    else:
        local = city or state
    if local and zip_code:
        return f"{local}  {zip_code}"
    return local or zip_code


def format_address_block(row, block):
    lines = []
    row = row or {}
    for spec in (block or {}).get("lines", []):
        kind = spec.get("kind", "fields")
        if kind == "city_state_zip":
            line = format_city_state_zip(
                row.get(spec.get("city", ""), ""),
                row.get(spec.get("state", ""), ""),
                row.get(spec.get("zip", ""), ""),
            )
        else:
            joiner = spec.get("join", " ")
            parts = [str(row.get(col, "") or "").strip() for col in spec.get("fields", []) if col]
            line = joiner.join(part for part in parts if part)
        if line:
            lines.append(line)
    return "\n".join(lines)


def build_address_block_spec(fields=None, city="", state="", zip_code="", name="", line1="", line2=""):
    stacked = list(fields or [])
    if not stacked and (name or line1 or line2):
        stacked = [name, line1, line2]
    lines = []
    for col in stacked:
        col = str(col or "").strip()
        if col:
            lines.append({"kind": "fields", "join": " ", "fields": [col]})
    if city or state or zip_code:
        lines.append({"kind": "city_state_zip", "city": city, "state": state, "zip": zip_code})
    return {"lines": lines}


_ODS_NS = {
    "office": "urn:oasis:names:tc:opendocument:xmlns:office:1.0",
    "table": "urn:oasis:names:tc:opendocument:xmlns:table:1.0",
    "text": "urn:oasis:names:tc:opendocument:xmlns:text:1.0",
}


def _ods_repeat(el, attr):
    raw = el.attrib.get("{%s}%s" % (_ODS_NS["table"], attr)) or el.attrib.get(attr) or "1"
    try:
        return max(1, int(raw))
    except ValueError:
        return 1


def _ods_cell_text(cell):
    parts = []
    for para in cell.findall("{%s}p" % _ODS_NS["text"]):
        parts.append("".join(para.itertext()))
    text = "\n".join(part for part in parts if part is not None).strip()
    if text:
        return text
    val = cell.attrib.get("{%s}value" % _ODS_NS["office"])
    return "" if val is None else str(val)


def _read_ods_matrix(path):
    with zipfile.ZipFile(path) as zhandle:
        root = ET.fromstring(zhandle.read("content.xml"))
    table = root.find(".//{%s}table" % _ODS_NS["table"])
    if table is None:
        return []
    rows = []
    for row_el in table.findall("{%s}table-row" % _ODS_NS["table"]):
        cells = []
        for cell_el in row_el.findall("{%s}table-cell" % _ODS_NS["table"]):
            value = _ods_cell_text(cell_el)
            for _ in range(_ods_repeat(cell_el, "number-columns-repeated")):
                cells.append(value)
        row_repeat = _ods_repeat(row_el, "number-rows-repeated")
        if row_repeat > 1000:
            row_repeat = 1
        for _ in range(row_repeat):
            rows.append(cells)
    return rows


def read_spreadsheet(path):
    """Return (headers, row dicts) from CSV, XLSX, or ODS."""
    if not path or not os.path.exists(path):
        return [], []
    lower = path.lower()
    if lower.endswith(".xlsx"):
        import openpyxl
        wb = openpyxl.load_workbook(path, data_only=True)
        sheet = wb.active
        headers = [str(cell.value).strip() if cell.value is not None else "" for cell in sheet[1]]
        rows = []
        for row in sheet.iter_rows(min_row=2, values_only=True):
            row_dict = {}
            for i, val in enumerate(row):
                if i < len(headers) and headers[i]:
                    row_dict[headers[i]] = "" if val is None else val
            rows.append(row_dict)
        headers = [h for h in headers if h]
        return headers, rows
    if lower.endswith(".ods"):
        matrix = _read_ods_matrix(path)
        if not matrix:
            return [], []
        headers = [str(h or "").strip() for h in matrix[0]]
        rows = []
        for raw in matrix[1:]:
            row_dict = {}
            for i, val in enumerate(raw):
                if i < len(headers) and headers[i]:
                    row_dict[headers[i]] = val
            rows.append(row_dict)
        headers = [h for h in headers if h]
        return headers, rows
    with open(path, mode="r", encoding="utf-8-sig", newline="") as handle:
        reader = csv.DictReader(handle)
        headers = [str(h or "").strip() for h in (reader.fieldnames or []) if str(h or "").strip()]
        rows = []
        for raw in reader:
            rows.append({str(k or "").strip(): ("" if v is None else v) for k, v in raw.items()})
        return headers, rows


def style_on(value):
    """True only for a real on value. Missing, blank, and 'false' stay off."""
    if isinstance(value, str):
        return value.strip().lower() in ("1", "true", "yes", "on")
    return bool(value)


def _face_style(filename, names):
    """Bold/italic from the file name. A regular face such as calibri.ttf stays regular."""
    stem = os.path.splitext(os.path.basename(filename).lower())[0]
    if stem.endswith("bi") or "bolditalic" in stem or "boldoblique" in stem:
        return True, True
    if stem.endswith("bd") or stem.endswith("bold") or "bold" in stem:
        return True, False
    if stem.endswith("z") and (stem[:-1] + ".ttf") in names:
        return True, True
    if stem.endswith("b") and (stem[:-1] + ".ttf") in names:
        return True, False
    if "italic" in stem or "oblique" in stem:
        return False, True
    if stem.endswith("i") and (stem[:-1] + ".ttf") in names:
        return False, True
    return False, False


def _family_stem(family):
    text = str(family or "Arial").lower().replace("-", " ")
    for word in ("bold italic", "boldoblique", "bold", "italic", "oblique", "regular"):
        text = text.replace(word, " ")
    text = " ".join(text.split())
    aliases = {
        "helvetica": "arial",
        "helv": "arial",
        "times": "times",
        "times new roman": "times",
        "courier": "cour",
        "courier new": "cour",
    }
    if text in aliases:
        return aliases[text]
    first = text.split()[0] if text else "arial"
    if first in aliases:
        return aliases[first]
    return "".join(text.split()) or "arial"


def _windows_font_file(family, bold=False, italic=False):
    windir = os.environ.get("WINDIR", r"C:\Windows")
    fonts = os.path.join(windir, "Fonts")
    bold = bool(bold)
    italic = bool(italic)
    stem = _family_stem(family)
    named = {
        "arial": [("arialbi.ttf", True, True), ("arialbd.ttf", True, False), ("ariali.ttf", False, True), ("arial.ttf", False, False)],
        "times": [("timesbi.ttf", True, True), ("timesbd.ttf", True, False), ("timesi.ttf", False, True), ("times.ttf", False, False)],
        "cour": [("courbi.ttf", True, True), ("courbd.ttf", True, False), ("couri.ttf", False, True), ("cour.ttf", False, False)],
    }
    candidates = list(named.get(stem, []))
    if not candidates and stem:
        paths = glob.glob(os.path.join(fonts, "*.ttf"))
        names = {os.path.basename(path).lower() for path in paths}
        for path in paths:
            name = os.path.basename(path).lower()
            face = os.path.splitext(name)[0]
            if not (face.startswith(stem) or stem.startswith(face)):
                continue
            candidates.append((name, *_face_style(name, names)))
    exact = [fn for fn, face_bold, face_italic in candidates if face_bold == bold and face_italic == italic]
    if bold:
        order = exact
    else:
        order = exact or [
            fn for fn, face_bold, face_italic in candidates
            if not face_bold and face_italic == italic
        ]
    if bold and italic:
        fallback = "arialbi.ttf"
    elif bold:
        fallback = "arialbd.ttf"
    elif italic:
        fallback = "ariali.ttf"
    else:
        fallback = "arial.ttf"
    order = sorted(order, key=lambda fn: (os.path.splitext(fn)[0].lower() != stem, len(fn)))
    for fn in list(order) + [fallback]:
        path = fn if os.path.isabs(fn) else os.path.join(fonts, fn)
        if os.path.exists(path):
            return path
    arial = os.path.join(fonts, "arial.ttf")
    return arial if os.path.exists(arial) else None


def _plain_merge_text(text, field):
    raw = str(text or "")
    if field.get("type") == "HTML":
        raw = raw.replace("<br/>", "\n").replace("<br>", "\n").replace("<br />", "\n")
        raw = html.unescape(raw)
        while "<" in raw and ">" in raw:
            start = raw.find("<")
            end = raw.find(">", start)
            if end < 0:
                break
            raw = raw[:start] + raw[end + 1:]
    return raw


def field_rotation(field):
    """Clockwise degrees. Missing or blank stays upright."""
    try:
        return float((field or {}).get("rotate", 0) or 0) % 360.0
    except (TypeError, ValueError):
        return 0.0


def stamp_vdp_text(page, rect, text, field):
    """Draw merge text in the field box with the same face the HTML stamper used."""
    if text is None:
        text = ""
    text = _plain_merge_text(text, field)
    if not str(text).strip() and field.get("type") != "HTML":
        return
    f_type = field.get("type", "Text")
    try:
        f_size = float(field.get("size", 12) or 12)
    except (TypeError, ValueError):
        f_size = 12.0
    align = str(field.get("align", "Left") or "Left").lower()
    align_code = {"left": 0, "center": 1, "right": 2}.get(align, 0)
    color = hex_to_rgb(field.get("color", "#000000"))
    family = field.get("font") or "Arial"
    bold = style_on(field.get("bold"))
    italic = style_on(field.get("italic"))
    underline = style_on(field.get("underline"))
    autoscale = bool(field.get("autoscale"))
    if f_type == "HTML":
        pass
    font_file = _windows_font_file(family, bold, italic)
    page.insert_textbox(
        rect,
        text,
        fontsize=f_size,
        fontfile=font_file,
        color=color,
        align=align_code,
        underline=underline,
        autoscale=autoscale,
        scale_low=0.12 if autoscale else 1.0,
        rotate=field_rotation(field),
    )


def load_merge_rows(csv_path="", generate_count=1, mapped_columns=None):
    """Load spreadsheet records, dropping blank rows and rows with no merge data."""
    mapped_columns = [c for c in (mapped_columns or []) if c]
    rows = []

    if csv_path and os.path.exists(csv_path):
        try:
            _headers, rows = read_spreadsheet(csv_path)
        except Exception as e:
            print(f"Spreadsheet read error: {e}")
            return []
        return [row for row in rows if row_has_merge_data(row, mapped_columns)]

    try:
        count = max(1, int(generate_count or 1))
    except (TypeError, ValueError):
        count = 1
    return [{} for _ in range(count)]


def _field_template_page(field, template_pages):
    try:
        raw = int(float(field.get("page", 0) or 0))
    except (TypeError, ValueError):
        raw = 0
    if template_pages > 0:
        return raw % template_pages
    return 0


def apply_vdp_merge(active_doc, rows, fields, to_points, unit=None):
    """Repeat the template once per data row and stamp mapped fields on every copy."""
    next_doc = pdfdoc.open()
    if not rows or len(active_doc) == 0:
        return next_doc

    template_pages = len(active_doc)
    for row_idx, row in enumerate(rows):
        base = next_doc.page_count
        next_doc.insert_pdf(active_doc)
        for p_idx in range(template_pages):
            new_p = next_doc[base + p_idx]
            try:
                new_p.clean_contents()
            except Exception:
                pass

            for field in fields or []:
                if _field_template_page(field, template_pages) != p_idx:
                    continue

                source_type = field.get("source_type", "column")
                if source_type == "address_block":
                    val = format_address_block(row, field.get("block") or {})
                elif source_type == "column":
                    val = str(row.get(field.get("column", ""), "") or "")
                else:
                    text_template = field.get("column", "")
                    try:
                        start_num = int(field.get("num_start", 1))
                    except ValueError:
                        start_num = 1
                    try:
                        pad = int(field.get("num_pad", 1))
                    except ValueError:
                        pad = 1
                    current_num = start_num + row_idx
                    val = text_template.replace("[NUM]", str(current_num).zfill(pad))

                f_type = field.get("type", "Text")
                x = to_points(field.get("x", 0), unit)
                y = to_points(field.get("y", 0), unit)
                w_box = to_points(field.get("w", 2.0), unit)
                h_box = to_points(field.get("h", 0.5), unit)
                rect = Rect(x, y, x + w_box, y + h_box)
                if rect.width < 2 or rect.height < 2:
                    continue

                if f_type == "QR Code":
                    if not QR_AVAILABLE:
                        stamp_vdp_text(new_p, rect, "[QR Missing - pip install qrcode[pil]]", {**field, "type": "Text", "color": "#cc0000"})
                        continue
                    qr = qrcode.QRCode(version=1, error_correction=qrcode.constants.ERROR_CORRECT_M, box_size=10, border=0)
                    qr.add_data(val)
                    qr.make(fit=True)
                    img = qr.make_image(fill_color="black", back_color="white")
                    angle = field_rotation(field)
                    if angle >= 0.5:
                        pil = img.get_image() if hasattr(img, "get_image") else img
                        img = pil.convert("RGB").rotate(-angle, expand=False, fillcolor="white")
                    img_bytes = io.BytesIO()
                    img.save(img_bytes, format="PNG")
                    new_p.insert_image(rect, stream=img_bytes.getvalue())
                else:
                    stamp_vdp_text(new_p, rect, val, field)

    return next_doc


def hex_to_rgb(hex_color):
    hex_color = hex_color.lstrip("#")
    if len(hex_color) == 6:
        return tuple(int(hex_color[i:i + 2], 16) / 255.0 for i in (0, 2, 4))
    return (0, 0, 0)


def apply_proof_stamp(doc, stamp_text):
    for page in doc:
        w, h = page.rect.width, page.rect.height
        page.insert_text(
            Point(w * 0.10, h * 0.50),
            stamp_text,
            fontsize=min(w, h) * 0.10,
            color=(0.85, 0.2, 0.2),
            fontname="helv",
            fill_opacity=0.30,
        )
        try:
            page.clean_contents()
        except Exception:
            pass
    return doc


