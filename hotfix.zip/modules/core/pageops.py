"""Shared page placement helpers used by impose and other pipeline steps."""

import pdfdoc


def show_source_page(dest_page, dest_rect, src_doc, src_index, keep_proportion=True, rotate=0, clip=None):
    """Copy a source page into dest_rect, clipped to the visible page box.

    Placing a full page with a dest rect that hangs off the new media box leaves
    the original artwork (crop marks, bleed) inside the Form XObject. The next
    Resize or impose step then scales that original instead of the crop. Always
    clip to the source page rectangle, or to an explicit crop region.
    """
    src_page = src_doc[src_index]
    if clip is None:
        src_clip = pdfdoc.Rect(src_page.rect)
    else:
        src_clip = pdfdoc.Rect(clip) & src_page.rect
    if src_clip.is_empty or src_clip.width < 0.5 or src_clip.height < 0.5:
        src_clip = pdfdoc.Rect(src_page.rect)
    kwargs = {"keep_proportion": keep_proportion, "clip": src_clip}
    if rotate:
        kwargs["rotate"] = rotate
    dest_page.show_pdf_page(dest_rect, src_doc, src_index, **kwargs)


