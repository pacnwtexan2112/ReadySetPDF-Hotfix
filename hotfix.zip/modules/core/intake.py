"""Turn an Open, drop, or hot-folder path into a file the PDF engine can read.

Network copies often show up late or refuse a direct open. This waits for a
stable size, retries the open, and if a UNC path still fails, copies it to
%TEMP%\\ReadySetPDF\\intake\\<original name>.
"""

import os
import shutil
import tempfile
import time
import urllib.parse

STABLE_SECONDS = 2.0
STABLE_TIMEOUT = 15.0
OPEN_ATTEMPTS = 3
OPEN_PAUSE = 0.4


class IntakeError(OSError):
    """Plain failure. The message always names the path that was tried."""

    def __init__(self, path, detail="", message=None):
        self.path = path
        if message:
            text = message if path and str(path) in message else f"{message}\n{path}"
        else:
            text = f"Could not open {path}"
            if detail:
                text = f"{text}\n{detail}"
        super().__init__(text)


def normalize_input_path(path):
    """Strip file:// and return a filesystem path. UNC stays UNC."""
    text = str(path or "").strip().strip("{}").strip('"').strip("'")
    if not text:
        return ""
    if text.lower().startswith("file:"):
        text = urllib.parse.unquote(text)
        rest = text[5:]
        slashes = 0
        for char in rest:
            if char in "/\\":
                slashes += 1
            else:
                break
        body = rest[slashes:].replace("/", "\\")
        if slashes >= 3 and len(body) >= 2 and body[1] == ":":
            text = body
        elif slashes >= 2:
            text = "\\\\" + body.lstrip("\\")
        else:
            text = body
    if text.startswith("\\\\"):
        return os.path.normpath(text)
    return os.path.normpath(text) if text else ""


def _unc_for_drive(drive):
    """Return the UNC root for a mapped drive letter, or None."""
    if os.name != "nt" or not str(drive).endswith(":"):
        return None
    try:
        import ctypes
        from ctypes import wintypes
        buffer = ctypes.create_unicode_buffer(1024)
        size = wintypes.DWORD(len(buffer))
        result = ctypes.windll.mpr.WNetGetConnectionW(str(drive), buffer, ctypes.byref(size))
    except OSError:
        return None
    if result != 0:
        return None
    unc = buffer.value.strip().rstrip("\\")
    if unc.startswith("\\\\"):
        return unc
    return None


def _resolve_network(path):
    """Return (path, is_network). A failed drive lookup keeps the letter."""
    if path.startswith("\\\\"):
        return path, True
    drive, tail = os.path.splitdrive(path)
    if drive:
        unc = _unc_for_drive(drive)
        if unc:
            return os.path.normpath(unc + tail), True
    return path, False


def _wait_until_stable(path, stable_seconds, timeout):
    deadline = time.monotonic() + timeout
    last_size = object()
    stable_since = None
    while True:
        now = time.monotonic()
        try:
            size = os.path.getsize(path)
        except OSError:
            size = None
        if size is not None and size == last_size:
            if stable_since is None:
                stable_since = now
            if now - stable_since >= stable_seconds:
                return
        else:
            last_size = size
            stable_since = None
        if now >= deadline:
            return
        remaining = deadline - now
        time.sleep(min(0.25, max(remaining, 0)))


def _open_with_retries(path, attempts, pause):
    last = None
    tries = max(int(attempts), 1)
    for attempt in range(tries):
        try:
            if not os.path.isfile(path):
                raise FileNotFoundError(path)
            with open(path, "rb") as handle:
                handle.read(16)
            return
        except OSError as exc:
            last = exc
            if attempt + 1 < tries:
                time.sleep(pause)
    raise last


def _copy_to_intake(path):
    folder = os.path.join(tempfile.gettempdir(), "ReadySetPDF", "intake")
    os.makedirs(folder, exist_ok=True)
    name = os.path.basename(path) or "input.pdf"
    dest = os.path.join(folder, name)
    shutil.copy2(path, dest)
    return dest


def prepare_input(path, stable_seconds=STABLE_SECONDS, timeout=STABLE_TIMEOUT, open_attempts=OPEN_ATTEMPTS):
    """Return a local path the PDF engine can open.

    Local files are returned as themselves. A UNC path, or a mapped drive that
    resolved to UNC, is copied into the temp intake folder only when a direct
    open still fails.
    """
    tried = normalize_input_path(path)
    if not tried:
        raise IntakeError(path or "", "The path is empty.")
    tried, is_network = _resolve_network(tried)
    if is_network:
        _wait_until_stable(tried, stable_seconds, timeout)
    try:
        _open_with_retries(tried, open_attempts, OPEN_PAUSE)
        return tried
    except OSError as exc:
        if not is_network:
            raise IntakeError(tried, str(exc)) from exc
        try:
            copied = _copy_to_intake(tried)
            _open_with_retries(copied, open_attempts, OPEN_PAUSE)
            return copied
        except OSError as copy_exc:
            raise IntakeError(tried, str(copy_exc)) from copy_exc


def ensure_output_writable(path):
    """Leave the destination where it is. Say so when it cannot be written."""
    folder = str(path or "").strip()
    if not folder:
        raise IntakeError(folder, "The output folder is empty.")
    probe = None
    try:
        os.makedirs(folder, exist_ok=True)
        probe = os.path.join(folder, ".readysetpdf_write_test")
        with open(probe, "wb") as handle:
            handle.write(b"")
        os.remove(probe)
    except OSError as exc:
        if probe and os.path.isfile(probe):
            try:
                os.remove(probe)
            except OSError:
                pass
        raise IntakeError(folder, message=f"Cannot write to {folder}\n{exc}") from exc
