from .automation import HotFolderMixin

__all__ = ['HotFolderMixin']
