"""Hot folder / Automation tab helpers extracted from readysetpdf.4.0.py."""

import json
import os
import shutil
import threading
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import pdfdoc

from engine import insert_source_file, prepare_imported_doc, save_optimized_pdf
from modules.core.intake import IntakeError, prepare_input, ensure_output_writable


PIPELINE_COUNT = 3
_BATCH_EXTS = (".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".csv", ".xlsx", ".ods")


class HotFolderMixin:
    def build_batch_tab(self):
        tab = ttk.Frame(self.tab_content_frame, padding=15)
        self.tabs["Automation"] = tab
        tk.Label(
            tab,
            text="Three hot folders. Each pipeline has its own input, output, and recipe. One watcher runs every pipeline that is filled in.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 9, "italic"),
            wraplength=520, justify="left",
        ).pack(anchor="w", pady=(0, 8))

        saved = self.settings.get("automation_pipelines") or []
        self.batch_pipelines = []
        notebook = ttk.Notebook(tab)
        notebook.pack(fill="x", pady=(0, 8))
        for index in range(PIPELINE_COUNT):
            row = saved[index] if index < len(saved) and isinstance(saved[index], dict) else {}
            if index == 0:
                inn, out, recipe = self.batch_in_var, self.batch_out_var, self.batch_recipe_var
            else:
                inn, out, recipe = tk.StringVar(), tk.StringVar(), tk.StringVar()
            inn.set(str(row.get("in") or ""))
            out.set(str(row.get("out") or ""))
            recipe.set(str(row.get("recipe") or ""))
            pipe = {
                "in": inn,
                "out": out,
                "recipe": recipe,
                "status": tk.StringVar(value="Idle"),
                "is_processing": False,
                "index": index,
            }
            self.batch_pipelines.append(pipe)
            frame = ttk.Frame(notebook, padding=10)
            notebook.add(frame, text=f" Pipeline {index + 1} ")
            self._build_batch_pipeline_form(frame, pipe)
            for var in (inn, out, recipe):
                var.trace_add("write", lambda *_a: self._save_automation_pipelines())

        action = ttk.LabelFrame(tab, text="Execution", padding=10)
        action.pack(fill="x", pady=8)
        self._ensure_preflight_mode_vars()
        assoc = ttk.Checkbutton(
            action,
            text="Run preflight in association with automation",
            variable=self.preflight_mode_vars["hotfolder"],
        )
        assoc.pack(anchor="w", pady=(0, 6))
        self._preflight_tip(
            assoc,
            "After each processed PDF, Preflight checks it and can move it to the pass, fail, or hold folders. "
            "Checking this turns off Manual execution in Preflight. Unchecking turns the association off immediately "
            "and does not overwrite the saved recipe.",
        )
        self.btn_batch = self._create_btn(action, "▶ Run Configured Pipelines Once", self.color_steel, self.color_white, self.start_manual_batch)
        self.btn_batch.pack(fill="x", pady=5)
        self.btn_watch = self._create_btn(action, "🔥 Start Hot Folder Watch", self.color_lime, self.color_navy, self.toggle_watch)
        self.btn_watch.pack(fill="x", pady=5)
        for pipe in self.batch_pipelines:
            line = tk.Frame(action, bg=self.color_white)
            line.pack(fill="x", pady=1)
            tk.Label(
                line, text=f"Pipeline {pipe['index'] + 1}:", width=12, anchor="w",
                bg=self.color_white, fg=self.color_navy, font=("Arial", 9, "bold"),
            ).pack(side="left")
            tk.Label(
                line, textvariable=pipe["status"], anchor="w",
                bg=self.color_white, fg=self.color_steel, font=("Arial", 9),
            ).pack(side="left", fill="x", expand=True)
        if hasattr(self, "_wire_engine_pipelines"):
            self._wire_engine_pipelines()

    def _build_batch_pipeline_form(self, parent, pipe):
        def row(label, variable, browse):
            line = tk.Frame(parent, bg=self.color_white)
            line.pack(fill="x", pady=4)
            tk.Label(line, text=label, bg=self.color_white, fg=self.color_navy, width=14, anchor="w").pack(side="left")
            tk.Entry(line, textvariable=variable, bg=self.color_pale).pack(side="left", fill="x", expand=True, padx=5)
            self._create_btn(line, "Browse", self.color_mint, self.color_navy, browse, compact=True).pack(side="left")

        row("Input Folder:", pipe["in"], lambda: pipe["in"].set(filedialog.askdirectory() or pipe["in"].get()))
        row("Output Folder:", pipe["out"], lambda: pipe["out"].set(filedialog.askdirectory() or pipe["out"].get()))
        row(
            "Recipe (.json):", pipe["recipe"],
            lambda: pipe["recipe"].set(self._pick_recipe_file() or pipe["recipe"].get()),
        )

    def _save_automation_pipelines(self):
        pipes = getattr(self, "batch_pipelines", None)
        if not pipes:
            return
        self.settings["automation_pipelines"] = [
            {"in": p["in"].get(), "out": p["out"].get(), "recipe": p["recipe"].get()}
            for p in pipes
        ]
        self.save_settings()

    def _batch_ready(self, pipe):
        return bool(pipe["in"].get().strip() and pipe["out"].get().strip() and pipe["recipe"].get().strip())

    def _configured_batch_pipelines(self):
        return [pipe for pipe in getattr(self, "batch_pipelines", []) if self._batch_ready(pipe)]

    def toggle_watch(self):
        if self.is_watching:
            self.is_watching = False
            self.btn_watch.config(text="🔥 Start Hot Folder Watch", bg=self.color_lime, fg=self.color_navy)
            self.btn_batch.config(state="normal")
            self.remove_bg_task("🔥 Hot Folder Watcher (Listening...)")
            for pipe in self.batch_pipelines:
                self.remove_bg_task(self._pipeline_listen_task(pipe))
                self.remove_bg_task(self._pipeline_process_task(pipe))
                if not pipe["is_processing"]:
                    pipe["status"].set("Stopped")
            return
        if self._free_blocks_batch():
            return
        ready = self._configured_batch_pipelines()
        if not ready:
            messagebox.showwarning("Missing Info", "Set Input, Output, and Recipe on at least one pipeline.")
            return
        self.is_watching = True
        self.btn_watch.config(text="⏹ Stop Hot Folder Watch", bg=self.color_steel, fg=self.color_white)
        self.btn_batch.config(state="disabled")
        for pipe in self.batch_pipelines:
            if self._batch_ready(pipe):
                pipe["status"].set("Listening...")
                self.add_bg_task(self._pipeline_listen_task(pipe))
            else:
                pipe["status"].set("Not configured")
        self.poll_hot_folder()

    def poll_hot_folder(self):
        if not self.is_watching:
            return
        for pipe in self.batch_pipelines:
            if pipe["is_processing"] or not self._batch_ready(pipe):
                continue
            in_dir = pipe["in"].get()
            if not os.path.isdir(in_dir):
                continue
            try:
                names = os.listdir(in_dir)
            except OSError:
                continue
            if any(name.lower().endswith(_BATCH_EXTS) for name in names):
                pipe["is_processing"] = True
                pipe["status"].set("Processing...")
                self.remove_bg_task(self._pipeline_listen_task(pipe))
                self.add_bg_task(self._pipeline_process_task(pipe))
                threading.Thread(target=self._batch_worker, args=(pipe, True), daemon=True).start()
        self.root.after(5000, self.poll_hot_folder)

    def _batch_worker(self, pipe, silent):
        try:
            self.run_batch(silent=silent, pipeline=pipe)
        except Exception as exc:
            print(f"Background Batch Error: {exc}")
        finally:
            pipe["is_processing"] = False
            def _done():
                self.remove_bg_task(self._pipeline_process_task(pipe))
                if self._widget_alive(getattr(self, "root", None)):
                    if self.is_watching and self._batch_ready(pipe):
                        pipe["status"].set("Listening...")
                        self.add_bg_task(self._pipeline_listen_task(pipe))
                    elif not pipe["is_processing"]:
                        pipe["status"].set("Idle")
            self.root.after(0, _done)

    def _pipeline_listen_task(self, pipe):
        return f"🔥 Pipeline {pipe['index'] + 1} listening"

    def _pipeline_process_task(self, pipe):
        return f"⚙️ Pipeline {pipe['index'] + 1} processing"

    def start_manual_batch(self):
        if self._free_blocks_batch():
            return
        if self.is_processing_batch or any(pipe["is_processing"] for pipe in self.batch_pipelines):
            messagebox.showwarning("Busy", "A batch process is already running.")
            return
        ready = self._configured_batch_pipelines()
        if not ready:
            messagebox.showwarning("Missing Info", "Set Input, Output, and Recipe on at least one pipeline.")
            return

        self.is_processing_batch = True
        self.btn_batch.config(state="disabled")

        def worker():
            try:
                for pipe in ready:
                    pipe["is_processing"] = True
                    self.root.after(0, lambda p=pipe: p["status"].set("Processing..."))
                    self.root.after(0, lambda p=pipe: self.add_bg_task(self._pipeline_process_task(p)))
                    try:
                        self.run_batch(silent=False, pipeline=pipe)
                    except Exception as exc:
                        print(exc)
                    finally:
                        pipe["is_processing"] = False
                        self.root.after(0, lambda p=pipe: self.remove_bg_task(self._pipeline_process_task(p)))
                        self.root.after(0, lambda p=pipe: p["status"].set("Idle"))
            finally:
                self.is_processing_batch = False
                self.root.after(0, lambda: self.btn_batch.config(state="normal") if self._widget_alive(self.btn_batch) else None)

        threading.Thread(target=worker, daemon=True).start()

    def _free_blocks_batch(self):
        import licensing
        from license_dialog import open_license_dialog
        state = getattr(self, "license_state", None) or licensing.load_state()
        if licensing.allows_multiple_files(state):
            return False
        messagebox.showinfo("Free", "Folder batch processing is part of Pro.", parent=self.root)
        open_license_dialog(self)
        return True

    def run_batch(self, silent=False, pipeline=None):
        import licensing
        state = getattr(self, "license_state", None) or licensing.load_state()
        if not licensing.allows_multiple_files(state):
            print("Folder batch processing is part of Pro.")
            if not silent:
                self.root.after(0, lambda: self._free_blocks_batch())
            return
        if pipeline is None:
            pipeline = self.batch_pipelines[0] if getattr(self, "batch_pipelines", None) else {
                "in": self.batch_in_var, "out": self.batch_out_var, "recipe": self.batch_recipe_var,
            }
        in_dir = pipeline["in"].get(); out_dir = pipeline["out"].get(); recipe_path = pipeline["recipe"].get()
        if not in_dir or not out_dir or not recipe_path:
            if not silent: self.root.after(0, lambda: messagebox.showwarning("Missing Info", "Please select Input, Output, and Recipe."))
            return
        try:
            with open(recipe_path, 'r') as f: recipe = json.load(f)
        except Exception as e:
            if not silent: self.root.after(0, lambda: messagebox.showerror("Recipe Error", str(e)))
            return
        try:
            steps, recipe_mode = self.parse_recipe_data(recipe)
        except ValueError as e:
            if not silent: self.root.after(0, lambda: messagebox.showerror("Recipe Error", str(e)))
            return
        page_mode = recipe_mode or self.page_box_mode_var.get()
        try:
            names = os.listdir(in_dir)
        except OSError as exc:
            message = f"Could not open {in_dir}\n{exc}"
            print(message)
            if not silent:
                self.root.after(0, lambda m=message: messagebox.showerror("Could not open file", m))
            return
        try:
            ensure_output_writable(out_dir)
        except IntakeError as exc:
            print(exc)
            if not silent:
                self.root.after(0, lambda m=str(exc): messagebox.showerror("Output folder", m))
            return
        files = [f for f in names if f.lower().endswith(('.pdf', '.png', '.jpg', '.jpeg', '.tif', '.tiff'))]
        data_files = [f for f in names if f.lower().endswith(('.csv', '.xlsx', '.ods'))]
        vdp_step = next((s for s in steps if s.get("type") == "VDP Mail Merge"), None)
        template_pdf = ""
        if vdp_step:
            template_pdf = (vdp_step.get("params") or {}).get("template_pdf") or ""
        done_dir = os.path.join(in_dir, "Processed_Originals")
        try:
            os.makedirs(done_dir, exist_ok=True)
        except OSError as exc:
            message = f"Could not open {done_dir}\n{exc}"
            print(message)
            if not silent:
                self.root.after(0, lambda m=message: messagebox.showerror("Could not open file", m))
            return
        success_count = 0
        errors = []

        def _ready(path):
            try:
                return prepare_input(path)
            except IntakeError as exc:
                errors.append(str(exc))
                print(exc)
                return None

        def _show_errors():
            if errors and not silent:
                text = "\n\n".join(errors)
                self.root.after(0, lambda m=text: messagebox.showerror("Could not open file", m))

        def _process_doc(active_doc, out_path, move_src, local_steps):
            nonlocal success_count
            prepare_imported_doc(active_doc, page_mode)
            final_doc = self._execute_pipeline(
                active_doc, local_steps, preview_mode=False,
                output_dir=out_dir, sidecar_stem=os.path.splitext(os.path.basename(out_path))[0],
            )
            save_optimized_pdf(final_doc, out_path)
            final_doc.close()
            dest_path = os.path.join(done_dir, os.path.basename(move_src))
            if os.path.exists(dest_path):
                os.remove(dest_path)
            shutil.move(move_src, dest_path)
            success_count += 1
            hook = getattr(self, "preflight_after_hotfolder_output", None)
            if hook:
                try:
                    hook(out_path)
                except Exception as exc:
                    print(f"Preflight recipe hook: {exc}")

        skip_pdfs = set()
        ready_template = _ready(template_pdf) if (data_files and template_pdf) else None
        if data_files and ready_template:
            skip_pdfs.add(os.path.normcase(os.path.abspath(template_pdf)))
            for fname in data_files:
                in_path = os.path.join(in_dir, fname)
                ready_data = _ready(in_path)
                if not ready_data:
                    continue
                out_path = os.path.join(out_dir, f"Processed_{os.path.splitext(fname)[0]}.pdf")
                try:
                    local_steps = []
                    for step in steps:
                        if step.get("type") == "VDP Mail Merge":
                            params = dict(step.get("params") or {})
                            params["csv_path"] = ready_data
                            local_steps.append({"type": step["type"], "params": params})
                        else:
                            local_steps.append(step)
                    active_doc = pdfdoc.open()
                    insert_source_file(active_doc, ready_template)
                    _process_doc(active_doc, out_path, in_path, local_steps)
                except OSError as exc:
                    message = f"Could not write {out_path}\n{exc}"
                    errors.append(message)
                    print(message)
                except Exception as e:
                    print(e)
        if not files:
            _show_errors()
            if not silent:
                if success_count:
                    self.root.after(0, lambda: messagebox.showinfo("Batch Complete", f"Successfully processed {success_count} files."))
                elif data_files and not template_pdf:
                    self.root.after(0, lambda: messagebox.showwarning(
                        "VDP hot folder",
                        "Found spreadsheet files but the recipe has no stored template PDF.\nAdd the merge to the stack from a loaded envelope, save the recipe, then drop CSV/XLSX/ODS in the hot folder.",
                    ))
            return
        for fname in files:
            in_path = os.path.join(in_dir, fname)
            if skip_pdfs and os.path.normcase(os.path.abspath(in_path)) in skip_pdfs:
                continue
            ready = _ready(in_path)
            if not ready:
                continue
            out_path = os.path.join(out_dir, f"Processed_{os.path.splitext(fname)[0]}.pdf")
            try:
                active_doc = pdfdoc.open()
                insert_source_file(active_doc, ready)
                _process_doc(active_doc, out_path, in_path, steps)
            except OSError as exc:
                message = f"Could not write {out_path}\n{exc}"
                errors.append(message)
                print(message)
            except Exception as e:
                print(e)
        _show_errors()
        if not silent:
            self.root.after(0, lambda: messagebox.showinfo("Batch Complete", f"Successfully processed {success_count} files."))

