"""Color tab UI extracted from readysetpdf.4.0.py."""

import tkinter as tk
from tkinter import ttk


class ColorMixin:
    def build_color_tab(self):
        tab = ttk.Frame(self.tab_content_frame, padding=15); self.tabs["Color"] = tab
        mode_frame = ttk.LabelFrame(tab, text="Color Space Conversion", padding=10); mode_frame.pack(fill="x", pady=5)
        modes = [("Keep Original Document Colors", "Keep Original"), ("Grayscale (256 Levels)", "Grayscale"),
                 ("Black & White (High Contrast)", "BW"), ("CMYK (Commercial Print)", "CMYK"), ("RGB (Digital/Web)", "RGB")]
        for text, val in modes:
            tk.Radiobutton(
                mode_frame, text=text, variable=self.color_mode_var, value=val,
                indicatoron=0, bg=self.color_pale, fg=self.color_navy,
                selectcolor=self.color_mint, relief="flat", font=("Arial", 10),
                anchor="w", justify="left",
            ).pack(anchor="w", fill="x", pady=3)
        res_frame = ttk.LabelFrame(tab, text="Rasterization Resolution", padding=10); res_frame.pack(fill="x", pady=10)
        dpi_row = tk.Frame(res_frame, bg=self.color_white); dpi_row.pack(fill="x")
        tk.Label(dpi_row, text="Target DPI:", bg=self.color_white, fg=self.color_navy, font=("Arial", 10, "bold")).pack(side="left")
        ttk.Combobox(dpi_row, values=["300", "400", "600", "1200"], textvariable=self.color_dpi_var, width=10, state="readonly", font=("Arial", 10)).pack(side="left", padx=10)
        
        def quick_add_cmyk():
            self.color_mode_var.set("CMYK") 
            self.add_step_to_queue("Color Conversion")
            
        btn_frame = tk.Frame(tab, bg=self.color_white); btn_frame.pack(fill="x", side="bottom", pady=10)
        self._create_btn(btn_frame, "🖨️ Quick Add: Convert to CMYK", self.color_lime, self.color_navy, quick_add_cmyk).pack(fill="x", pady=(0, 5))
        self._build_step_commit_buttons(btn_frame, "Color Conversion", "➕ Add Standard Color Conversion").pack(fill="x")

