"""Color conversion helpers extracted from engine.py."""

import os
import sys
import subprocess
import tempfile

import pdfdoc
from pdfrender import render_page_image
from tkinter import messagebox


def find_ghostscript():
    if hasattr(sys, "_MEIPASS"):
        gs_path = os.path.join(sys._MEIPASS, "gswin64c.exe")
        if os.path.exists(gs_path):
            return gs_path

    local_path = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), "gswin64c.exe")
    if os.path.exists(local_path):
        return local_path

    return None


def convert_colorspace(active_doc, mode, dpi=300, preview_mode=False):
    if mode == "Keep Original":
        return active_doc

    if preview_mode:
        next_doc = pdfdoc.open()
        dpi = max(36, int(dpi or 300))
        for page in active_doc:
            w, h = page.rect.width, page.rect.height
            new_p = next_doc.new_page(width=w, height=h)
            image = render_page_image(active_doc, page.number, dpi / 72.0, annots=True)
            if mode == "CMYK":
                image = image.convert("CMYK")
            elif mode == "RGB":
                image = image.convert("RGB")
            else:
                image = image.convert("L")
            new_p.insert_image(new_p.rect, pil=image)
        active_doc.close()
        return next_doc

    gs_exec = find_ghostscript()
    if not gs_exec:
        messagebox.showerror(
            "Engine Missing",
            "Critical Error: The Ghostscript engine is missing from the application bundle.",
        )
        return active_doc

    in_fd, in_temp = tempfile.mkstemp(suffix=".pdf")
    out_fd, out_temp = tempfile.mkstemp(suffix=".pdf")
    os.close(in_fd)
    os.close(out_fd)

    active_doc.save(in_temp)

    cmd = [gs_exec, "-dNOPAUSE", "-dBATCH", "-sDEVICE=pdfwrite"]
    if mode in ["Grayscale", "BW"]:
        cmd.extend(["-sColorConversionStrategy=Gray", "-dProcessColorModel=/DeviceGray"])
    elif mode == "CMYK":
        cmd.extend(["-sColorConversionStrategy=CMYK", "-dProcessColorModel=/DeviceCMYK"])
    elif mode == "RGB":
        cmd.extend(["-sColorConversionStrategy=RGB", "-dProcessColorModel=/DeviceRGB"])

    cmd.extend([f"-sOutputFile={out_temp}", in_temp])

    startupinfo = None
    if os.name == "nt":
        startupinfo = subprocess.STARTUPINFO()
        startupinfo.dwFlags |= subprocess.STARTF_USESHOWWINDOW

    try:
        subprocess.run(cmd, startupinfo=startupinfo, check=True)
        active_doc.close()
        return pdfdoc.open(out_temp)
    except Exception as e:
        messagebox.showerror("Ghostscript Error", f"Vector conversion failed:\n{e}")
        return active_doc


