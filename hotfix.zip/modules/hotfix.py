"""Check the ReadySetPDF hot-fix manifest and stage an update.

The manifest and zip must stay on the ReadySetPDF-Hotfix GitHub repository.
The helper script copies the extracted files over this program's folder, then
relaunches the same way the app was started.
"""

from __future__ import annotations

import json
import os
import shutil
import subprocess
import sys
import zipfile
from urllib.error import HTTPError, URLError
from urllib.request import Request, urlopen

import licensing

MANIFEST_URL = (
    "https://raw.githubusercontent.com/pacnwtexan2112/ReadySetPDF-Hotfix/main/version.json"
)
_ALLOWED_PREFIX = "https://raw.githubusercontent.com/pacnwtexan2112/ReadySetPDF-Hotfix/"
_MAX_ZIP_BYTES = 100 * 1024 * 1024


def updates_dir():
    path = os.path.join(licensing.app_dir(), "updates")
    os.makedirs(path, exist_ok=True)
    return path


def app_install_dir():
    """Folder that holds the running program, not the updates folder."""
    if getattr(sys, "frozen", False):
        return os.path.dirname(os.path.abspath(sys.executable))
    here = os.path.dirname(os.path.abspath(__file__))
    return os.path.dirname(here)


def version_key(value):
    parts = []
    for piece in str(value or "").strip().lstrip("vV").split("."):
        digits = ""
        for char in piece:
            if char.isdigit():
                digits += char
            else:
                break
        parts.append(int(digits) if digits else 0)
    return tuple(parts)


def version_is_newer(remote, local):
    left = version_key(remote)
    right = version_key(local)
    width = max(len(left), len(right))
    left = left + (0,) * (width - len(left))
    right = right + (0,) * (width - len(right))
    return left > right


def _allowed_url(url):
    text = str(url or "").strip()
    return text.startswith(_ALLOWED_PREFIX) and ".." not in text


def _request(url, timeout):
    if not _allowed_url(url):
        raise ValueError("Hot-fix address is not on the ReadySetPDF-Hotfix repository.")
    return Request(url, headers={"User-Agent": "ReadySetPDF-Hotfix"})


def fetch_manifest(url=MANIFEST_URL, timeout=20):
    try:
        with urlopen(_request(url, timeout), timeout=timeout) as response:
            payload = response.read(1024 * 1024 + 1)
    except HTTPError as exc:
        raise RuntimeError(f"Could not read the hot-fix list ({exc.code}).") from exc
    except URLError as exc:
        raise RuntimeError(f"Could not reach the hot-fix list.\n{exc.reason}") from exc
    if len(payload) > 1024 * 1024:
        raise RuntimeError("The hot-fix list is too large.")
    try:
        data = json.loads(payload.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        raise RuntimeError("The hot-fix list is not valid JSON.") from exc
    if not isinstance(data, dict) or not str(data.get("version") or "").strip():
        raise RuntimeError("The hot-fix list has no version.")
    patch_url = str(data.get("patch_url") or "").strip()
    if patch_url and not _allowed_url(patch_url):
        raise RuntimeError("The hot-fix download is not on the ReadySetPDF-Hotfix repository.")
    return {
        "version": str(data.get("version")).strip(),
        "patch_url": patch_url,
        "release_notes": str(data.get("release_notes") or "").strip(),
    }


def download_patch(url, dest, timeout=120):
    if not _allowed_url(url):
        raise RuntimeError("The hot-fix download is not on the ReadySetPDF-Hotfix repository.")
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    temp = dest + ".part"
    received = 0
    try:
        with urlopen(_request(url, timeout), timeout=timeout) as response, open(temp, "wb") as handle:
            while True:
                chunk = response.read(64 * 1024)
                if not chunk:
                    break
                received += len(chunk)
                if received > _MAX_ZIP_BYTES:
                    raise RuntimeError("The hot-fix download is too large.")
                handle.write(chunk)
        os.replace(temp, dest)
    except HTTPError as exc:
        raise RuntimeError(f"Could not download the hot-fix ({exc.code}).") from exc
    except URLError as exc:
        raise RuntimeError(f"Could not download the hot-fix.\n{exc.reason}") from exc
    finally:
        if os.path.isfile(temp):
            try:
                os.remove(temp)
            except OSError:
                pass
    return dest


def safe_extract(zip_path, dest):
    os.makedirs(dest, exist_ok=True)
    root = os.path.abspath(dest)
    with zipfile.ZipFile(zip_path) as archive:
        if archive.testzip() is not None:
            raise RuntimeError("The hot-fix zip is damaged.")
        members = archive.infolist()
        if not members:
            raise RuntimeError("The hot-fix zip is empty.")
        for info in members:
            name = info.filename.replace("\\", "/").lstrip("/")
            if not name or name.startswith("../") or "/../" in f"/{name}/" or ":" in name.split("/", 1)[0]:
                raise RuntimeError(f"Unsafe path in the hot-fix: {info.filename}")
            target = os.path.abspath(os.path.join(root, *name.split("/")))
            if target != root and not target.startswith(root + os.sep):
                raise RuntimeError(f"Unsafe path in the hot-fix: {info.filename}")
            if name.endswith("/") or info.is_dir():
                os.makedirs(target, exist_ok=True)
                continue
            os.makedirs(os.path.dirname(target), exist_ok=True)
            with archive.open(info) as source, open(target, "wb") as handle:
                shutil.copyfileobj(source, handle)
    _flatten_single_folder(root)
    return root


def _flatten_single_folder(root):
    names = [name for name in os.listdir(root) if name not in (".", "..")]
    if len(names) != 1:
        return
    only = os.path.join(root, names[0])
    if not os.path.isdir(only):
        return
    for name in os.listdir(only):
        shutil.move(os.path.join(only, name), os.path.join(root, name))
    os.rmdir(only)


def restart_command():
    """Command the helper uses after the copy. Frozen builds start the exe."""
    if getattr(sys, "frozen", False):
        exe = os.path.abspath(sys.executable)
        return f'start "" "{exe}"'
    script = os.path.join(app_install_dir(), "readysetpdf.4.0.py")
    python = os.path.abspath(sys.executable)
    return f'start "" "{python}" "{script}"'


def write_update_bat(extracted_dir, install_dir):
    """Write update.bat under %APPDATA%\\ReadySetPDF\\updates.

    The copy target is the program folder. A batch file stored in the updates
    folder cannot use its own folder (%~dp0) as that target.
    """
    folder = updates_dir()
    bat_path = os.path.join(folder, "update.bat")
    extracted = os.path.abspath(extracted_dir)
    install = os.path.abspath(install_dir)
    if not extracted.startswith(os.path.abspath(folder) + os.sep):
        raise RuntimeError("Hot-fix files are not in the updates folder.")
    lines = [
        "@echo off",
        "timeout /t 2 /nobreak > nul",
        f'xcopy /y /s /q "{extracted}\\*.*" "{install}"',
        restart_command(),
        'del "%~f0"',
        "",
    ]
    with open(bat_path, "w", encoding="utf-8", newline="\r\n") as handle:
        handle.write("\r\n".join(lines))
    return bat_path


def stage_update(manifest):
    folder = updates_dir()
    zip_path = os.path.join(folder, "hotfix.zip")
    extracted = os.path.join(folder, "extracted")
    if os.path.isdir(extracted):
        shutil.rmtree(extracted)
    download_patch(manifest["patch_url"], zip_path)
    safe_extract(zip_path, extracted)
    return write_update_bat(extracted, app_install_dir())


def launch_updater(bat_path):
    flags = 0
    if os.name == "nt":
        flags = subprocess.DETACHED_PROCESS | subprocess.CREATE_NEW_PROCESS_GROUP
    subprocess.Popen(
        ["cmd", "/c", bat_path],
        cwd=os.path.dirname(bat_path),
        close_fds=True,
        creationflags=flags,
    )
