"""Structured preflight audit for ReadySetPDF.

Reads the compiled stack through pikepdf-backed inspect helpers. Returns a
machine-readable dict plus a human text report. Does not mutate the PDF.
"""

from __future__ import annotations

from pageboxes import read_page_boxes

from modules.preflight.inspect import (
    cmyk_image_tac_percent,
    page_font_details,
    page_graphics_audit,
)

DPI_WARN = 250
DPI_TARGET = 300
HAIRLINE_PT = 0.25
BLEED_MIN_PT = 9.0  # 0.125 in
TAC_WARN_PCT = 300.0


def _rule(rules, key):
    if not rules:
        return {}
    item = rules.get(key) or {}
    return item if isinstance(item, dict) else {}


def _rule_severity(rules, key, default):
    """Map a recipe severity onto fail / warn, or None when the check is ignored."""
    raw = str(_rule(rules, key).get("severity") or default).strip()
    if raw.lower() in ("ignore",):
        return None
    if raw.lower() in ("error", "error (fail)", "fail"):
        return "fail"
    if raw.lower() in ("warning", "warning (maybe)", "warn", "maybe", "hold"):
        return "warn"
    return default


def _rule_threshold(rules, key, default):
    item = _rule(rules, key)
    if "threshold" not in item or item.get("threshold") in (None, ""):
        return default
    try:
        return float(item["threshold"])
    except (TypeError, ValueError):
        return default


def audit_document(doc, unit="inches", rules=None, profile_name="", filename=""):
    """Full document audit. ``doc`` is a pdfdoc Document (or compatible).

    ``rules`` is an optional recipe rule map. Missing rules keep the built-in
    thresholds. Severity ``Ignore`` drops that finding.
    ``filename`` is the source PDF name stamped onto pages and findings.
    """
    pages = []
    fonts = {}
    images = []
    findings = []
    colors = {
        "has_rgb": False,
        "has_cmyk": False,
        "has_gray": False,
        "spots": set(),
        "spaces": set(),
    }
    transparency = []
    overprint = []
    hairlines = []
    tac = []
    min_dpi = _rule_threshold(rules, "min_image_dpi", DPI_TARGET if rules else DPI_WARN)
    hairline_pt = _rule_threshold(rules, "hairline_pt", HAIRLINE_PT)
    tac_limit = _rule_threshold(rules, "tac_percent", TAC_WARN_PCT)
    bleed_min_pt = _rule_threshold(rules, "check_trim_box", 0.125) * 72.0
    box_severity = _rule_severity(rules, "check_trim_box", "warn")
    font_severity = _rule_severity(rules, "enforce_embedded_fonts", "fail")
    hair_severity = _rule_severity(rules, "hairline_pt", "warn")
    dpi_severity = _rule_severity(rules, "min_image_dpi", "warn")
    tac_severity = _rule_severity(rules, "tac_percent", "warn")
    trans_severity = _rule_severity(rules, "transparency", "info")
    over_severity = _rule_severity(rules, "overprint", "info")
    jpx_severity = _rule_severity(rules, "jpeg2000", "info")
    rgb_severity = _rule_severity(rules, "color_space", "warn")

    for pno in range(len(doc)):
        page = doc[pno]
        boxes = read_page_boxes(page)
        page_info = {
            "page": pno + 1,
            "width_pt": float(page.rect.width),
            "height_pt": float(page.rect.height),
            "boxes": _box_sizes(boxes),
            "bleed": _bleed_status(boxes, bleed_min_pt),
        }
        pages.append(page_info)

        if box_severity and page_info["bleed"]["status"] == "missing":
            findings.append(_finding(
                box_severity, "bleed_missing", pno + 1,
                f"TrimBox has no usable BleedBox margin (need >= {bleed_min_pt:.2f} pt).",
            ))
        elif box_severity and page_info["bleed"]["status"] == "short":
            findings.append(_finding(
                box_severity, "bleed_short", pno + 1,
                f"Bleed is only {page_info['bleed']['min_pt']:.2f} pt on the shortest side.",
            ))

        for font in page_font_details(page):
            name = font["name"]
            entry = fonts.setdefault(name, {
                "name": name,
                "subtype": font.get("subtype"),
                "embedded": bool(font.get("embedded")),
                "subset": bool(font.get("subset")),
                "pages": [],
            })
            entry["embedded"] = entry["embedded"] or bool(font.get("embedded"))
            entry["pages"].append(pno + 1)
            if font_severity and not entry["embedded"]:
                findings.append(_finding(
                    font_severity, "font_not_embedded", pno + 1,
                    f"Font not embedded: {name}",
                    {"font": name, "subtype": font.get("subtype")},
                ))

        gfx = page_graphics_audit(page)
        for spot in gfx.get("spots") or []:
            colors["spots"].add(spot)
        for note in gfx.get("transparency") or []:
            item = dict(note)
            item["page"] = pno + 1
            transparency.append(item)
        for note in gfx.get("overprint") or []:
            item = dict(note)
            item["page"] = pno + 1
            overprint.append(item)
        for note in gfx.get("hairlines") or []:
            item = {"page": pno + 1, "width_pt": float(note.get("width_pt") or 0)}
            if float(item["width_pt"]) < hairline_pt - 1e-6:
                hairlines.append(item)
                if hair_severity:
                    findings.append(_finding(
                        hair_severity, "hairline", pno + 1,
                        f"Hairline stroke ~{item['width_pt']:.3f} pt (under {hairline_pt} pt).",
                        item,
                    ))

        for img in gfx.get("images") or []:
            record = dict(img)
            record["page"] = pno + 1
            images.append(record)
            cs_name = record.get("colorspace_name") or ""
            colors["spaces"].add(cs_name)
            comps = int(record.get("colorspace") or 0)
            if comps == 3 or cs_name.startswith("DeviceRGB") or cs_name.startswith("CalRGB"):
                colors["has_rgb"] = True
            elif comps == 4 or "CMYK" in cs_name or cs_name.startswith("ICCBased/4"):
                colors["has_cmyk"] = True
            elif comps == 1 or "Gray" in cs_name:
                colors["has_gray"] = True
            if record.get("spot"):
                colors["spots"].add(record["spot"])

            dpi = min(float(record.get("dpi_x") or 0), float(record.get("dpi_y") or 0))
            if dpi_severity and dpi > 0 and dpi < min_dpi:
                findings.append(_finding(
                    dpi_severity, "low_dpi", pno + 1,
                    f"Image ~{int(dpi)} PPI effective (< {min_dpi:g}).",
                    {
                        "dpi": dpi,
                        "xref": record.get("xref"),
                        "filter": record.get("filter"),
                        "colorspace": cs_name,
                    },
                ))

            filt = record.get("filter") or ""
            if "DCTDecode" in filt and colors["has_cmyk"] is False and comps == 3:
                # JPEG RGB is common and already covered by RGB warning; note compression.
                pass
            if jpx_severity and "JPXDecode" in filt:
                findings.append(_finding(
                    jpx_severity, "jpeg2000", pno + 1,
                    "JPEG 2000 image compression present (confirm RIP support).",
                    {"xref": record.get("xref")},
                ))

            if comps == 4 or "CMYK" in cs_name or cs_name.startswith("ICCBased/4"):
                tac_pct = cmyk_image_tac_percent(page, record.get("xref"))
                if tac_pct is not None:
                    tac.append({"page": pno + 1, "xref": record.get("xref"), "max_pct": tac_pct})
                    if tac_severity and tac_pct > tac_limit:
                        findings.append(_finding(
                            tac_severity, "tac_high", pno + 1,
                            f"CMYK image TAC ~{tac_pct:.0f}% (over {tac_limit:.0f}%).",
                            {"xref": record.get("xref"), "max_pct": tac_pct},
                        ))

        if trans_severity and gfx.get("transparency"):
            findings.append(_finding(
                trans_severity, "transparency", pno + 1,
                "Transparency / soft mask / non-Normal blend mode detected.",
            ))
        if over_severity and gfx.get("overprint"):
            findings.append(_finding(
                over_severity, "overprint", pno + 1,
                "Overprint settings detected on this page.",
            ))

    if rgb_severity and colors["has_rgb"]:
        findings.append(_finding(
            rgb_severity, "rgb_color", None,
            "RGB color space detected. Use Color tab for CMYK conversion.",
        ))

    result = {
        "version": 1,
        "page_count": len(doc),
        "unit": unit,
        "pages": pages,
        "fonts": [fonts[name] for name in sorted(fonts)],
        "images": images,
        "colors": {
            "has_rgb": colors["has_rgb"],
            "has_cmyk": colors["has_cmyk"],
            "has_gray": colors["has_gray"],
            "spots": sorted(colors["spots"]),
            "spaces": sorted(colors["spaces"]),
        },
        "transparency": transparency,
        "overprint": overprint,
        "hairlines": hairlines,
        "tac": tac,
        "findings": findings,
        "counts": _count_findings(findings),
        "suggestions": _suggestions(findings, colors),
        "profile_name": profile_name or "",
        "min_image_dpi": min_dpi,
        "hairline_pt": hairline_pt,
        "tac_limit": tac_limit,
        "bleed_min_pt": bleed_min_pt,
    }
    from modules.preflight.recipes import verdict_for
    _stamp_filename(result, filename)
    result["verdict"] = verdict_for(result)
    result["report_text"] = format_report_text(result, unit=unit)
    return result


def _stamp_filename(result, filename):
    name = str(filename or "").strip()
    if not name:
        return
    result["filename"] = name
    for key in ("pages", "images", "transparency", "overprint", "hairlines", "tac", "findings"):
        for item in result.get(key) or []:
            if isinstance(item, dict):
                item["file"] = name


def format_report_text(audit, unit="inches"):
    """Human-readable report. Keeps the classic color / DPI / fonts sections."""
    dpi_limit = float(audit.get("min_image_dpi") or DPI_WARN)
    hair_limit = float(audit.get("hairline_pt") or HAIRLINE_PT)
    tac_limit = float(audit.get("tac_limit") or TAC_WARN_PCT)
    profile = audit.get("profile_name") or ""
    raw_verdict = str(audit.get("verdict") or "").strip()
    from modules.preflight.recipes import verdict_label
    verdict = verdict_label(raw_verdict).upper() if raw_verdict else "PASS"
    filename = str(audit.get("filename") or "").strip()
    lines = [
        "=== READYSETPDF PREFLIGHT REPORT ===",
    ]
    if filename:
        lines.append(f"File: {filename}")
    lines.append(f"Total Pages: {audit.get('page_count', 0)}")
    lines.append(f"Findings: {_counts_phrase(audit.get('counts') or {})}")
    if profile:
        lines.append(f"Recipe: {profile} · Result: {verdict}")
    lines.append("")

    for page in audit.get("pages") or []:
        w = _fmt_len(page.get("width_pt") or 0, unit)
        h = _fmt_len(page.get("height_pt") or 0, unit)
        page_label = f"Page {page['page']}"
        if filename:
            page_label = f"{filename} — {page_label}"
        lines.append(f"{page_label}: {w} x {h}")
        boxes = page.get("boxes") or {}
        bleed = page.get("bleed") or {}
        lines.append(
            "   Boxes: Media {media} · Crop {crop} · Trim {trim} · Bleed {bleed}".format(
                media=_fmt_box(boxes.get("mediabox"), unit),
                crop=_fmt_box(boxes.get("cropbox"), unit),
                trim=_fmt_box(boxes.get("trimbox"), unit),
                bleed=_fmt_box(boxes.get("bleedbox"), unit),
            )
        )
        status = bleed.get("status")
        if status == "ok":
            lines.append(f"   Bleed: OK (min {_fmt_len(bleed.get('min_pt') or 0, unit)})")
        elif status == "short":
            lines.append(f"   Bleed: SHORT (min {_fmt_len(bleed.get('min_pt') or 0, unit)})")
        elif status == "missing":
            lines.append("   Bleed: MISSING / none beyond TrimBox")
        else:
            lines.append("   Bleed: n/a")

    colors = audit.get("colors") or {}
    rgb_finding = next((item for item in audit.get("findings") or [] if item.get("code") == "rgb_color"), None)
    lines.append("\n=== COLOR SPACE ===")
    if colors.get("has_rgb") and rgb_finding is None:
        lines.append("RGB color space present (ignored by this recipe).")
    elif rgb_finding and rgb_finding.get("severity") == "fail":
        lines.append("⚠️ ERROR: RGB color space detected.")
        lines.append("   (Use Color tab for CMYK conversion)")
    elif colors.get("has_rgb"):
        lines.append("⚠️ HOLD: RGB color space detected.")
        lines.append("   (Use Color tab for CMYK conversion)")
    elif colors.get("has_cmyk"):
        lines.append("✅ PASS: CMYK color space detected. No RGB found.")
    else:
        lines.append("✅ PASS: Grayscale/Monochrome document.")
    spots = colors.get("spots") or []
    if spots:
        lines.append("Spot / Separation colors:")
        for name in spots:
            lines.append(f"   - {name}")
    spaces = colors.get("spaces") or []
    if spaces:
        lines.append("Color spaces seen: " + ", ".join(spaces[:24]))

    low = [f for f in audit.get("findings") or [] if f.get("code") == "low_dpi"]
    lines.append("\n=== IMAGE RESOLUTION ===")
    if low:
        mark = "ERROR" if any(item.get("severity") == "fail" for item in low) else "HOLD"
        lines.append(f"⚠️ {mark}: {len(low)} low-resolution image instances (< {dpi_limit:g} DPI).")
        for item in low:
            dpi = (item.get("details") or {}).get("dpi")
            page = item.get("page")
            lines.append(f"   - Page {page}: ~{int(dpi or 0)} DPI")
    else:
        lines.append(f"✅ PASS: All image instances are >= {dpi_limit:g} DPI.")

    images = audit.get("images") or []
    if images:
        lines.append("\n=== IMAGE INVENTORY ===")
        for img in images[:40]:
            dpi = min(float(img.get("dpi_x") or 0), float(img.get("dpi_y") or 0))
            lines.append(
                "   p{page}: {w}×{h}px · ~{dpi} PPI · {cs} · {filt}".format(
                    page=img.get("page"),
                    w=img.get("width"),
                    h=img.get("height"),
                    dpi=int(dpi),
                    cs=img.get("colorspace_name") or "?",
                    filt=img.get("filter") or "None",
                )
            )
        if len(images) > 40:
            lines.append(f"   … {len(images) - 40} more images")

    fonts = audit.get("fonts") or []
    lines.append("\n=== FONTS DETECTED ===")
    if fonts:
        for font in fonts:
            flags = []
            if font.get("embedded"):
                flags.append("embedded")
            else:
                flags.append("NOT EMBEDDED")
            if font.get("subset"):
                flags.append("subset")
            flags.append(font.get("subtype") or "?")
            lines.append(f"   - {font['name']} ({', '.join(flags)})")
    else:
        lines.append("   No fonts detected. (Fully rasterized or pure vector art)")

    hairlines = audit.get("hairlines") or []
    lines.append("\n=== LINE WEIGHTS ===")
    if hairlines:
        hair_findings = [item for item in audit.get("findings") or [] if item.get("code") == "hairline"]
        mark = "ERROR" if any(item.get("severity") == "fail" for item in hair_findings) else "HOLD"
        lines.append(f"⚠️ {mark}: {len(hairlines)} hairline stroke(s) under {hair_limit:g} pt.")
        for item in hairlines[:20]:
            lines.append(f"   - Page {item['page']}: ~{item['width_pt']:.3f} pt")
    else:
        lines.append(f"✅ PASS: No stroked paths under {hair_limit:g} pt detected.")

    lines.append("\n=== TRANSPARENCY / OVERPRINT ===")
    transparency = audit.get("transparency") or []
    overprint = audit.get("overprint") or []
    if transparency:
        lines.append(f"ℹ️ {len(transparency)} transparency / soft-mask / blend note(s).")
        seen = set()
        for item in transparency[:15]:
            key = (item.get("page"), item.get("detail"))
            if key in seen:
                continue
            seen.add(key)
            lines.append(f"   - Page {item.get('page')}: {item.get('detail')}")
    else:
        lines.append("✅ PASS: No ExtGState transparency flags found.")
    if overprint:
        lines.append(f"ℹ️ {len(overprint)} overprint flag(s).")
        for item in overprint[:10]:
            lines.append(f"   - Page {item.get('page')}: {item.get('detail')}")
    else:
        lines.append("   No overprint flags found.")

    tac = audit.get("tac") or []
    lines.append("\n=== TOTAL AREA COVERAGE (CMYK images) ===")
    if tac:
        for item in tac:
            mark = "⚠️" if float(item.get("max_pct") or 0) > tac_limit else "✅"
            lines.append(
                f"   {mark} Page {item['page']} xref {item['xref']}: max ~{item['max_pct']:.0f}%"
            )
    else:
        lines.append("   No readable Flate/uncompressed CMYK image samples (skipped).")

    suggestions = audit.get("suggestions") or []
    if suggestions:
        lines.append("\n=== SUGGESTED NEXT STEPS ===")
        for tip in suggestions:
            lines.append(f"   • {tip}")

    lines.append("\n--- END OF REPORT ---")
    return "\n".join(lines)


def _finding(severity, code, page, message, details=None):
    return {
        "severity": severity,
        "code": code,
        "page": page,
        "message": message,
        "details": details or {},
    }


def _count_findings(findings):
    counts = {"fail": 0, "warn": 0, "info": 0}
    for item in findings:
        key = item.get("severity") or "info"
        counts[key] = counts.get(key, 0) + 1
    return counts


def _counts_phrase(counts):
    return (
        f"{counts.get('fail', 0)} fail · "
        f"{counts.get('warn', 0)} hold · "
        f"{counts.get('info', 0)} info"
    )


def _suggestions(findings, colors):
    tips = []
    codes = {item.get("code") for item in findings}
    if colors.get("has_rgb") or "rgb_color" in codes:
        tips.append("Open the Color tab and convert RGB to the press CMYK profile.")
    if "bleed_missing" in codes or "bleed_short" in codes:
        tips.append("Use Page Geometry / Box Settings (or rebuild with bleed) before plating.")
    if "font_not_embedded" in codes:
        tips.append("Re-export the PDF with fonts embedded, or outline text in the design app.")
    if "low_dpi" in codes:
        tips.append("Replace low-PPI images with 300 PPI (or higher) print assets.")
    if "hairline" in codes:
        tips.append("Thicken strokes to at least 0.25 pt at final size.")
    if "tac_high" in codes:
        tips.append("Reduce rich blacks / heavy CMYK builds below 300% TAC.")
    if "transparency" in codes:
        tips.append("Confirm the RIP flattens transparency, or flatten before output.")
    return tips


def _box_sizes(boxes):
    out = {}
    for key in ("mediabox", "cropbox", "trimbox", "bleedbox", "artbox"):
        rect = boxes.get(key)
        if rect is None:
            out[key] = None
        else:
            out[key] = {
                "width_pt": float(rect.width),
                "height_pt": float(rect.height),
                "x0": float(rect.x0),
                "y0": float(rect.y0),
                "x1": float(rect.x1),
                "y1": float(rect.y1),
            }
    return out


def _bleed_status(boxes, min_required_pt=BLEED_MIN_PT):
    trim = boxes.get("trimbox") or boxes.get("cropbox")
    bleed = boxes.get("bleedbox")
    if trim is None:
        return {"status": "n/a", "min_pt": 0.0}
    if bleed is None:
        return {"status": "missing", "min_pt": 0.0}
    # Boxes are in page-space y-down via pageboxes; margins are absolute deltas.
    left = float(trim.x0) - float(bleed.x0)
    right = float(bleed.x1) - float(trim.x1)
    top = float(trim.y0) - float(bleed.y0)
    bottom = float(bleed.y1) - float(trim.y1)
    # Depending on flip, top/bottom may swap sign meaning; take absolute.
    margins = [abs(left), abs(right), abs(top), abs(bottom)]
    min_pt = min(margins) if margins else 0.0
    # Identical boxes → no bleed
    same = (
        abs(float(trim.x0) - float(bleed.x0)) < 0.5
        and abs(float(trim.y0) - float(bleed.y0)) < 0.5
        and abs(float(trim.x1) - float(bleed.x1)) < 0.5
        and abs(float(trim.y1) - float(bleed.y1)) < 0.5
    )
    if same or min_pt < 0.5:
        return {"status": "missing", "min_pt": 0.0}
    if min_pt + 1e-6 < float(min_required_pt):
        return {"status": "short", "min_pt": min_pt}
    return {"status": "ok", "min_pt": min_pt}


def _unit_suffix(unit):
    if unit == "mm":
        return "mm"
    if unit == "points":
        return "pt"
    return "in"


def _from_points(points, unit):
    if unit == "points":
        return float(points)
    if unit == "mm":
        return float(points) / 72.0 * 25.4
    return float(points) / 72.0


def _fmt_len(points, unit):
    return f"{_from_points(points, unit):.2f} {_unit_suffix(unit)}"


def _fmt_box(box, unit):
    if not box:
        return "—"
    return (
        f"{_from_points(box['width_pt'], unit):.2f}×"
        f"{_from_points(box['height_pt'], unit):.2f} {_unit_suffix(unit)}"
    )
