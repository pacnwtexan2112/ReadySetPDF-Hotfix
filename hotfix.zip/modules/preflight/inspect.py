"""Page fonts, images, graphics flags, and hairlines from the pikepdf object tree.

BaseFont names come from the font resource tree. Each painted image reports
its pixel size, colorspace, filter, and axis-aligned box in page space (y down).
"""

import pikepdf

from pageboxes import _pike_page, _quad, _rotation


_IDENTITY = (1.0, 0.0, 0.0, 1.0, 0.0, 0.0)
_STROKE_OPS = frozenset({"S", "s", "B", "b", "B*", "b*"})
_FILL_STROKE_OPS = frozenset({"B", "b", "B*", "b*"})
_PATH_BUILD = frozenset({"m", "l", "c", "v", "y", "re", "h", "n", "f", "F", "f*"})


def page_font_names(page):
    """BaseFont names on the page, including fonts inside form XObjects."""
    return sorted({item["name"] for item in page_font_details(page) if item.get("name")})


def page_font_details(page):
    """Font records: name, subtype, embedded, subset, pages resource path."""
    pike, owned = _pike_page(page)
    try:
        found = {}
        _collect_font_details(pike.obj.get("/Resources"), set(), found)
        return [found[key] for key in sorted(found)]
    finally:
        if owned is not None:
            owned.close()


def page_image_placements(page):
    """Each painted image: pixel size, component count, xref, and page-space box."""
    pike, owned = _pike_page(page)
    try:
        crop = _quad(pike.cropbox)
        rotation = _rotation(pike)
        placements = []
        flags = {"transparency": [], "overprint": [], "hairlines": [], "spots": set()}
        _walk_content(
            _contents_bytes(pike.obj.get("/Contents")),
            pike.obj.get("/Resources"),
            _IDENTITY,
            crop,
            rotation,
            placements,
            flags,
            set(),
            0,
            {"lw": 1.0, "gs": None},
        )
        _collect_resource_spots(pike.obj.get("/Resources"), set(), flags["spots"])
        return placements
    finally:
        if owned is not None:
            owned.close()


def page_graphics_audit(page):
    """Images plus transparency, overprint, hairlines, and spot color names."""
    pike, owned = _pike_page(page)
    try:
        crop = _quad(pike.cropbox)
        rotation = _rotation(pike)
        placements = []
        flags = {"transparency": [], "overprint": [], "hairlines": [], "spots": set()}
        group = pike.obj.get("/Group")
        if group is not None and _name(group.get("/S")) == "Transparency":
            flags["transparency"].append({"kind": "page_group", "detail": "Page transparency group"})
        _walk_content(
            _contents_bytes(pike.obj.get("/Contents")),
            pike.obj.get("/Resources"),
            _IDENTITY,
            crop,
            rotation,
            placements,
            flags,
            set(),
            0,
            {"lw": 1.0, "gs": None},
        )
        _collect_resource_spots(pike.obj.get("/Resources"), set(), flags["spots"])
        _scan_extgstate_resources(pike.obj.get("/Resources"), set(), flags)
        return {
            "images": placements,
            "transparency": flags["transparency"],
            "overprint": flags["overprint"],
            "hairlines": flags["hairlines"],
            "spots": sorted(flags["spots"]),
        }
    finally:
        if owned is not None:
            owned.close()


def _name(value):
    if value is None:
        return ""
    return str(value).lstrip("/")


def _base_font(font):
    try:
        kids = font.get("/DescendantFonts")
        if kids:
            nested = _base_font(kids[0])
            if nested:
                return nested
        base = font.get("/BaseFont")
        if base is not None:
            return str(base).lstrip("/")
    except Exception:
        return None
    return None


_STANDARD_14 = frozenset({
    "Times-Roman", "Times-Bold", "Times-Italic", "Times-BoldItalic",
    "Helvetica", "Helvetica-Bold", "Helvetica-Oblique", "Helvetica-BoldOblique",
    "Courier", "Courier-Bold", "Courier-Oblique", "Courier-BoldOblique",
    "Symbol", "ZapfDingbats",
})


def _font_embedded(font):
    try:
        kids = font.get("/DescendantFonts")
        if kids:
            if _font_embedded(kids[0]):
                return True
        descriptor = font.get("/FontDescriptor")
        if descriptor is None:
            name = _base_font(font) or ""
            # PDF Standard 14 may omit a descriptor and still print.
            return name in _STANDARD_14
        for key in ("/FontFile", "/FontFile2", "/FontFile3"):
            if descriptor.get(key) is not None:
                return True
    except Exception:
        return False
    return False


def _looks_subset(name):
    text = str(name or "")
    return len(text) > 7 and text[6] == "+"


def _font_subtype(font):
    try:
        kids = font.get("/DescendantFonts")
        if kids:
            nested = _font_subtype(kids[0])
            if nested:
                return nested
        return _name(font.get("/Subtype")) or "Unknown"
    except Exception:
        return "Unknown"


def _collect_fonts(resources, seen, found):
    for item in _iter_font_objects(resources, seen):
        name = item.get("name")
        if name:
            found.add(name)


def _collect_font_details(resources, seen, found):
    for item in _iter_font_objects(resources, seen):
        name = item.get("name")
        if not name:
            continue
        previous = found.get(name)
        if previous is None:
            found[name] = item
            continue
        previous["embedded"] = previous["embedded"] or item["embedded"]


def _iter_font_objects(resources, seen):
    if resources is None:
        return
    marker = id(resources)
    if marker in seen:
        return
    seen.add(marker)
    try:
        fonts = resources.get("/Font") or {}
        for key, font in fonts.items():
            name = _base_font(font) or str(key).lstrip("/")
            yield {
                "name": name,
                "subtype": _font_subtype(font),
                "embedded": _font_embedded(font),
                "subset": _looks_subset(name),
            }
        xobjects = resources.get("/XObject") or {}
        for _key, obj in xobjects.items():
            if _name(obj.get("/Subtype")) == "Form":
                yield from _iter_font_objects(obj.get("/Resources"), seen)
    except Exception:
        return


def _colorspace_label(cs, depth=0):
    if cs is None or depth > 6:
        return "Unknown", 3, None
    name = _name(cs)
    if name in ("DeviceGray", "G"):
        return "DeviceGray", 1, None
    if name in ("DeviceRGB", "RGB"):
        return "DeviceRGB", 3, None
    if name in ("DeviceCMYK", "CMYK"):
        return "DeviceCMYK", 4, None
    if name == "CalGray":
        return "CalGray", 1, None
    if name in ("CalRGB",):
        return "CalRGB", 3, None
    if name == "Lab":
        return "Lab", 3, None
    try:
        kind = _name(cs[0])
        if kind == "ICCBased":
            n = int(cs[1].get("/N") or 3)
            return f"ICCBased/{n}", n, None
        if kind == "Indexed":
            base_label, base_n, spot = _colorspace_label(cs[1], depth + 1)
            return f"Indexed/{base_label}", base_n, spot
        if kind == "Separation":
            spot = _name(cs[1]) or "Spot"
            return f"Separation/{spot}", 1, spot
        if kind == "DeviceN":
            names = [_name(item) for item in list(cs[1])]
            return "DeviceN/" + "+".join(names[:8]), max(1, len(names)), None
        if kind in ("CalRGB", "Lab"):
            return kind, 3, None
        if kind == "CalGray":
            return kind, 1, None
    except Exception:
        return "Unknown", 3, None
    return name or "Unknown", 3, None


def _colorspace_components(cs, depth=0):
    return _colorspace_label(cs, depth)[1]


def _filter_names(value):
    if value is None:
        return []
    try:
        if isinstance(value, pikepdf.Array):
            return [_name(item) for item in value]
        return [_name(value)]
    except Exception:
        return []


def _contents_bytes(contents):
    if contents is None:
        return b""
    try:
        if isinstance(contents, pikepdf.Array):
            return b"\n".join(_stream_bytes(item) for item in contents)
        return _stream_bytes(contents)
    except Exception:
        return b""


def _stream_bytes(obj):
    try:
        return obj.read_bytes()
    except Exception:
        return b""


def _lookup(resources, name, table_name="/XObject"):
    if resources is None:
        return None
    try:
        table = resources.get(table_name)
    except Exception:
        return None
    if table is None:
        return None
    key = name if str(name).startswith("/") else "/" + str(name)
    try:
        return table[pikepdf.Name(key)]
    except Exception:
        try:
            return table.get(pikepdf.Name(key))
        except Exception:
            return None


def _mul(left, right):
    """Matrix product. ``right`` is applied to the point first."""
    a1, b1, c1, d1, e1, f1 = left
    a2, b2, c2, d2, e2, f2 = right
    return (
        a1 * a2 + c1 * b2,
        b1 * a2 + d1 * b2,
        a1 * c2 + c1 * d2,
        b1 * c2 + d1 * d2,
        a1 * e2 + c1 * f2 + e1,
        b1 * e2 + d1 * f2 + f1,
    )


def _apply(matrix, x, y):
    a, b, c, d, e, f = matrix
    return (a * x + c * y + e, b * x + d * y + f)


def _scale_of(matrix):
    a, b, c, d, _e, _f = matrix
    sx = (a * a + b * b) ** 0.5
    sy = (c * c + d * d) ** 0.5
    return max(sx, sy, 1e-9)


def _pdf_to_page(x, y, crop, rotation):
    # Image boxes follow the unrotated crop. Page rotation does not move them.
    del rotation
    cx0, _cy0, _cx1, cy1 = crop
    return x - cx0, cy1 - y


def _placement_box(ctm, crop, rotation):
    corners = [_apply(ctm, x, y) for x, y in ((0, 0), (1, 0), (1, 1), (0, 1))]
    mapped = [_pdf_to_page(x, y, crop, rotation) for x, y in corners]
    xs = [point[0] for point in mapped]
    ys = [point[1] for point in mapped]
    return min(xs), min(ys), max(xs), max(ys)


def _obj_id(obj):
    try:
        return tuple(obj.objgen)
    except Exception:
        return id(obj)


def _image_record(obj, ctm, crop, rotation):
    x0, y0, x1, y1 = _placement_box(ctm, crop, rotation)
    width_pt = max(0.0, x1 - x0)
    height_pt = max(0.0, y1 - y0)
    px_w = int(obj.get("/Width") or 0)
    px_h = int(obj.get("/Height") or 0)
    label, components, spot = _colorspace_label(obj.get("/ColorSpace"))
    filters = _filter_names(obj.get("/Filter"))
    obj_num = 0
    try:
        obj_num = int(obj.objgen[0])
    except Exception:
        obj_num = 0
    dpi_x = (px_w / (width_pt / 72.0)) if width_pt > 0.01 else 0.0
    dpi_y = (px_h / (height_pt / 72.0)) if height_pt > 0.01 else 0.0
    return {
        "width": px_w,
        "height": px_h,
        "colorspace": components,
        "colorspace_name": label,
        "spot": spot,
        "filter": ",".join(filters) if filters else "None",
        "filters": filters,
        "xref": obj_num,
        "bbox": (x0, y0, x1, y1),
        "width_pt": width_pt,
        "height_pt": height_pt,
        "dpi_x": dpi_x,
        "dpi_y": dpi_y,
        "has_smask": obj.get("/SMask") is not None,
        "bits": int(obj.get("/BitsPerComponent") or 8),
    }


def _extgstate_notes(gs, flags):
    if gs is None:
        return
    try:
        ca = gs.get("/ca")
        CA = gs.get("/CA")
        if ca is not None and float(ca) < 0.999:
            flags["transparency"].append({"kind": "fill_alpha", "detail": f"Fill opacity {float(ca):.2f}"})
        if CA is not None and float(CA) < 0.999:
            flags["transparency"].append({"kind": "stroke_alpha", "detail": f"Stroke opacity {float(CA):.2f}"})
        bm = gs.get("/BM")
        if bm is not None:
            mode = _name(bm) if not isinstance(bm, pikepdf.Array) else _name(bm[0] if bm else "Normal")
            if mode and mode != "Normal":
                flags["transparency"].append({"kind": "blend_mode", "detail": f"Blend mode {mode}"})
        if gs.get("/SMask") is not None and _name(gs.get("/SMask")) != "None":
            flags["transparency"].append({"kind": "soft_mask", "detail": "ExtGState soft mask"})
        op = gs.get("/OP")
        fill_op = gs.get("/op")
        if op is True or (op is not None and bool(op)):
            flags["overprint"].append({"kind": "stroke_overprint", "detail": "Stroke overprint"})
        if fill_op is True or (fill_op is not None and bool(fill_op)):
            flags["overprint"].append({"kind": "fill_overprint", "detail": "Fill overprint"})
    except Exception:
        return


def _scan_extgstate_resources(resources, seen, flags):
    if resources is None:
        return
    marker = id(resources)
    if marker in seen:
        return
    seen.add(marker)
    try:
        states = resources.get("/ExtGState") or {}
        for _key, gs in states.items():
            _extgstate_notes(gs, flags)
        xobjects = resources.get("/XObject") or {}
        for _key, obj in xobjects.items():
            if _name(obj.get("/Subtype")) == "Form":
                group = obj.get("/Group")
                if group is not None and _name(group.get("/S")) == "Transparency":
                    flags["transparency"].append({"kind": "form_group", "detail": "Form transparency group"})
                _scan_extgstate_resources(obj.get("/Resources"), seen, flags)
    except Exception:
        return


def _collect_resource_spots(resources, seen, spots):
    if resources is None:
        return
    marker = id(resources)
    if marker in seen:
        return
    seen.add(marker)
    try:
        spaces = resources.get("/ColorSpace") or {}
        for _key, cs in spaces.items():
            _label, _n, spot = _colorspace_label(cs)
            if spot:
                spots.add(spot)
            if _name(cs[0] if hasattr(cs, "__getitem__") else "") == "DeviceN":
                try:
                    for item in list(cs[1]):
                        name = _name(item)
                        if name and name not in ("None", "All"):
                            spots.add(name)
                except Exception:
                    pass
        xobjects = resources.get("/XObject") or {}
        for _key, obj in xobjects.items():
            if _name(obj.get("/Subtype")) == "Form":
                _collect_resource_spots(obj.get("/Resources"), seen, spots)
            elif _name(obj.get("/Subtype")) == "Image":
                _label, _n, spot = _colorspace_label(obj.get("/ColorSpace"))
                if spot:
                    spots.add(spot)
    except Exception:
        return


def _note_hairline(ctm, line_width, flags):
    effective = float(line_width) * _scale_of(ctm)
    if 0 < effective < 0.25:
        flags["hairlines"].append({"width_pt": effective})


def _walk_content(data, resources, ctm, crop, rotation, placements, flags, active, depth, state):
    if depth > 12 or not data:
        return
    graphics = [ctm]
    gstate = [dict(state)]
    stack = []
    for kind, value in _tokens(data):
        if kind == "num":
            stack.append(value)
            continue
        if kind == "name":
            stack.append(value)
            continue
        if value == "q":
            graphics.append(graphics[-1])
            gstate.append(dict(gstate[-1]))
            stack.clear()
            continue
        if value == "Q":
            if len(graphics) > 1:
                graphics.pop()
            if len(gstate) > 1:
                gstate.pop()
            stack.clear()
            continue
        if value == "cm" and len(stack) >= 6:
            nums = [float(item) for item in stack[-6:]]
            graphics[-1] = _mul(graphics[-1], tuple(nums))
            stack.clear()
            continue
        if value == "w" and stack:
            gstate[-1]["lw"] = float(stack[-1])
            stack.clear()
            continue
        if value == "gs" and stack:
            name = stack[-1]
            stack.clear()
            gs = _lookup(resources, name, "/ExtGState")
            gstate[-1]["gs"] = gs
            _extgstate_notes(gs, flags)
            continue
        if value in _STROKE_OPS or value in _FILL_STROKE_OPS:
            _note_hairline(graphics[-1], gstate[-1].get("lw", 1.0), flags)
            stack.clear()
            continue
        if value == "Do" and stack:
            name = stack[-1]
            stack.clear()
            obj = _lookup(resources, name)
            if obj is None:
                continue
            subtype = _name(obj.get("/Subtype"))
            if subtype == "Image":
                record = _image_record(obj, graphics[-1], crop, rotation)
                placements.append(record)
                if record.get("spot"):
                    flags["spots"].add(record["spot"])
                if record.get("has_smask"):
                    flags["transparency"].append({
                        "kind": "image_smask",
                        "detail": f"Image soft mask (xref {record['xref']})",
                    })
                continue
            if subtype == "Form":
                marker = _obj_id(obj)
                if marker in active:
                    continue
                matrix = obj.get("/Matrix")
                form_matrix = _IDENTITY
                if matrix is not None:
                    try:
                        form_matrix = tuple(float(item) for item in list(matrix)[:6])
                    except Exception:
                        form_matrix = _IDENTITY
                group = obj.get("/Group")
                if group is not None and _name(group.get("/S")) == "Transparency":
                    flags["transparency"].append({"kind": "form_group", "detail": "Form transparency group"})
                active.add(marker)
                try:
                    _walk_content(
                        _stream_bytes(obj),
                        obj.get("/Resources") or resources,
                        _mul(graphics[-1], form_matrix),
                        crop,
                        rotation,
                        placements,
                        flags,
                        active,
                        depth + 1,
                        dict(gstate[-1]),
                    )
                finally:
                    active.discard(marker)
            continue
        if value in _PATH_BUILD:
            stack.clear()
            continue
        stack.clear()


def _tokens(data):
    index = 0
    length = len(data)
    while index < length:
        char = data[index]
        if char in b" \t\r\n\f\0":
            index += 1
            continue
        if char == 37:  # %
            while index < length and data[index] not in b"\r\n":
                index += 1
            continue
        if char == 40:  # (
            index += 1
            depth = 1
            while index < length and depth:
                if data[index] == 92:
                    index += 2
                    continue
                if data[index] == 40:
                    depth += 1
                elif data[index] == 41:
                    depth -= 1
                index += 1
            yield ("str", b"")
            continue
        if char == 60:  # <
            if index + 1 < length and data[index + 1] == 60:
                yield ("op", "<<")
                index += 2
                continue
            index += 1
            while index < length and data[index] != 62:
                index += 1
            index += 1
            yield ("str", b"")
            continue
        if char == 62 and index + 1 < length and data[index + 1] == 62:
            yield ("op", ">>")
            index += 2
            continue
        if char == 91:
            yield ("op", "[")
            index += 1
            continue
        if char == 93:
            yield ("op", "]")
            index += 1
            continue
        if char == 47:  # /
            index += 1
            start = index
            while index < length and data[index] not in b" \t\r\n\f\0()<>[]{}/%":
                index += 1
            yield ("name", data[start:index].decode("latin-1", "replace"))
            continue
        start = index
        if char in b"+-." or 48 <= char <= 57:
            index += 1
            while index < length and data[index] in b"0123456789.+-eE":
                index += 1
            word = data[start:index].decode("latin-1", "replace")
            try:
                number = float(word) if any(item in word for item in ".eE") else int(word)
            except ValueError:
                yield ("op", word)
            else:
                yield ("num", number)
            continue
        while index < length and data[index] not in b" \t\r\n\f\0()<>[]{}/%":
            index += 1
        yield ("op", data[start:index].decode("latin-1", "replace"))


def cmyk_image_tac_percent(page, xref, max_pixels=2_000_000):
    """Max C+M+Y+K coverage (%) for a Flate/uncompressed 8-bit CMYK image, or None."""
    pike, owned = _pike_page(page)
    try:
        return _tac_from_page(pike, int(xref or 0), max_pixels)
    finally:
        if owned is not None:
            owned.close()


def _tac_from_page(pike, xref, max_pixels):
    if xref <= 0:
        return None
    try:
        obj = pike.obj.objgen  # touch page
        del obj
    except Exception:
        pass
    resources = pike.obj.get("/Resources")
    image = _find_image_xref(resources, set(), xref)
    if image is None:
        return None
    label, components, _spot = _colorspace_label(image.get("/ColorSpace"))
    if components != 4 and not label.startswith("DeviceCMYK") and "ICCBased/4" not in label:
        return None
    filters = _filter_names(image.get("/Filter"))
    if any(item in ("DCTDecode", "JPXDecode", "CCITTFaxDecode", "JBIG2Decode") for item in filters):
        return None
    width = int(image.get("/Width") or 0)
    height = int(image.get("/Height") or 0)
    bpc = int(image.get("/BitsPerComponent") or 8)
    if width <= 0 or height <= 0 or bpc != 8:
        return None
    if width * height > max_pixels:
        return None
    try:
        data = image.read_bytes()
    except Exception:
        return None
    stride = width * 4
    expected = stride * height
    if len(data) < expected:
        return None
    max_sum = 0
    for row in range(height):
        base = row * stride
        for col in range(0, stride, 4):
            i = base + col
            total = data[i] + data[i + 1] + data[i + 2] + data[i + 3]
            if total > max_sum:
                max_sum = total
    return (max_sum / 255.0) * 100.0


def _find_image_xref(resources, seen, xref):
    if resources is None:
        return None
    marker = id(resources)
    if marker in seen:
        return None
    seen.add(marker)
    try:
        xobjects = resources.get("/XObject") or {}
        for _key, obj in xobjects.items():
            subtype = _name(obj.get("/Subtype"))
            try:
                obj_num = int(obj.objgen[0])
            except Exception:
                obj_num = 0
            if subtype == "Image" and obj_num == xref:
                return obj
            if subtype == "Form":
                found = _find_image_xref(obj.get("/Resources"), seen, xref)
                if found is not None:
                    return found
    except Exception:
        return None
    return None
