"""Saved preflight recipes: thresholds, severities, routing, and triggers.

Stored at %APPDATA%\\ReadySetPDF\\preflight_recipes.json.
"""

from __future__ import annotations

import fnmatch
import json
import os
import shutil

import licensing

STORE_NAME = "preflight_recipes.json"

SEVERITY_UI = ("Error (Fail)", "Hold", "Ignore")
_SEVERITY_TO_STORE = {
    "Error (Fail)": "Error",
    "Warning (Maybe)": "Warning",
    "Hold": "Warning",
    "Ignore": "Ignore",
    "Error": "Error",
    "Warning": "Warning",
    "Fail": "Error",
    "Maybe": "Warning",
}
_STORE_TO_UI = {
    "Error": "Error (Fail)",
    "Warning": "Hold",
    "Ignore": "Ignore",
}

SOURCE_MODES = ("manual", "hotfolder", "api")
# Shown in the recipe editor. "api" stays valid for run_recipe_on_paths if a
# saved recipe or another program still asks for it.
UI_SOURCE_MODES = ("manual", "hotfolder")

# key, label, has numeric threshold, default threshold text, default severity
RULE_SPECS = (
    ("min_image_dpi", "Minimum image DPI", True, "300", "Error"),
    ("enforce_embedded_fonts", "Font embedding", False, "", "Error"),
    ("check_trim_box", "Box inspection / bleed (in)", True, "0.125", "Warning"),
    ("color_space", "Color space (RGB)", False, "", "Warning"),
    ("hairline_pt", "Hairline stroke (pt)", True, "0.25", "Warning"),
    ("tac_percent", "Max CMYK TAC %", True, "300", "Warning"),
    ("transparency", "Transparency / soft mask", False, "", "Warning"),
    ("overprint", "Overprint", False, "", "Ignore"),
    ("jpeg2000", "JPEG 2000 compression", False, "", "Warning"),
)


def store_path(directory=None):
    root = directory or licensing.app_dir()
    return os.path.join(root, STORE_NAME)


def ui_severity(value):
    return _STORE_TO_UI.get(_SEVERITY_TO_STORE.get(str(value or "").strip(), "Warning"), "Hold")


def verdict_label(verdict):
    """Word shown to the user. Stored verdicts stay pass, fail, and maybe."""
    key = str(verdict or "").strip().lower()
    return {"pass": "pass", "fail": "fail", "maybe": "hold"}.get(key, key)


def store_severity(value):
    return _SEVERITY_TO_STORE.get(str(value or "").strip(), "Warning")


def _rule(threshold, severity):
    item = {"severity": store_severity(severity)}
    if threshold is not None and str(threshold).strip() != "":
        item["threshold"] = threshold
    return item


def default_recipes():
    """Built-in profiles used the first time the store is missing."""
    digital = {
        "profile_name": "Standard Digital Press",
        "routing": {
            "pass_dir": "",
            "fail_dir": "",
            "maybe_dir": "",
        },
        "triggers": {
            "file_pattern": "*.pdf",
            "source_modes": ["manual", "hotfolder"],
            "generate_json_report": True,
            "email_notification": False,
            "move_original": False,
        },
        "rules": {
            "min_image_dpi": _rule(300, "Error"),
            "enforce_embedded_fonts": _rule(None, "Error"),
            "check_trim_box": _rule(0.125, "Warning"),
            "color_space": _rule(None, "Warning"),
            "hairline_pt": _rule(0.25, "Warning"),
            "tac_percent": _rule(300, "Warning"),
            "transparency": _rule(None, "Warning"),
            "overprint": _rule(None, "Ignore"),
            "jpeg2000": _rule(None, "Warning"),
        },
    }
    sheetfed = {
        "profile_name": "Commercial Sheetfed",
        "routing": {"pass_dir": "", "fail_dir": "", "maybe_dir": ""},
        "triggers": {
            "file_pattern": "*_print.pdf",
            "source_modes": ["manual", "hotfolder"],
            "generate_json_report": True,
            "email_notification": False,
            "move_original": False,
        },
        "rules": {
            "min_image_dpi": _rule(300, "Error"),
            "enforce_embedded_fonts": _rule(None, "Error"),
            "check_trim_box": _rule(0.125, "Error"),
            "color_space": _rule(None, "Error"),
            "hairline_pt": _rule(0.25, "Error"),
            "tac_percent": _rule(300, "Error"),
            "transparency": _rule(None, "Warning"),
            "overprint": _rule(None, "Warning"),
            "jpeg2000": _rule(None, "Warning"),
        },
    }
    proof = {
        "profile_name": "Soft Proof",
        "routing": {"pass_dir": "", "fail_dir": "", "maybe_dir": ""},
        "triggers": {
            "file_pattern": "*PROOF*.pdf",
            "source_modes": ["manual"],
            "generate_json_report": False,
            "email_notification": False,
            "move_original": False,
        },
        "rules": {
            "min_image_dpi": _rule(150, "Warning"),
            "enforce_embedded_fonts": _rule(None, "Warning"),
            "check_trim_box": _rule(0.125, "Ignore"),
            "color_space": _rule(None, "Ignore"),
            "hairline_pt": _rule(0.25, "Ignore"),
            "tac_percent": _rule(300, "Ignore"),
            "transparency": _rule(None, "Ignore"),
            "overprint": _rule(None, "Ignore"),
            "jpeg2000": _rule(None, "Ignore"),
        },
    }
    return [digital, sheetfed, proof]


def _blank_store():
    recipes = default_recipes()
    return {"version": 1, "active": recipes[0]["profile_name"], "recipes": recipes}


def load_store(directory=None):
    path = store_path(directory)
    if not os.path.isfile(path):
        store = _blank_store()
        save_store(store, directory)
        return store
    try:
        with open(path, "r", encoding="utf-8") as handle:
            data = json.load(handle)
    except (OSError, json.JSONDecodeError):
        store = _blank_store()
        save_store(store, directory)
        return store
    recipes = data.get("recipes") if isinstance(data, dict) else None
    if not isinstance(recipes, list) or not recipes:
        # A single recipe object was saved at the root.
        if isinstance(data, dict) and data.get("profile_name"):
            recipes = [normalize_recipe(data)]
            data = {"version": 1, "active": recipes[0]["profile_name"], "recipes": recipes}
        else:
            data = _blank_store()
        save_store(data, directory)
        return data
    data["recipes"] = [normalize_recipe(item) for item in recipes]
    if not data.get("active"):
        data["active"] = data["recipes"][0]["profile_name"]
    return data


def save_store(store, directory=None):
    path = store_path(directory)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as handle:
        json.dump(store, handle, indent=2)
    return path


def normalize_recipe(raw):
    base = default_recipes()[0]
    raw = raw or {}
    rules = dict(base["rules"])
    incoming = raw.get("rules") or {}
    for key, _label, has_threshold, _default, _sev in RULE_SPECS:
        item = dict(rules.get(key) or {})
        src = incoming.get(key) or {}
        if "severity" in src:
            item["severity"] = store_severity(src.get("severity"))
        if has_threshold and "threshold" in src and src.get("threshold") not in (None, ""):
            try:
                item["threshold"] = float(src.get("threshold"))
            except (TypeError, ValueError):
                pass
        rules[key] = item
    routing = dict(base["routing"])
    routing.update({k: str((raw.get("routing") or {}).get(k) or "") for k in routing})
    triggers = dict(base["triggers"])
    incoming_triggers = raw.get("triggers") or {}
    pattern = str(incoming_triggers.get("file_pattern") or triggers["file_pattern"]).strip()
    triggers["file_pattern"] = pattern or "*.pdf"
    modes = incoming_triggers.get("source_modes")
    if isinstance(modes, list) and modes:
        triggers["source_modes"] = [m for m in modes if m in SOURCE_MODES] or ["manual"]
    for flag in ("generate_json_report", "email_notification", "move_original"):
        if flag in incoming_triggers:
            triggers[flag] = bool(incoming_triggers.get(flag))
    name = str(raw.get("profile_name") or "Untitled Recipe").strip() or "Untitled Recipe"
    return {
        "profile_name": name,
        "routing": routing,
        "triggers": triggers,
        "rules": rules,
    }


def upsert_recipe(recipe, directory=None):
    store = load_store(directory)
    recipe = normalize_recipe(recipe)
    name = recipe["profile_name"]
    replaced = False
    updated = []
    for item in store["recipes"]:
        if item["profile_name"] == name:
            updated.append(recipe)
            replaced = True
        else:
            updated.append(item)
    if not replaced:
        updated.append(recipe)
    store["recipes"] = updated
    store["active"] = name
    save_store(store, directory)
    return recipe


def delete_recipe(name, directory=None):
    store = load_store(directory)
    store["recipes"] = [item for item in store["recipes"] if item["profile_name"] != name]
    if not store["recipes"]:
        store = _blank_store()
    elif store.get("active") == name:
        store["active"] = store["recipes"][0]["profile_name"]
    save_store(store, directory)
    return store


def set_active(name, directory=None):
    store = load_store(directory)
    names = [item["profile_name"] for item in store["recipes"]]
    if name in names:
        store["active"] = name
        save_store(store, directory)
    return store


def active_recipe(directory=None):
    store = load_store(directory)
    name = store.get("active")
    for item in store["recipes"]:
        if item["profile_name"] == name:
            return item
    return store["recipes"][0]


def name_matches(path, pattern):
    pattern = str(pattern or "*.pdf").strip() or "*.pdf"
    base = os.path.basename(str(path or ""))
    return fnmatch.fnmatch(base.lower(), pattern.lower())


def verdict_for(audit):
    counts = (audit or {}).get("counts") or {}
    if int(counts.get("fail") or 0) > 0:
        return "fail"
    if int(counts.get("warn") or 0) > 0:
        return "maybe"
    return "pass"


def file_summary_counts(entries):
    """Count files by routing verdict. Warnings are files with only warnings."""
    summary = {"pass": 0, "fail": 0, "warn": 0}
    for entry in entries or []:
        verdict = (entry or {}).get("verdict")
        if verdict == "pass":
            summary["pass"] += 1
        elif verdict == "fail":
            summary["fail"] += 1
        else:
            summary["warn"] += 1
    return summary


def file_summary_line(summary):
    """High-level line such as '1 passed, 5 failed, 3 holds'."""
    summary = summary or {}
    passed = int(summary.get("pass") or 0)
    failed = int(summary.get("fail") or 0)
    warned = int(summary.get("warn") or 0)
    hold_word = "hold" if warned == 1 else "holds"
    return f"{passed} passed, {failed} failed, {warned} {hold_word}"


def _result_buckets(verdict, paths):
    buckets = {"pass": [], "error": [], "warning": []}
    key = {"pass": "pass", "fail": "error", "maybe": "warning"}.get(verdict, "warning")
    buckets[key] = [os.path.basename(path) for path in paths or []]
    return buckets


def run_recipe_on_paths(paths, source="api", allow_side_effects=True, recipe=None, unit="inches"):
    """Audit files for an external dispatch.

    Returns without opening files when the active recipe does not include
    the requested source mode (manual, hotfolder, or api).
    """
    recipe = normalize_recipe(recipe or active_recipe())
    modes = recipe["triggers"].get("source_modes") or []
    if source not in modes:
        return {
            "skipped": True,
            "profile_name": recipe["profile_name"],
            "notes": [f"Recipe is not enabled for {source}."],
            "results": [],
        }
    import pdfdoc
    from modules.preflight.audit import audit_document

    results = []
    for path in paths or []:
        if not name_matches(path, recipe["triggers"].get("file_pattern")):
            results.append({
                "path": path,
                "skipped": True,
                "notes": [f"Skipped (pattern {recipe['triggers']['file_pattern']}): {os.path.basename(path)}"],
            })
            continue
        doc = pdfdoc.open(path)
        try:
            audit = audit_document(
                doc, unit=unit, rules=recipe.get("rules"), profile_name=recipe.get("profile_name") or "",
                filename=os.path.basename(path),
            )
        finally:
            try:
                doc.close()
            except Exception:
                pass
        actions = execute_recipe_actions([path], audit, recipe, allow_side_effects=allow_side_effects)
        results.append({
            "path": path,
            "skipped": False,
            "verdict": actions["verdict"],
            "notes": actions["notes"],
            "moved": actions["moved"],
        })
    return {"skipped": False, "profile_name": recipe["profile_name"], "results": results}


def _dest_dir(routing, verdict):
    routing = routing or {}
    key = {"pass": "pass_dir", "fail": "fail_dir", "maybe": "maybe_dir"}.get(verdict, "maybe_dir")
    return str(routing.get(key) or "").strip()


def _unique_dest(folder, filename):
    dest = os.path.join(folder, filename)
    if not os.path.exists(dest):
        return dest
    stem, ext = os.path.splitext(filename)
    number = 2
    while True:
        candidate = os.path.join(folder, f"{stem}_{number}{ext}")
        if not os.path.exists(candidate):
            return candidate
        number += 1


def execute_recipe_actions(paths, audit, recipe, allow_side_effects=False, include_json=True):
    """Write JSON, a notify note, and optionally move files.

    Free tier passes allow_side_effects=False. The returned notes explain
    what was skipped. This does not rewrite PDF content.
    """
    notes = []
    recipe = normalize_recipe(recipe)
    triggers = recipe["triggers"]
    routing = recipe["routing"]
    verdict = verdict_for(audit)
    folder = _dest_dir(routing, verdict)
    matched = [path for path in paths or [] if path and name_matches(path, triggers["file_pattern"])]
    skipped = [path for path in paths or [] if path and path not in matched]
    for path in skipped:
        notes.append(f"Skipped (pattern {triggers['file_pattern']}): {os.path.basename(path)}")
    if not allow_side_effects:
        if triggers.get("generate_json_report") or triggers.get("move_original") or triggers.get("email_notification"):
            notes.append("Routing, JSON export, and email hooks are part of Pro.")
        return {"verdict": verdict, "notes": notes, "moved": []}

    moved = []
    if include_json and triggers.get("generate_json_report") and folder:
        try:
            os.makedirs(folder, exist_ok=True)
            report_path = _unique_dest(folder, "preflight_report.json")
            payload = {key: value for key, value in (audit or {}).items() if key != "report_text"}
            if len(matched) == 1:
                payload["filename"] = os.path.basename(matched[0])
            payload["profile_name"] = recipe["profile_name"]
            payload["verdict"] = verdict
            payload["results"] = _result_buckets(verdict, matched)
            with open(report_path, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2)
            notes.append(f"JSON report: {report_path}")
        except OSError as exc:
            notes.append(f"Could not write JSON report: {exc}")

    if triggers.get("email_notification") and folder:
        try:
            os.makedirs(folder, exist_ok=True)
            note_path = _unique_dest(folder, "preflight_notify.txt")
            with open(note_path, "w", encoding="utf-8") as handle:
                handle.write(
                    f"ReadySetPDF preflight {verdict_label(verdict)} · {recipe['profile_name']}\n"
                    "No mail server is configured. This file is the notification hook.\n"
                )
            notes.append(f"Email hook written (no SMTP configured): {note_path}")
        except OSError as exc:
            notes.append(f"Could not write email hook: {exc}")

    if triggers.get("move_original"):
        if not folder:
            notes.append(f"Move skipped: no {verdict_label(verdict)} folder set on this recipe.")
        else:
            try:
                os.makedirs(folder, exist_ok=True)
            except OSError as exc:
                notes.append(f"Could not create routing folder: {exc}")
                folder = ""
            for path in matched:
                if not folder or not os.path.isfile(path):
                    continue
                dest = _unique_dest(folder, os.path.basename(path))
                try:
                    shutil.move(path, dest)
                    moved.append(dest)
                    notes.append(f"Moved to {verdict_label(verdict)} folder: {dest}")
                except OSError as exc:
                    notes.append(f"Could not move {os.path.basename(path)}: {exc}")
    return {"verdict": verdict, "notes": notes, "moved": moved}


def _file_report_record(path, audit, verdict, moved):
    name = os.path.basename(path)
    body = {"filename": name, "verdict": verdict}
    for key, value in (audit or {}).items():
        if key in ("report_text", "filename", "verdict"):
            continue
        body[key] = value
    if not body.get("filename"):
        body["filename"] = name
    for key in ("pages", "findings", "images", "transparency", "overprint", "hairlines", "tac"):
        for item in body.get(key) or []:
            if isinstance(item, dict):
                item["file"] = name
    if moved:
        body["moved_to"] = moved
    return body


def write_batch_json(entries, recipe):
    """Write one report that names each PDF. Copies it into each folder that received a file.

    Returns the paths that were written.
    """
    recipe = normalize_recipe(recipe)
    if not recipe["triggers"].get("generate_json_report"):
        return []
    files = []
    folders = []
    seen = set()
    for entry in entries or []:
        path = entry.get("path") or ""
        verdict = entry.get("verdict") or verdict_for(entry.get("audit"))
        record = _file_report_record(path, entry.get("audit"), verdict, entry.get("moved"))
        files.append(record)
        folder = _dest_dir(recipe["routing"], verdict)
        if folder and folder not in seen:
            seen.add(folder)
            folders.append(folder)
    if not folders:
        return []
    payload = {
        "version": 1,
        "profile_name": recipe["profile_name"],
        "summary": file_summary_counts(entries),
        "files": files,
    }
    written = []
    for folder in folders:
        try:
            os.makedirs(folder, exist_ok=True)
            report_path = _unique_dest(folder, "preflight_report.json")
            with open(report_path, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2)
            written.append(report_path)
        except OSError:
            continue
    return written


def route_audited_files(entries, recipe, allow_side_effects=True):
    """Move each already-audited PDF by its own verdict and write one named JSON report."""
    recipe = normalize_recipe(recipe)
    notes = []
    routed = []
    for entry in entries or []:
        path = entry.get("path")
        audit = entry.get("audit") or {}
        actions = execute_recipe_actions(
            [path], audit, recipe,
            allow_side_effects=allow_side_effects,
            include_json=False,
        )
        notes.extend(actions.get("notes") or [])
        moved = (actions.get("moved") or [None])[0]
        routed.append({
            "path": path,
            "audit": audit,
            "verdict": actions.get("verdict") or verdict_for(audit),
            "moved": moved,
        })
    reports = []
    if allow_side_effects and recipe["triggers"].get("generate_json_report"):
        reports = write_batch_json(routed, recipe)
        if reports:
            for report_path in reports:
                notes.append(f"JSON report: {report_path}")
        elif routed:
            notes.append("JSON report skipped: set a pass, fail, or hold folder for the files in this run.")
    summary = file_summary_counts(routed)
    return {"summary": summary, "notes": notes, "files": routed, "reports": reports}
