"""Preflight tab: audit report for everyone; exports and fixups for Pro."""

import json
import os
import tkinter as tk
from tkinter import filedialog, messagebox, ttk

import licensing
from license_dialog import open_license_dialog
from modules.preflight.audit import audit_document
from modules.preflight.recipes import (
    RULE_SPECS,
    SEVERITY_UI,
    UI_SOURCE_MODES,
    active_recipe,
    delete_recipe,
    execute_recipe_actions,
    file_summary_counts,
    file_summary_line,
    load_store,
    name_matches,
    normalize_recipe,
    route_audited_files,
    set_active,
    ui_severity,
    upsert_recipe,
)


def preflight_finish_popup(headline, pro):
    """Finish-dialog body. Pro states the result. Free only previews the routing."""
    if pro:
        return f"Preflight finished.\n\n{headline}."
    return (
        "Free mode Preflight finished. If in Pro, files would be moved as follows:\n\n"
        f"{headline}."
    )


class PreflightMixin:
    def build_preflight_tab(self):
        tab = ttk.Frame(self.tab_content_frame, padding=15)
        self.tabs["Preflight"] = tab
        self._last_preflight_audit = None
        self._build_preflight_recipe_frame(tab)

        top = tk.Frame(tab)
        top.pack(fill="x", pady=(0, 6))
        self._create_btn(
            top, "🔍 Run Preflight Analysis", self.color_lime, self.color_navy, self.run_preflight,
            tooltip="Checks each PDF loaded in Assets Manager. Uses Manual execution on this recipe.",
        ).pack(side="left")

        actions = tk.Frame(tab)
        actions.pack(fill="x", pady=(0, 6))
        self._preflight_export_json_btn = self._create_btn(
            actions, "Export JSON *", self.color_steel, self.color_white,
            self._preflight_export_json,
            tooltip="Saves the report on screen as a JSON file you choose. Separate from the automatic report written into a destination folder.",
        )
        self._preflight_export_json_btn.pack(side="left", padx=(0, 6))
        self._preflight_export_pdf_btn = self._create_btn(
            actions, "Export PDF Report *", self.color_steel, self.color_white,
            self._preflight_export_pdf_report,
            tooltip="Saves the report on screen as a PDF. Pro only.",
        )
        self._preflight_export_pdf_btn.pack(side="left", padx=(0, 6))

        fixups = tk.Frame(tab)
        fixups.pack(fill="x", pady=(0, 6))
        self._preflight_color_btn = self._create_btn(
            fixups, "Open Color (RGB fix) *", self.color_mint, self.color_navy,
            self._preflight_open_color,
            tooltip="Opens the Color tab so you can convert RGB to CMYK. Pro only.",
        )
        self._preflight_color_btn.pack(side="left", padx=(0, 6))
        self._preflight_geo_btn = self._create_btn(
            fixups, "Open Page Geometry *", self.color_mint, self.color_navy,
            self._preflight_open_geometry,
            tooltip="Opens Page Geometry to adjust crop, trim, and bleed. Pro only.",
        )
        self._preflight_geo_btn.pack(side="left", padx=(0, 6))

        tk.Label(
            tab,
            text="Free: run and read the report. Pro / Trial: JSON, PDF, routing, and one-click jumps to fix tools.",
            font=("Arial", 8, "italic"),
            foreground=self.color_steel,
        ).pack(anchor="w", pady=(0, 4))

        report_frame = ttk.LabelFrame(tab, text="Preflight Report", padding=10)
        report_frame.pack(fill="both", expand=True, pady=10)
        self.report_text = tk.Text(
            report_frame, bg=self.color_navy, fg=self.color_lime,
            font=("Courier", 10), wrap="word", state="disabled", relief="flat",
            padx=10, pady=10,
        )
        self.report_text.pack(side="left", fill="both", expand=True)
        scroll = ttk.Scrollbar(report_frame, command=self.report_text.yview)
        scroll.pack(side="right", fill="y")
        self.report_text.config(yscrollcommand=scroll.set)
        self._refresh_preflight_action_styles()
        self._load_preflight_recipes()

    def _build_preflight_recipe_frame(self, tab):
        holder = ttk.LabelFrame(tab, text="Recipe / Profile", padding=4)
        holder.pack(fill="x", pady=(0, 6))
        canvas = tk.Canvas(holder, height=248, highlightthickness=0)
        scroll = ttk.Scrollbar(holder, orient="vertical", command=canvas.yview)
        inner = tk.Frame(canvas)
        window_id = canvas.create_window((0, 0), window=inner, anchor="nw")

        def _fit(event):
            canvas.configure(scrollregion=canvas.bbox("all"))
            canvas.itemconfigure(window_id, width=event.width)

        inner.bind("<Configure>", lambda _e: canvas.configure(scrollregion=canvas.bbox("all")))
        canvas.bind("<Configure>", _fit)
        canvas.configure(yscrollcommand=scroll.set)
        canvas.pack(side="left", fill="x", expand=True)
        scroll.pack(side="right", fill="y")

        def _wheel(event):
            canvas.yview_scroll(int(-event.delta / 120), "units")
            return "break"

        canvas.bind("<Enter>", lambda _e: canvas.focus_set())
        canvas.bind("<MouseWheel>", _wheel)
        inner.bind("<MouseWheel>", _wheel)

        row = tk.Frame(inner)
        row.pack(fill="x", padx=6, pady=(4, 2))
        profile_tip = (
            "Recipe name. Save Recipe overwrites this name in the Preflight list. "
            "Type a new name first if you want to keep Standard Digital Press."
        )
        profile_label = tk.Label(row, text="Profile")
        profile_label.pack(side="left")
        self._preflight_tip(profile_label, profile_tip)
        self.preflight_recipe_var = tk.StringVar()
        self.preflight_recipe_combo = ttk.Combobox(row, textvariable=self.preflight_recipe_var, width=36)
        self.preflight_recipe_combo.pack(side="left", padx=6)
        self._preflight_tip(self.preflight_recipe_combo, profile_tip)
        self.preflight_recipe_combo.bind("<<ComboboxSelected>>", lambda _e: self._on_preflight_recipe_selected())
        self._create_btn(
            row, "💾 Save Recipe", self.color_lime, self.color_navy, self._save_preflight_recipe,
            tooltip="Saves this Preflight recipe. The same name overwrites that recipe. This does not save an Automation file.",
        ).pack(side="left", padx=(0, 6))
        self._create_btn(
            row, "🗑️ Delete Recipe", self.color_steel, self.color_white, self._delete_preflight_recipe,
            tooltip="Removes this recipe from the Preflight list.",
        ).pack(side="left")

        rules = ttk.LabelFrame(inner, text="Criteria & thresholds", padding=6)
        rules.pack(fill="x", padx=6, pady=4)
        self._preflight_rule_vars = {}
        rule_tips = {
            "min_image_dpi": "Images below this DPI are flagged. Error (Fail) can send the file to the fail folder. Hold can send it to the hold folder.",
            "enforce_embedded_fonts": "Flags fonts that are not embedded. The number box is not used for this check.",
            "check_trim_box": "Bleed required beyond the trim box, in inches. Missing or short bleed is flagged at the severity you choose.",
            "color_space": "Flags RGB color. Open Color to convert it to CMYK. The number box is not used for this check.",
            "hairline_pt": "Strokes thinner than this point size are flagged.",
            "tac_percent": "Flags CMYK images whose total ink is above this percent.",
            "transparency": "Flags transparency, soft masks, and blend modes other than Normal.",
            "overprint": "Flags overprint. Choose Ignore to leave overprint out of the report.",
            "jpeg2000": "Flags JPEG 2000 images. Some RIPs cannot print them.",
        }
        severity_tip = "Error (Fail) counts toward the fail folder. Hold counts toward the hold folder and means a person should look before release. Ignore skips this check."
        for key, label, has_threshold, default, _severity in RULE_SPECS:
            line = tk.Frame(rules)
            line.pack(fill="x", pady=1)
            tip = rule_tips.get(key, label)
            name = tk.Label(line, text=label, width=28, anchor="w")
            name.pack(side="left")
            self._preflight_tip(name, tip)
            threshold = tk.StringVar(value=default)
            entry = tk.Entry(line, textvariable=threshold, width=8)
            entry.pack(side="left", padx=(0, 8))
            if not has_threshold:
                entry.config(state="disabled")
                self._preflight_tip(entry, tip + " This number is not used.")
            else:
                self._preflight_tip(entry, tip)
            severity = tk.StringVar(value="Hold")
            combo = ttk.Combobox(
                line, textvariable=severity, values=list(SEVERITY_UI), width=18, state="readonly",
            )
            combo.pack(side="left")
            self._preflight_tip(combo, severity_tip)
            self._preflight_rule_vars[key] = {"threshold": threshold, "severity": severity, "numeric": has_threshold}

        routing = ttk.LabelFrame(inner, text="Destination routing", padding=6)
        routing.pack(fill="x", padx=6, pady=4)
        self.preflight_pass_var = tk.StringVar()
        self.preflight_fail_var = tk.StringVar()
        self.preflight_maybe_var = tk.StringVar()
        self._path_row(
            routing, "Pass folder", self.preflight_pass_var,
            "Files with no errors or holds are moved here when Move original file is checked.",
        )
        self._path_row(
            routing, "Fail (error) folder", self.preflight_fail_var,
            "Files with at least one Error (Fail) are moved here when Move original file is checked.",
        )
        self._path_row(
            routing, "Hold folder", self.preflight_maybe_var,
            "Files with holds and no errors are moved here when Move original file is checked. A hold means a person should look before release.",
        )

        triggers = ttk.LabelFrame(inner, text="Triggers & filters", padding=6)
        triggers.pack(fill="x", padx=6, pady=(4, 6))
        pattern_row = tk.Frame(triggers)
        pattern_row.pack(fill="x", pady=1)
        pattern_tip = "Only file names matching this pattern are checked. *.pdf means every PDF."
        pattern_label = tk.Label(pattern_row, text="File name pattern", width=28, anchor="w")
        pattern_label.pack(side="left")
        self._preflight_tip(pattern_label, pattern_tip)
        self.preflight_pattern_var = tk.StringVar(value="*.pdf")
        pattern_entry = tk.Entry(pattern_row, textvariable=self.preflight_pattern_var, width=28)
        pattern_entry.pack(side="left")
        self._preflight_tip(pattern_entry, pattern_tip)
        mode_row = tk.Frame(triggers)
        mode_row.pack(fill="x", pady=2)
        run_when_tip = (
            "Choose when this recipe runs. Hot-folder watchdog is the same switch as "
            "Run preflight in association with automation on the Automation tab. "
            "Checking Manual execution or Hot-folder watchdog turns the other off. "
            "Unchecking one leaves the other as it is."
        )
        run_when = tk.Label(mode_row, text="Run when", width=28, anchor="w")
        run_when.pack(side="left")
        self._preflight_tip(run_when, run_when_tip)
        self._ensure_preflight_mode_vars()
        labels = {
            "manual": "Manual execution",
            "hotfolder": "Hot-folder watchdog",
        }
        mode_tips = {
            "manual": (
                "Runs when you click Run Preflight Analysis on the PDFs in Assets Manager. "
                "Checking this turns off Hot-folder watchdog and Run preflight in association with automation. "
                "Unchecking does not turn that association on."
            ),
            "hotfolder": (
                "Same switch as Run preflight in association with automation on the Automation tab. "
                "After each processed PDF, Preflight checks it and can move it to the pass, fail, or hold folders. "
                "Checking this turns off Manual execution. Unchecking turns the association off immediately "
                "and does not overwrite the saved recipe."
            ),
        }
        for mode in UI_SOURCE_MODES:
            var = self.preflight_mode_vars[mode]
            check = ttk.Checkbutton(mode_row, text=labels[mode], variable=var)
            check.pack(side="left", padx=(0, 8))
            self._preflight_tip(check, mode_tips[mode])
        hook_row = tk.Frame(triggers)
        hook_row.pack(fill="x", pady=1)
        after_tip = "Optional Pro actions after a file is checked. They use the pass, fail, and hold folders."
        after_label = tk.Label(hook_row, text="After the run (Pro)", width=28, anchor="w")
        after_label.pack(side="left")
        self._preflight_tip(after_label, after_tip)
        self.preflight_json_var = tk.BooleanVar(value=True)
        self.preflight_email_var = tk.BooleanVar(value=False)
        self.preflight_move_var = tk.BooleanVar(value=False)
        json_check = ttk.Checkbutton(hook_row, text="Generate JSON report", variable=self.preflight_json_var)
        json_check.pack(side="left", padx=(0, 8))
        self._preflight_tip(
            json_check,
            "Writes preflight_report.json into that file's pass, fail, or hold folder. The report uses the original PDF name.",
        )
        email_check = ttk.Checkbutton(hook_row, text="Email notification hook", variable=self.preflight_email_var)
        email_check.pack(side="left", padx=(0, 8))
        self._preflight_tip(
            email_check,
            "Writes a notification text file in the destination folder. Mail is not sent until a mail server is configured.",
        )
        move_check = ttk.Checkbutton(hook_row, text="Move original file", variable=self.preflight_move_var)
        move_check.pack(side="left")
        self._preflight_tip(
            move_check,
            "Moves each checked PDF into the pass, fail, or hold folder. Leave this off to keep the file where it is.",
        )

    def _preflight_tip(self, widget, text):
        if widget is None or not text:
            return widget
        import sys
        module = sys.modules.get(type(self).__module__)
        tip_cls = getattr(module, "ToolTip", None) if module else None
        if tip_cls is None:
            return widget
        tip_cls(widget, text, self)
        return widget

    def _path_row(self, parent, label, variable, tooltip=""):
        row = tk.Frame(parent)
        row.pack(fill="x", pady=1)
        name = tk.Label(row, text=label, width=28, anchor="w")
        name.pack(side="left")
        self._preflight_tip(name, tooltip)
        entry = tk.Entry(row, textvariable=variable, width=42)
        entry.pack(side="left", padx=(0, 6))
        self._preflight_tip(entry, tooltip)
        browse = self._create_btn(
            row, "Browse...", self.color_steel, self.color_white,
            lambda var=variable: self._browse_preflight_dir(var),
            tooltip=tooltip or "Choose this folder.",
        )
        browse.pack(side="left")

    def _browse_preflight_dir(self, variable):
        path = filedialog.askdirectory(parent=self.root, title="Select folder")
        if path:
            variable.set(path)

    def _load_preflight_recipes(self):
        store = load_store()
        names = [item["profile_name"] for item in store["recipes"]]
        self.preflight_recipe_combo["values"] = names
        current = store.get("active") or (names[0] if names else "")
        self.preflight_recipe_var.set(current)
        match = next((item for item in store["recipes"] if item["profile_name"] == current), None)
        if match:
            self._apply_preflight_recipe(match)

    def _on_preflight_recipe_selected(self):
        name = self.preflight_recipe_var.get().strip()
        store = load_store()
        match = next((item for item in store["recipes"] if item["profile_name"] == name), None)
        if match:
            self._apply_preflight_recipe(match)
            set_active(name)

    def _apply_preflight_recipe(self, recipe):
        recipe = normalize_recipe(recipe)
        self.preflight_recipe_var.set(recipe["profile_name"])
        rules = recipe["rules"]
        for key, vars_ in self._preflight_rule_vars.items():
            item = rules.get(key) or {}
            vars_["severity"].set(ui_severity(item.get("severity")))
            if vars_["numeric"]:
                value = item.get("threshold")
                vars_["threshold"].set("" if value is None else str(value))
        routing = recipe["routing"]
        self.preflight_pass_var.set(routing.get("pass_dir") or "")
        self.preflight_fail_var.set(routing.get("fail_dir") or "")
        self.preflight_maybe_var.set(routing.get("maybe_dir") or "")
        triggers = recipe["triggers"]
        self.preflight_pattern_var.set(triggers.get("file_pattern") or "*.pdf")
        modes = set(triggers.get("source_modes") or [])
        # Profile load sets the boxes as saved. It is not a user toggle, so
        # mutual exclusion does not rewrite a recipe that still lists both.
        self._preflight_mode_applying = True
        try:
            for mode, var in self.preflight_mode_vars.items():
                var.set(mode in modes)
        finally:
            self._preflight_mode_applying = False
        self.preflight_json_var.set(bool(triggers.get("generate_json_report")))
        self.preflight_email_var.set(bool(triggers.get("email_notification")))
        self.preflight_move_var.set(bool(triggers.get("move_original")))

    def _preflight_recipe_from_ui(self):
        rules = {}
        for key, vars_ in self._preflight_rule_vars.items():
            item = {"severity": vars_["severity"].get()}
            if vars_["numeric"]:
                text = vars_["threshold"].get().strip()
                if text:
                    item["threshold"] = text
            rules[key] = item
        modes = [mode for mode, var in self.preflight_mode_vars.items() if var.get()]
        return normalize_recipe({
            "profile_name": self.preflight_recipe_var.get().strip() or "Untitled Recipe",
            "routing": {
                "pass_dir": self.preflight_pass_var.get().strip(),
                "fail_dir": self.preflight_fail_var.get().strip(),
                "maybe_dir": self.preflight_maybe_var.get().strip(),
            },
            "triggers": {
                "file_pattern": self.preflight_pattern_var.get().strip() or "*.pdf",
                "source_modes": modes or ["manual"],
                "generate_json_report": bool(self.preflight_json_var.get()),
                "email_notification": bool(self.preflight_email_var.get()),
                "move_original": bool(self.preflight_move_var.get()),
            },
            "rules": rules,
        })

    def _save_preflight_recipe(self):
        recipe = self._preflight_recipe_from_ui()
        upsert_recipe(recipe)
        self._load_preflight_recipes()
        self.preflight_recipe_var.set(recipe["profile_name"])
        messagebox.showinfo("Preflight", f"Saved recipe:\n{recipe['profile_name']}", parent=self.root)

    def _delete_preflight_recipe(self):
        name = self.preflight_recipe_var.get().strip()
        if not name:
            return
        if not messagebox.askyesno("Preflight", f"Delete recipe \"{name}\"?", parent=self.root):
            return
        delete_recipe(name)
        self._load_preflight_recipes()

    def _ensure_preflight_mode_vars(self):
        """One BooleanVar per trigger, shared by Preflight and Automation.

        Traces enforce mutual exclusion. A re-entry flag stops the two writes
        from calling each other, and recipe apply sets _preflight_mode_applying
        so a profile load is not treated as a click.
        """
        modes = getattr(self, "preflight_mode_vars", None)
        if not isinstance(modes, dict):
            modes = {}
            self.preflight_mode_vars = modes
        if "manual" not in modes:
            modes["manual"] = tk.BooleanVar(value=True)
        if "hotfolder" not in modes:
            modes["hotfolder"] = tk.BooleanVar(value=False)
        if getattr(self, "_preflight_mode_traces", False):
            return modes
        self._preflight_mode_traces = True
        modes["manual"].trace_add("write", lambda *_a: self._sync_preflight_mode_exclusive("manual"))
        modes["hotfolder"].trace_add("write", lambda *_a: self._sync_preflight_mode_exclusive("hotfolder"))
        return modes

    def _sync_preflight_mode_exclusive(self, source):
        if getattr(self, "_preflight_mode_applying", False) or getattr(self, "_preflight_mode_syncing", False):
            return
        modes = getattr(self, "preflight_mode_vars", None) or {}
        var = modes.get(source)
        other_name = {"hotfolder": "manual", "manual": "hotfolder"}.get(source)
        other = modes.get(other_name) if other_name else None
        if var is None or other is None:
            return
        try:
            turned_on = bool(var.get())
        except Exception:
            return
        if not turned_on:
            return
        try:
            other_on = bool(other.get())
        except Exception:
            return
        if not other_on:
            return
        self._preflight_mode_syncing = True
        try:
            other.set(False)
        finally:
            self._preflight_mode_syncing = False

    def preflight_hotfolder_enabled(self):
        """Whether Automation should preflight its output right now.

        Automation's association checkbox and Hot-folder watchdog are one switch.
        That live value wins over the saved recipe. The recipe file is updated
        only when the user clicks Save Recipe.
        """
        modes = getattr(self, "preflight_mode_vars", None)
        if isinstance(modes, dict) and "hotfolder" in modes:
            try:
                return bool(modes["hotfolder"].get())
            except Exception:
                pass
        recipe = active_recipe()
        triggers = (recipe or {}).get("triggers") or {}
        return "hotfolder" in (triggers.get("source_modes") or [])

    def preflight_after_hotfolder_output(self, out_path):
        """Audit a hot-folder output when Hot-folder watchdog is on."""
        if not self._preflight_is_pro():
            return
        if not self.preflight_hotfolder_enabled():
            return
        recipe = active_recipe()
        triggers = recipe.get("triggers") or {}
        if not name_matches(out_path, triggers.get("file_pattern")):
            return
        import pdfdoc
        doc = pdfdoc.open(out_path)
        try:
            unit = self.global_unit_var.get() if hasattr(self, "global_unit_var") else "inches"
            audit = audit_document(
                doc, unit=unit, rules=recipe.get("rules"), profile_name=recipe.get("profile_name") or "",
                filename=os.path.basename(out_path),
            )
        finally:
            try:
                doc.close()
            except Exception:
                pass
        execute_recipe_actions([out_path], audit, recipe, allow_side_effects=True)

    def _preflight_is_pro(self):
        return licensing.tool_unlocked("Preflight", getattr(self, "license_state", None))

    def _preflight_require_pro(self):
        if self._preflight_is_pro():
            return True
        open_license_dialog(self)
        return False

    def _refresh_preflight_action_styles(self):
        buttons = [
            getattr(self, "_preflight_export_json_btn", None),
            getattr(self, "_preflight_export_pdf_btn", None),
            getattr(self, "_preflight_color_btn", None),
            getattr(self, "_preflight_geo_btn", None),
        ]
        pro = self._preflight_is_pro()
        for btn in buttons:
            if btn is None:
                continue
            try:
                if not btn.winfo_exists():
                    continue
            except Exception:
                continue
            if pro:
                btn.config(
                    bg=self.color_steel if "Export" in (btn.cget("text") or "") else self.color_mint,
                    fg=self.color_white if "Export" in (btn.cget("text") or "") else self.color_navy,
                    state="normal",
                )
            else:
                btn.config(bg="#c5c5c5", fg="#6a6a6a", state="normal")

    def run_preflight(self):
        if not self.files:
            messagebox.showwarning("No Assets", "Load source PDF documents first.")
            return
        recipe = self._preflight_recipe_from_ui()
        triggers = recipe["triggers"]
        if "manual" not in (triggers.get("source_modes") or []):
            messagebox.showinfo(
                "Preflight",
                "This recipe is not set for manual execution.\nTurn on Manual execution under Triggers.",
                parent=self.root,
            )
            return
        pattern = triggers.get("file_pattern") or "*.pdf"
        matched = [path for path in self.files if name_matches(path, pattern)]
        skipped = [path for path in self.files if path not in matched]
        if not matched:
            messagebox.showinfo(
                "Preflight",
                f"No loaded file matches {pattern}.",
                parent=self.root,
            )
            return
        self.report_text.config(state="normal")
        self.report_text.delete(1.0, tk.END)
        self.report_text.insert(tk.END, "Analyzing each PDF...\n\n")
        self.root.update_idletasks()
        unit = self.global_unit_var.get() if hasattr(self, "global_unit_var") else "inches"
        allow = self._preflight_is_pro()
        notes = [f"Skipped (pattern {pattern}): {os.path.basename(path)}" for path in skipped]
        import pdfdoc
        entries = []
        sections = []
        try:
            for path in matched:
                name = os.path.basename(path)
                try:
                    one = pdfdoc.open(path)
                except Exception as exc:
                    notes.append(f"Could not read {name}: {exc}")
                    entries.append({
                        "path": path,
                        "audit": {
                            "filename": name,
                            "page_count": 0,
                            "pages": [],
                            "findings": [{
                                "severity": "fail",
                                "code": "unreadable",
                                "file": name,
                                "page": None,
                                "message": str(exc),
                            }],
                            "counts": {"fail": 1, "warn": 0, "info": 0},
                            "verdict": "fail",
                            "report_text": f"=== READYSETPDF PREFLIGHT REPORT ===\nFile: {name}\nCould not read this PDF: {exc}\n\n--- END OF REPORT ---",
                        },
                    })
                    sections.append(entries[-1]["audit"]["report_text"])
                    continue
                try:
                    try:
                        audit = audit_document(
                            one, unit=unit, rules=recipe.get("rules"),
                            profile_name=recipe.get("profile_name") or "",
                            filename=name,
                        )
                    finally:
                        try:
                            one.close()
                        except Exception:
                            pass
                except Exception as exc:
                    notes.append(f"Could not read {name}: {exc}")
                    entries.append({
                        "path": path,
                        "audit": {
                            "filename": name,
                            "page_count": 0,
                            "pages": [],
                            "findings": [{
                                "severity": "fail",
                                "code": "unreadable",
                                "file": name,
                                "page": None,
                                "message": str(exc),
                            }],
                            "counts": {"fail": 1, "warn": 0, "info": 0},
                            "verdict": "fail",
                            "report_text": f"=== READYSETPDF PREFLIGHT REPORT ===\nFile: {name}\nCould not read this PDF: {exc}\n\n--- END OF REPORT ---",
                        },
                    })
                    sections.append(entries[-1]["audit"]["report_text"])
                    continue
                entries.append({"path": path, "audit": audit})
                sections.append(audit.get("report_text") or "")
            routed = route_audited_files(entries, recipe, allow_side_effects=allow)
            notes.extend(routed.get("notes") or [])
            summary = dict(routed.get("summary") or file_summary_counts(routed.get("files")))
            moved_any = False
            for item in routed.get("files") or []:
                new_path = item.get("moved")
                old_path = item.get("path")
                if new_path and old_path in self.files:
                    self.files[self.files.index(old_path)] = new_path
                    moved_any = True
            batch = {
                "version": 1,
                "profile_name": recipe.get("profile_name") or "",
                "summary": summary,
                "files": [],
                "report_text": "",
            }
            for item in routed.get("files") or []:
                audit = item.get("audit") or {}
                record = {key: value for key, value in audit.items() if key != "report_text"}
                record["filename"] = os.path.basename(item.get("path") or record.get("filename") or "")
                record["verdict"] = item.get("verdict")
                if item.get("moved"):
                    record["moved_to"] = item.get("moved")
                batch["files"].append(record)
            headline = file_summary_line(summary)
            text = headline + "\n\n" + "\n\n".join(section for section in sections if section)
            if notes and "--- END OF REPORT ---" in text:
                head, _sep, tail = text.rpartition("\n--- END OF REPORT ---")
                routing = "\n=== ROUTING ===\n" + "\n".join(f"   • {note}" for note in notes)
                text = head + routing + "\n\n--- END OF REPORT ---" + tail
            elif notes:
                text = text + "\n\n=== ROUTING ===\n" + "\n".join(f"   • {note}" for note in notes)
            batch["report_text"] = text
            self._last_preflight_audit = batch
            self.report_text.delete(1.0, tk.END)
            self.report_text.insert(tk.END, text)
            if moved_any and hasattr(self, "refresh_file_list"):
                try:
                    self.refresh_file_list()
                except Exception:
                    pass
            messagebox.showinfo(
                "Preflight", preflight_finish_popup(headline, allow), parent=self.root,
            )
        except Exception as exc:
            self._last_preflight_audit = None
            self.report_text.delete(1.0, tk.END)
            self.report_text.insert(tk.END, f"Preflight failed:\n{exc}")
            messagebox.showerror("Preflight", f"Preflight failed:\n{exc}")
        finally:
            self.report_text.config(state="disabled")
            self._refresh_preflight_action_styles()

    def _preflight_export_json(self):
        if not self._preflight_require_pro():
            return
        audit = self._last_preflight_audit
        if not audit:
            messagebox.showinfo("Preflight", "Run Preflight Analysis first.")
            return
        path = filedialog.asksaveasfilename(
            parent=self.root,
            defaultextension=".json",
            initialfile="preflight_report.json",
            filetypes=[("JSON", "*.json")],
        )
        if not path:
            return
        payload = {key: value for key, value in audit.items() if key != "report_text"}
        try:
            with open(path, "w", encoding="utf-8") as handle:
                json.dump(payload, handle, indent=2)
        except OSError as exc:
            messagebox.showerror("Preflight", f"Could not write JSON:\n{exc}")
            return
        messagebox.showinfo("Preflight", f"Saved JSON report:\n{path}")

    def _preflight_export_pdf_report(self):
        if not self._preflight_require_pro():
            return
        audit = self._last_preflight_audit
        if not audit:
            messagebox.showinfo("Preflight", "Run Preflight Analysis first.")
            return
        path = filedialog.asksaveasfilename(
            parent=self.root,
            defaultextension=".pdf",
            initialfile="preflight_report.pdf",
            filetypes=[("PDF", "*.pdf")],
        )
        if not path:
            return
        try:
            self._write_preflight_pdf_report(path, audit.get("report_text") or "")
        except Exception as exc:
            messagebox.showerror("Preflight", f"Could not write PDF report:\n{exc}")
            return
        messagebox.showinfo("Preflight", f"Saved PDF report:\n{path}")

    def _write_preflight_pdf_report(self, path, text):
        import pdfdoc
        from pdfgeom import Point
        from engine import save_production_pdf

        doc = pdfdoc.open()
        try:
            lines = (text or "").splitlines() or ["(empty report)"]
            margin = 36
            font_size = 9
            leading = 11
            page_w, page_h = 612, 792
            # y-down page space: start at top margin and step downward.
            y = margin
            page = doc.new_page(width=page_w, height=page_h)
            page.insert_text(
                Point(margin, y), "ReadySetPDF Preflight Report", fontsize=14,
            )
            y += 22
            for line in lines:
                if y > page_h - margin - leading:
                    page = doc.new_page(width=page_w, height=page_h)
                    y = margin
                clean = (
                    line.replace("⚠️", "[!]")
                    .replace("✅", "[OK]")
                    .replace("ℹ️", "[i]")
                    .replace("·", "-")
                )
                page.insert_text(Point(margin, y), clean[:110], fontsize=font_size)
                y += leading
            save_production_pdf(doc, path, {})
        finally:
            doc.close()

    def _preflight_open_color(self):
        if not self._preflight_require_pro():
            return
        if self._tool_tab_locked("Color"):
            open_license_dialog(self)
            return
        self.select_tab("Color")

    def _preflight_open_geometry(self):
        if not self._preflight_require_pro():
            return
        try:
            if hasattr(self, "_toggle_page_geometry"):
                body = getattr(self, "page_geo_body", None)
                if body is not None and not body.winfo_ismapped():
                    self._toggle_page_geometry()
            messagebox.showinfo(
                "Page Geometry",
                "Use Page Geometry / Box Settings in Assets Manager to adjust Crop/Trim/Bleed.",
                parent=self.root,
            )
        except Exception as exc:
            messagebox.showerror("Page Geometry", str(exc))
