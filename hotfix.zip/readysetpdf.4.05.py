import os
import sys
import json
import shutil
import csv
import math
import webbrowser
import urllib.request
import urllib.parse
import tkinter as tk
import threading 
from tkinter import filedialog, messagebox, ttk
from tkinter import font as tkfont
from tkinterdnd2 import DND_FILES, TkinterDnD
import pdfdoc
from PIL import Image, ImageTk
from pdfrender import render_page_image
from engine import (
    _execute_pipeline,
    UnlockError,
    insert_source_file,
    prepare_imported_doc,
    save_unlocked_copy,
    unlock_password_from_steps,
    apply_proof_stamp,
    save_production_pdf,
    save_optimized_pdf,
    load_merge_rows,
    read_spreadsheet,
    mapped_merge_columns,
    apply_vdp_merge,
    style_on,
    field_rotation,
    _field_template_page,
    guess_address_columns,
    format_address_block,
    build_address_block_spec,
    normalize_address_map,
    ADDRESS_BLOCK_FIELD_COUNT,
    find_tesseract,
    extract_ocr_text,
    extract_ocr_table,
    save_ocr_export,
    parse_max_dpi,
    FOLD_TYPES,
    FOLD_NEST_PT,
    compute_fold_layout,
    build_fold_proof_doc,
    steps_include_join_split,
    run_join_split_stack,
    join_output_stem,
    split_page_stem,
    output_path_avoiding_sources,
)
from modules.hotfolder import HotFolderMixin
from modules import hotfix
from modules.preflight import PreflightMixin
from modules.color import ColorMixin
from modules.ocr import OcrMixin
from pageboxes import (
    PAGE_BOX_KEEP,
    PAGE_BOX_LABELS,
    format_page_boxes_summary,
    normalize_page_box_mode,
)
import licensing
from license_dialog import open_license_dialog
from modules.core.intake import IntakeError, prepare_input, normalize_input_path

try:
    import openpyxl
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False

APP_VERSION = "4.05"
LIVE_PREVIEW_TABS = {
    "Resize": "Resize",
    "Crop": "Crop Margin",
    "Grid": "Grid Imposition",
    "Booklet": "Booklet Spread",
    "Cutter": "Cutter Marks",
    "Rotate": "Rotate Pages",
    "Color": "Color Conversion",
}
# Same empty-stack live preview as 3.53. Resize/Crop/Color only ghost-replace
# a matching last step so opening Color does not grayscale the file unasked.
LIVE_PREVIEW_EMPTY_STACK = {
    "Grid Imposition",
    "Booklet Spread",
    "Cutter Marks",
    "Rotate Pages",
}
STEP_TAB_BY_TYPE = {
    "Resize": "Resize",
    "Crop Margin": "Crop",
    "Monkey Imposition": "Grid",
    "Grid Imposition": "Grid",
    "Booklet Spread": "Booklet",
    "Insert Blank Page": "Booklet",
    "Cutter Marks": "Cutter",
    "Rotate Pages": "Rotate",
    "Color Conversion": "Color",
    "VDP Mail Merge": "VDP",
    "OCR Extraction": "OCR",
    "Unlock PDF": "Unlock",
    "Join PDFs": "JoinSplit",
    "Split PDFs": "JoinSplit",
}
TAB_TOOLTIPS = {
    "Resize": "Fit each page into a target sheet size (Letter, A4, custom).\nUse this before imposing when the source trim is wrong.",
    "Crop": "Trim equal or unequal margins off every page.\nEnter amounts in the global unit (inches, mm, or points).",
    "Grid": "Step-and-repeat onto a sheet. Type the rows and columns, or turn on Auto max-fit.\nSource Trim packs on the finished size so gutter 0 means trims touch; bleed may overlap neighbors.",
    "Booklet": "Imposed saddle-stitch spreads. Creep is paper thickness per sheet (0 on the cover).\nPage forward to inner sheets to see it. Source Trim packs facing pages on the finished size.",
    "Cutter": "Add cut L-marks and extra finishing marks (corner dots, cross, or L)\nfor collators. Target all pages, fronts (odd), or backs (even).",
    "Rotate": "Rotate selected pages 90 / 180 / 270 degrees and swap the page box.\nUse Odd/Even (Front/Back) for duplex work.",
    "VDP": "Variable data: click a column tag, then click the template to place it.\nClick a placed box to select. Address Block places one object. ODS/XLSX/CSV.",
    "Color": "Convert color space (CMYK, RGB, grayscale) at a chosen DPI.\nCMYK is for commercial print; RGB is for screen/web.",
    "Preflight": "Audit fonts, images, color, boxes, bleed, transparency, hairlines, and TAC.\nFree: read the report. Pro: JSON/PDF export and jumps to fix tools.",
    "Automation": "Three hot folders. Each pipeline has its own input, output, and recipe.\nOne watcher runs every pipeline that is filled in.",
    "JoinSplit": "Join makes one document so later steps in the stack run on the combined file.\nSplit writes one PDF per page with the page number in the name.",
    "Unlock": "Clear Print Lock and Edit Lock written by ReadySetPDF.\nA PDF that will not open until a password is typed stays locked.",
    "OCR": "Three OCR hot folders. Drop scans in a watch folder.\nEach pipeline writes a searchable PDF at the original page size.",
    "Folds": "Brochure fold guides on the current sheet: panels, tuck compensation, and bleed.\nExport a die-line proof only — this is not a production step.",
}

# Free tools first, then Pro. A saved tab_order can rearrange this.
TAB_BUTTONS = (
    ("📐 Resize", "Resize"),
    ("📏 Crop", "Crop"),
    ("✂️ Cutter", "Cutter"),
    ("🔄 Rotate", "Rotate"),
    ("📎 Join / Split", "JoinSplit"),
    ("🔓 Unlock ReadySetPDF locked files", "Unlock"),
    ("📄 Folds", "Folds"),
    ("✅ Preflight", "Preflight"),
    ("🏷️ Mail Merge/Stamp *", "VDP"),
    ("🎨 Color *", "Color"),
    ("📂 Automation *", "Automation"),
    ("👁️ OCR Extract *", "OCR"),
    ("📖 Booklet *", "Booklet"),
    ("🔲 Grid *", "Grid"),
)

# ====================== TOOLTIP CLASS ======================
class ToolTip(object):
    def __init__(self, widget, text, app):
        self.widget, self.text, self.app = widget, text, app
        self.tw = None
        self._after = None
        self.widget.bind("<Enter>", self.enter, add="+")
        self.widget.bind("<Leave>", self.close, add="+")
        self.widget.bind("<ButtonPress>", self.close, add="+")

    def enter(self, event=None):
        self.close()
        try:
            self._after = self.widget.after(450, self._show)
        except Exception:
            self._after = None

    def _show(self):
        self._after = None
        if self.tw or not self.widget.winfo_exists():
            return
        try:
            x = self.widget.winfo_rootx() + self.widget.winfo_width() + 10
            y = self.widget.winfo_rooty()
        except Exception:
            return
        self.tw = tk.Toplevel(self.widget)
        self.tw.wm_overrideredirect(True)
        try:
            self.tw.wm_attributes("-topmost", True)
        except Exception:
            pass
        self.tw.wm_geometry(f"+{x}+{y}")
        tk.Label(
            self.tw, text=self.text, background=self.app.color_pale, foreground=self.app.color_navy,
            relief="flat", borderwidth=1, highlightbackground=self.app.color_steel, highlightthickness=1,
            font=("Arial", "9", "bold"), padx=6, pady=4, justify="left", wraplength=320,
        ).pack(ipadx=1)
        self.tw.bind("<Enter>", self.close, add="+")
        self.tw.bind("<ButtonPress>", self.close, add="+")

    def close(self, event=None):
        if self._after:
            try:
                self.widget.after_cancel(self._after)
            except Exception:
                pass
            self._after = None
        if self.tw:
            try:
                self.tw.destroy()
            except Exception:
                pass
            self.tw = None

_ASSET_FILE_FILTERS = (
    ("PDF & Images", "*.pdf;*.png;*.jpg;*.jpeg;*.tif;*.tiff"),
    ("PDF", "*.pdf"),
    ("Images", "*.png;*.jpg;*.jpeg;*.tif;*.tiff"),
    ("All files", "*.*"),
)
_RECIPE_FILE_FILTERS = (("JSON Recipe", "*.json"),)


def _dialog_vtable(dialog, index, restype, *argtypes):
    import ctypes
    from ctypes import WINFUNCTYPE, c_void_p
    table = ctypes.cast(dialog, ctypes.POINTER(ctypes.POINTER(c_void_p))).contents
    return WINFUNCTYPE(restype, c_void_p, *argtypes)(table[index])


def _windows_force_dialog_folder(dialog, folder):
    """Open this dialog in folder. Windows otherwise reuses the last folder from any pane."""
    import ctypes
    from ctypes import HRESULT, POINTER, byref, c_void_p
    from ctypes.wintypes import BYTE, DWORD, LPCWSTR, WORD

    if not folder or not os.path.isdir(folder):
        return False

    class GUID(ctypes.Structure):
        _fields_ = [
            ("Data1", DWORD),
            ("Data2", WORD),
            ("Data3", WORD),
            ("Data4", BYTE * 8),
        ]

    def _guid(text):
        import uuid
        value = uuid.UUID(text)
        return GUID(
            value.time_low, value.time_mid, value.time_hi_version,
            (BYTE * 8).from_buffer_copy(value.bytes[8:]),
        )

    shell32 = ctypes.windll.shell32
    item = c_void_p()
    try:
        shell_iid = _guid("43826D1E-E718-42EE-BC55-A1E261C37BFE")
        shell32.SHCreateItemFromParsingName.argtypes = [LPCWSTR, c_void_p, POINTER(GUID), POINTER(c_void_p)]
        shell32.SHCreateItemFromParsingName.restype = HRESULT
        if shell32.SHCreateItemFromParsingName(os.path.abspath(folder), None, byref(shell_iid), byref(item)) != 0 or not item.value:
            return False
        set_folder = _dialog_vtable(dialog, 12, HRESULT, c_void_p)
        return set_folder(dialog, item) == 0
    except Exception:
        return False
    finally:
        if item.value:
            try:
                _dialog_vtable(item, 2, ctypes.c_ulong)(item)
            except Exception:
                pass


def _windows_pick_files(hwnd, title, probe=False, initial_dir=None, filters=None, multi=True, save=False):
    """Windows file dialog. Returns a list, [] on cancel, or None if the dialog cannot be created."""
    import ctypes
    from ctypes import HRESULT, POINTER, WINFUNCTYPE, byref, c_void_p
    from ctypes.wintypes import BYTE, DWORD, HWND, LPCWSTR, UINT, WORD

    ole32 = ctypes.windll.ole32

    class GUID(ctypes.Structure):
        _fields_ = [
            ("Data1", DWORD),
            ("Data2", WORD),
            ("Data3", WORD),
            ("Data4", BYTE * 8),
        ]

    class FILTERSPEC(ctypes.Structure):
        _fields_ = [("pszName", LPCWSTR), ("pszSpec", LPCWSTR)]

    def _guid(text):
        import uuid
        value = uuid.UUID(text)
        return GUID(
            value.time_low, value.time_mid, value.time_hi_version,
            (BYTE * 8).from_buffer_copy(value.bytes[8:]),
        )

    def _item_path(item):
        item_table = ctypes.cast(item, POINTER(POINTER(c_void_p))).contents
        name_ptr = c_void_p()
        get_name = WINFUNCTYPE(HRESULT, c_void_p, DWORD, POINTER(c_void_p))(item_table[5])
        path = ""
        if get_name(item, DWORD(0x80058000), byref(name_ptr)) == 0 and name_ptr.value:
            path = ctypes.wstring_at(name_ptr)
            ole32.CoTaskMemFree(name_ptr)
        WINFUNCTYPE(ctypes.c_ulong, c_void_p)(item_table[2])(item)
        return path

    started = False
    dialog = c_void_p()
    try:
        hr = ole32.CoInitialize(None)
        if hr in (0, 1):
            started = True
        if save:
            clsid = _guid("C0B4E2F3-BA21-4773-8DBA-335EC946EB8B")
            iid = _guid("84bccd23-5fde-4cdb-aea4-af64b83d78ab")
        else:
            clsid = _guid("DC1C5A9C-E88A-4dde-A5A1-60F82A20AEF7")
            iid = _guid("d57c7288-d4ad-4768-be02-9d969532d960")
        ole32.CoCreateInstance.argtypes = [POINTER(GUID), c_void_p, DWORD, POINTER(GUID), POINTER(c_void_p)]
        ole32.CoCreateInstance.restype = HRESULT
        if ole32.CoCreateInstance(byref(clsid), None, 1, byref(iid), byref(dialog)) != 0 or not dialog.value:
            return None

        def _method(index, restype, *argtypes):
            return _dialog_vtable(dialog, index, restype, *argtypes)

        get_options = _method(10, HRESULT, POINTER(DWORD))
        set_options = _method(9, HRESULT, DWORD)
        set_types = _method(4, HRESULT, UINT, POINTER(FILTERSPEC))
        set_title = _method(17, HRESULT, LPCWSTR)
        show = _method(3, HRESULT, HWND)

        options = DWORD()
        if get_options(dialog, byref(options)) != 0:
            return None
        flags = 0x40 | 0x800
        if not save:
            flags |= 0x1000
        if multi and not save:
            flags |= 0x200
        if set_options(dialog, DWORD(options.value | flags)) != 0:
            return None
        if probe:
            checked = DWORD()
            if get_options(dialog, byref(checked)) != 0:
                return None
            return checked.value
        chosen_filters = filters or _ASSET_FILE_FILTERS
        specs = (FILTERSPEC * len(chosen_filters))()
        for index, (name, pattern) in enumerate(chosen_filters):
            specs[index].pszName = name
            specs[index].pszSpec = pattern
        set_types(dialog, len(chosen_filters), specs)
        set_title(dialog, title)
        if save:
            _method(22, HRESULT, LPCWSTR)(dialog, "json")
        _windows_force_dialog_folder(dialog, initial_dir)
        shown = show(dialog, HWND(hwnd or 0))
        if shown != 0:
            return []

        if multi and not save:
            array = c_void_p()
            get_results = _method(27, HRESULT, POINTER(c_void_p))
            if get_results(dialog, byref(array)) != 0 or not array.value:
                return []

            def _array_method(index, restype, *argtypes):
                table = ctypes.cast(array, POINTER(POINTER(c_void_p))).contents
                return WINFUNCTYPE(restype, c_void_p, *argtypes)(table[index])

            count = DWORD()
            if _array_method(7, HRESULT, POINTER(DWORD))(array, byref(count)) != 0:
                _array_method(2, ctypes.c_ulong)(array)
                return []
            paths = []
            get_item = _array_method(8, HRESULT, DWORD, POINTER(c_void_p))
            for index in range(count.value):
                item = c_void_p()
                if get_item(array, DWORD(index), byref(item)) != 0 or not item.value:
                    continue
                path = _item_path(item)
                if path:
                    paths.append(path)
            _array_method(2, ctypes.c_ulong)(array)
            return paths

        item = c_void_p()
        get_result = _method(20, HRESULT, POINTER(c_void_p))
        if get_result(dialog, byref(item)) != 0 or not item.value:
            return []
        path = _item_path(item)
        return [path] if path else []
    except Exception:
        return None
    finally:
        if dialog.value:
            try:
                _dialog_vtable(dialog, 2, ctypes.c_ulong)(dialog)
            except Exception:
                pass
        if started:
            try:
                ole32.CoUninitialize()
            except Exception:
                pass


# ====================== APP CLASS ======================
class ReadySetPDFApp(HotFolderMixin, PreflightMixin, ColorMixin, OcrMixin):
    def __init__(self):
        try:
            import ctypes
            myappid = 'readysetpdf.pro.prepress.4.0' 
            ctypes.windll.shell32.SetCurrentProcessExplicitAppUserModelID(myappid)
        except Exception:
            pass
        
        self.root = TkinterDnD.Tk()
        self.root.title(f"ReadySetPDF {APP_VERSION} - Professional Prepress")
        
        if hasattr(sys, '_MEIPASS'):
            base_path = sys._MEIPASS
        else:
            base_path = os.path.dirname(os.path.abspath(__file__))
            
        self.logo_path = os.path.join(base_path, "ReadySetPDF logo.jpg")
        icon_path = os.path.join(base_path, "icon.ico")
        
        if os.path.exists(self.logo_path):
            try:
                self.app_icon = ImageTk.PhotoImage(Image.open(self.logo_path))
                self.root.iconphoto(False, self.app_icon)
            except Exception:
                if os.path.exists(icon_path): self.root.iconbitmap(icon_path)
        elif os.path.exists(icon_path):
            self.root.iconbitmap(icon_path)
            
        self.root.geometry("1450x920")

        self.appdata_dir = os.path.join(os.environ.get('LOCALAPPDATA', os.path.expanduser('~')), 'ReadySetPDF')
        os.makedirs(self.appdata_dir, exist_ok=True)
        self.settings_file = os.path.join(self.appdata_dir, 'settings.json')

        self.settings = {
            "global_unit": "inches",
            "theme": "Tech Theme (Default)",
            "custom_sizes": {},
            "page_box_mode": PAGE_BOX_KEEP,
        }
        if os.path.exists(self.settings_file):
            try:
                with open(self.settings_file, 'r') as f:
                    self.settings.update(json.load(f))
            except Exception: pass

        self.global_unit_var = tk.StringVar(value=self.settings["global_unit"])
        self.current_theme_var = tk.StringVar(value=self.settings["theme"])
        self.custom_sizes = self.settings["custom_sizes"]
        stored_order = self.settings.get("custom_size_order") or list(self.custom_sizes.keys())
        self.custom_size_order = [name for name in stored_order if name in self.custom_sizes]
        for name in self.custom_sizes:
            if name not in self.custom_size_order:
                self.custom_size_order.append(name)
        
        self.themes = {
            "Tech Theme (Default)": {"WHITE": "#F3EEE8", "NAVY": "#19123D", "LIME": "#B2F332", "STEEL": "#6787AF", "MINT": "#BADDCF", "PALE": "#E8F3DA"},
            "Ink Wash": {"WHITE": "#FFFFE3", "NAVY": "#4A4A4A", "LIME": "#6D8196", "STEEL": "#CBCBCB", "MINT": "#E2E2C7", "PALE": "#F0F0D8"},
            "California Beaches": {"WHITE": "#FAFAFA", "NAVY": "#2C3E50", "LIME": "#FFC067", "STEEL": "#7D99AA", "MINT": "#66F4FF", "PALE": "#E6FAFC"},
            "Cobalt Sky": {"WHITE": "#F4F7FB", "NAVY": "#000080", "LIME": "#0047AB", "STEEL": "#6D8196", "MINT": "#82C8E5", "PALE": "#EBF4FA"}
        }
        self.set_colors()
        self.root.configure(bg=self.color_white)
        self.main_container = tk.Frame(self.root, bg=self.color_white)
        self.main_container.pack(fill="both", expand=True)

        self.files, self.action_queue, self.active_history_index = [], [], -1
        self.preview_doc = None
        self.current_preview_page = 0
        self.current_preview_file_index = 0
        self.background_tasks = []
        self.is_processing_batch = False

        # --- UI VARIABLES ---
        self.rotate_deg_var = tk.StringVar(value="90")
        self.rotate_pages_var = tk.StringVar(value="all")
        self.join_split_mode_var = tk.StringVar(value="join")
        self.join_name_var = tk.StringVar(value="first_file")
        self.split_name_var = tk.StringVar(value="page")
        self.join_split_example_var = tk.StringVar(value="Example: Combined_card.pdf")
        self.resize_preset_var = tk.StringVar(value="Letter")
        self.resize_w_var = tk.StringVar(value="8.5")
        self.resize_h_var = tk.StringVar(value="11")
        self.resize_landscape_var = tk.BooleanVar(value=False)
        self.resize_stretch_var = tk.BooleanVar(value=False)
        self.crop_left_var = tk.StringVar(value="0")
        self.crop_top_var = tk.StringVar(value="0")
        self.crop_right_var = tk.StringVar(value="0")
        self.crop_bottom_var = tk.StringVar(value="0")
        
        self.grid_preset_var = tk.StringVar(value="12x18")
        self.grid_w_var = tk.StringVar(value="12")
        self.grid_h_var = tk.StringVar(value="18")
        self.grid_landscape_var = tk.BooleanVar(value=False)
        self.grid_order_var = tk.StringVar(value="Sequential")
        self.grid_double_sided_var = tk.BooleanVar(value=False)
        self.grid_repeat_var = tk.StringVar(value="1")
        self.grid_autoscale_var = tk.BooleanVar(value=False)
        self.grid_aspect_var = tk.BooleanVar(value=True)
        self.grid_auto_fit_var = tk.BooleanVar(value=False)
        self.grid_direction_var = tk.StringVar(value="LTR")
        self.grid_cols_var = tk.StringVar(value="2")
        self.grid_rows_var = tk.StringVar(value="2")
        self.grid_margin_l_var = tk.StringVar(value="0")
        self.grid_margin_t_var = tk.StringVar(value="0")
        self.grid_gutter_h_var = tk.StringVar(value="0.25")
        self.grid_gutter_v_var = tk.StringVar(value="0.25")
        self.grid_center_var = tk.BooleanVar(value=True)
        self.grid_draw_marks_var = tk.BooleanVar(value=True)
        self.grid_mark_dist_var = tk.StringVar(value="0.125")    
        self.grid_mark_thick_var = tk.StringVar(value="0.007")
        self.grid_mark_overlap_var = tk.StringVar(value="0")
        self.grid_mark_color_var = tk.StringVar(value="black")
        self.grid_flip_edge_var = tk.StringVar(value="long")
        self.grid_anchor_var = tk.StringVar(value="c")
        self.grid_art_has_bleed_var = tk.BooleanVar(value=False)
        self.grid_trim_w_var = tk.StringVar(value="")
        self.grid_trim_h_var = tk.StringVar(value="")
        
        self.blank_pos_var = tk.StringVar(value="End of Document")
        self.blank_page_num_var = tk.StringVar(value="1")
        self.booklet_preset_var = tk.StringVar(value="Custom")
        self.booklet_w_var = tk.StringVar(value="18")
        self.booklet_h_var = tk.StringVar(value="12")
        self.booklet_landscape_var = tk.BooleanVar(value=False)
        self.booklet_center_gutter_var = tk.StringVar(value="0")
        self.booklet_margin_l_var = tk.StringVar(value="0")
        self.booklet_margin_t_var = tk.StringVar(value="0")
        self.booklet_creep_var = tk.StringVar(value="0")
        self.booklet_creep_dir_var = tk.StringVar(value="Outward")
        self.booklet_center_var = tk.BooleanVar(value=True)
        self.booklet_anchor_var = tk.StringVar(value="c")
        self.booklet_rotate_var = tk.BooleanVar(value=False)
        self.booklet_art_has_bleed_var = tk.BooleanVar(value=False)
        self.booklet_trim_w_var = tk.StringVar(value="")
        self.booklet_trim_h_var = tk.StringVar(value="")
        self.booklet_draw_marks_var = tk.BooleanVar(value=False)
        self.booklet_mark_dist_var = tk.StringVar(value="0.125")
        self.booklet_mark_thick_var = tk.StringVar(value="0.007")
        self.booklet_mark_overlap_var = tk.StringVar(value="0")
        self.booklet_mark_color_var = tk.StringVar(value="black")
        
        self.cutter_size_var = tk.StringVar(value="0.13")
        self.cutter_thick_var = tk.StringVar(value="0.03")
        self.cutter_placement_var = tk.StringVar(value="Inside")
        self.cutter_margin_var = tk.StringVar(value="0")
        self.cutter_pages_var = tk.StringVar(value="all")
        self.cutter_remove_art_var = tk.BooleanVar(value=False)
        self.cutter_l_marks_var = tk.BooleanVar(value=True)
        self.cutter_collate_var = tk.StringVar(value="None")
        self.cutter_corner_var = tk.StringVar(value="Top Left")
        self.cutter_mark_color_var = tk.StringVar(value="black")
        self.page_box_mode_var = tk.StringVar(
            value=normalize_page_box_mode(self.settings.get("page_box_mode", PAGE_BOX_KEEP))
        )
        self.page_geo_summary_var = tk.StringVar(value="Load a file to read Media / Crop / Trim.")
        self.color_mode_var = tk.StringVar(value="Grayscale")
        self.color_dpi_var = tk.StringVar(value="300")
        
        self.preview_zoom_var = tk.StringVar(value="1.0x (Fit Width)")
        self.preview_merge_var = tk.BooleanVar(value=False)
        self.show_measurements_var = tk.BooleanVar(value=True)
        self.ruler_band = 28
        
        self.apply_stamp_var = tk.BooleanVar(value=False)
        self.stamp_text_var = tk.StringVar(value="DIGITAL PROOF")
        self.lock_print_var = tk.BooleanVar(value=False)
        self.lock_edit_var = tk.BooleanVar(value=False)
        self.custom_owner_pw_var = tk.StringVar(value="readysetpdf")  
        self.export_suffix_var = tk.StringVar(value="_readysetpdf")
        
        # EXPORT SIZE OPTIMIZATION VARIABLES
        self.export_compress_streams_var = tk.BooleanVar(value=True)
        self.export_optimize_images_var = tk.BooleanVar(value=True)
        self.export_max_dpi_var = tk.StringVar(
            value=str(self.settings.get("export_max_dpi", "Original") or "Original")
        )

        self.batch_in_var = tk.StringVar()
        self.batch_out_var = tk.StringVar()
        self.batch_recipe_var = tk.StringVar()
        self.is_watching = False
        self.vdp_csv_path_var = tk.StringVar()
        self.vdp_headers = []
        self.vdp_mapped_fields = []
        
        self.vdp_source_type_var = tk.StringVar(value="column")
        self.vdp_custom_text_var = tk.StringVar(value="Ticket-[NUM]")
        self.vdp_num_start_var = tk.StringVar(value="1")
        self.vdp_num_pad_var = tk.StringVar(value="3")
        self.vdp_generate_count_var = tk.StringVar(value="1")
        self.vdp_target_mode = False
        self.vdp_col_var = tk.StringVar()
        self.vdp_type_var = tk.StringVar(value="Text")
        self.vdp_x_var = tk.StringVar(value="0.5")
        self.vdp_y_var = tk.StringVar(value="0.5")
        self.vdp_w_var = tk.StringVar(value="2.0")
        self.vdp_h_var = tk.StringVar(value="0.5")
        self.vdp_font_var = tk.StringVar(value="Arial")
        self.vdp_size_var = tk.StringVar(value="12")
        self.vdp_align_var = tk.StringVar(value="Left")
        self.vdp_color_var = tk.StringVar(value="#000000")
        self.vdp_autoscale_var = tk.BooleanVar(value=True)
        self.vdp_bold_var = tk.BooleanVar(value=False)
        self.vdp_italic_var = tk.BooleanVar(value=False)
        self.vdp_underline_var = tk.BooleanVar(value=False)
        self.vdp_rotate_var = tk.StringVar(value="0")
        self.vdp_unit_label_var = tk.StringVar(value="in")
        self.vdp_selected_column = None
        self.vdp_selected_index = None
        self.vdp_address_block = None
        self.vdp_address_map = {}
        self._vdp_sample_row_cache = None
        self._vdp_place_armed = False
        self._vdp_undo_stack = []
        self._vdp_hover_index = None
        self.vdp_drag = None
        self.vdp_layout_scale = 1.0
        self.vdp_layout_origin = (0.0, 0.0)
        self.vdp_page_size = (612.0, 792.0)
        self.vdp_hint_var = tk.StringVar(value="Load a PDF template and a spreadsheet to place merge fields.")
        self.vdp_page_label_var = tk.StringVar(value="Page: 0 / 0")
        self.vdp_field_id_seq = 0
        self._vdp_syncing = False
        self._vdp_canvas_size = (0, 0)
        self.unlock_pass_var = tk.StringVar(value="readysetpdf")
        self.unlock_in_var = tk.StringVar()
        self.unlock_out_var = tk.StringVar()
        self.unlock_suffix_var = tk.StringVar(value="_unlocked")
        
        self.ocr_mode_var = tk.StringVar(value="txt")
        self.ocr_lang_var = tk.StringVar(value="eng")

        self.fold_type_var = tk.StringVar(value="trifold")
        self.fold_preset_var = tk.StringVar(value="Letter")
        self.fold_w_var = tk.StringVar(value="11")
        self.fold_h_var = tk.StringVar(value="8.5")
        self.fold_landscape_var = tk.BooleanVar(value=True)
        self.fold_bleed_var = tk.StringVar(value="0.125")
        self.fold_along_var = tk.StringVar(value="width")
        self.fold_art_has_bleed_var = tk.BooleanVar(value=True)
        self.fold_use_pdf_size_var = tk.BooleanVar(value=False)
        self.fold_summary_var = tk.StringVar(value="")
        self.fold_desc_var = tk.StringVar(value="")

        self.preview_img_w = 0; self.preview_img_h = 0
        self.preview_pos_x = 0; self.preview_pos_y = 0
        self.preview_final_scale = 1.0

        self.vdp_x_var.trace_add("write", self._on_vdp_geometry_change)
        self.vdp_y_var.trace_add("write", self._on_vdp_geometry_change)
        self.vdp_w_var.trace_add("write", self._on_vdp_geometry_change)
        self.vdp_h_var.trace_add("write", self._on_vdp_geometry_change)
        self.vdp_font_var.trace_add("write", self._on_vdp_geometry_change)
        self.vdp_size_var.trace_add("write", self._on_vdp_geometry_change)
        self.vdp_align_var.trace_add("write", self._on_vdp_geometry_change)
        self.vdp_color_var.trace_add("write", self._on_vdp_geometry_change)
        self.vdp_type_var.trace_add("write", self._on_vdp_geometry_change)
        self.vdp_autoscale_var.trace_add("write", self._on_vdp_geometry_change)
        self.vdp_bold_var.trace_add("write", self._on_vdp_geometry_change)
        self.vdp_italic_var.trace_add("write", self._on_vdp_geometry_change)
        self.vdp_underline_var.trace_add("write", self._on_vdp_geometry_change)
        self.vdp_rotate_var.trace_add("write", self._on_vdp_geometry_change)

        self._loading_form = False
        self._step_commit_buttons = []
        self._apply_vdp_unit_defaults(self.global_unit_var.get(), force=True)

        self.license_state = licensing.load_state()
        self._settings_win = None
        self._license_entry = None
        self._account_status_var = None
        self._account_sentence_var = None
        self.hotfix_status_var = tk.StringVar(value="")
        self._hotfix_busy = False

        self.setup_styles()
        self.setup_ui()
        self._bind_live_preview_traces()
        self.root.after(300, self._validate_license_on_startup)

    def set_colors(self):
        theme = self.themes.get(self.current_theme_var.get(), self.themes["Tech Theme (Default)"])
        self.color_white = theme["WHITE"]; self.color_navy = theme["NAVY"]
        self.color_lime = theme["LIME"]; self.color_steel = theme["STEEL"]
        self.color_mint = theme["MINT"]; self.color_pale = theme["PALE"]

    def change_theme(self, event=None):
        self._dock_preview()
        self._dock_side_panel("assets")
        self._dock_side_panel("steps")
        for name in ("_assets_body", "_steps_body"):
            panel = getattr(self, name, None)
            if panel is not None:
                try:
                    panel.destroy()
                except Exception:
                    pass
                setattr(self, name, None)
        body = getattr(self, "_monitor_body", None)
        if body is not None:
            try:
                body.destroy()
            except Exception:
                pass
            self._monitor_body = None
        # Pane titles live on the root so they can sit in the LabelFrame border.
        # Drop them with the old layout or they stay behind after the rebuild.
        for btn_name in ("_assets_pop_btn", "_steps_pop_btn"):
            btn = getattr(self, btn_name, None)
            header = getattr(btn, "master", None) if btn is not None else None
            if header is not None and header is not self.root and self._widget_alive(header):
                try:
                    header.destroy()
                except Exception:
                    pass
        self._monitor_chrome_hosts = []
        self.set_colors()
        self.root.configure(bg=self.color_white)
        self.main_container.destroy()
        self.setup_styles()
        self.main_container = tk.Frame(self.root, bg=self.color_white)
        self.main_container.pack(fill="both", expand=True)
        try:
            self.setup_ui()
        finally:
            # setup_ui used to abort once a file was open, leaving this list empty
            # while self.files still counted toward the free one-file limit.
            self._sync_file_list_widget()
            self._sync_queue_widget()
        self.render_live_preview()
        
    def save_settings(self):
        self.settings["global_unit"] = self.global_unit_var.get()
        self.settings["theme"] = self.current_theme_var.get()
        self.settings["custom_sizes"] = self.custom_sizes
        self.settings["custom_size_order"] = list(self.custom_size_order)
        self.settings["page_box_mode"] = normalize_page_box_mode(self.page_box_mode_var.get())
        if hasattr(self, "export_max_dpi_var"):
            chosen = self.export_max_dpi_var.get().strip() or "Original"
            self.settings["export_max_dpi"] = chosen
        try:
            with open(self.settings_file, 'w') as f:
                json.dump(self.settings, f, indent=4)
        except Exception as e:
            print(f"Failed to save AppData settings: {e}")

    def _dialog_folder(self, key):
        folder = str(self.settings.get(key) or "").strip()
        if folder and os.path.isdir(folder):
            return os.path.normpath(folder)
        return ""

    def _remember_dialog_folder(self, key, path):
        if not path:
            return
        folder = path if os.path.isdir(path) else os.path.dirname(os.path.abspath(path))
        if not folder or not os.path.isdir(folder):
            return
        folder = os.path.normpath(folder)
        if self.settings.get(key) == folder:
            return
        self.settings[key] = folder
        self.save_settings()

    def _tool_tab_locked(self, key):
        # Preflight tab stays open on Free so the report can be read; exports/fixups
        # still call licensing.tool_unlocked("Preflight") inside PreflightMixin.
        if key == "Preflight":
            return False
        return not licensing.tool_unlocked(key, self.license_state)

    def _style_tool_button(self, key, btn, active=False):
        if self._tool_tab_locked(key):
            btn.config(
                bg="#c5c5c5", fg="#6a6a6a",
                activebackground="#b0b0b0", activeforeground="#4a4a4a",
            )
            return
        if active:
            btn.config(
                bg=self.color_steel, fg=self.color_white,
                activebackground=self.color_steel, activeforeground=self.color_white,
            )
        else:
            btn.config(
                bg=self.color_mint, fg=self.color_navy,
                activebackground=self.color_steel, activeforeground=self.color_white,
            )

    def _refresh_tool_lock_styles(self):
        active = getattr(self, "current_active_tab", None)
        for key, btn in getattr(self, "tab_btns", {}).items():
            try:
                if not btn.winfo_exists():
                    continue
            except Exception:
                continue
            self._style_tool_button(key, btn, active=(key == active and not self._tool_tab_locked(key)))
        if hasattr(self, "_refresh_preflight_action_styles"):
            try:
                self._refresh_preflight_action_styles()
            except Exception:
                pass

    def _refresh_account_panel(self):
        status = getattr(self, "_account_status_var", None)
        sentence = getattr(self, "_account_sentence_var", None)
        if status is not None:
            status.set(licensing.status_line(self.license_state))
        if sentence is not None:
            sentence.set(licensing.status_sentence(self.license_state))
        footer = getattr(self, "footer_status_var", None)
        if footer is not None:
            footer.set(f"Rev {APP_VERSION} | {licensing.footer_text(self.license_state)}")

    def _focus_license_field(self):
        notebook = getattr(self, "_settings_notebook", None)
        pref = getattr(self, "_settings_pref_tab", None)
        if notebook is not None and pref is not None:
            try:
                notebook.select(pref)
            except Exception:
                pass
        entry = getattr(self, "_license_entry", None)
        win = getattr(self, "_settings_win", None)
        if entry is None:
            return
        try:
            if win is not None and win.winfo_exists():
                win.lift()
                win.focus_force()
            entry.focus_force()
            entry.selection_range(0, tk.END)
            entry.icursor(tk.END)
        except Exception:
            pass

    def _activate_license(self):
        key = self._license_key_var.get() if getattr(self, "_license_key_var", None) is not None else ""
        ok, message = licensing.activate(key)
        parent = self._settings_win if getattr(self, "_settings_win", None) is not None else self.root
        if not ok:
            messagebox.showerror("License", message, parent=parent)
            self._focus_license_field()
            return
        self.license_state = licensing.load_state()
        self._refresh_account_panel()
        self._refresh_tool_lock_styles()
        if getattr(self, "_license_key_var", None) is not None:
            self._license_key_var.set("")
        messagebox.showinfo("License", message, parent=parent)

    def _open_buy_monthly(self):
        webbrowser.open(licensing.MONTHLY_CHECKOUT_URL)

    def _open_buy_yearly(self):
        webbrowser.open(licensing.YEARLY_CHECKOUT_URL)

    def _settings_popup_geometry(self, screen_w, screen_h, content_h, prefer_w=620):
        """Size Global Settings to the screen.

        Width stays near 620. Height is the content height, capped at about 85% of
        the screen so the title bar stays on screen and the bottom is not clipped
        by the taskbar. geometry() height is the client area; the title bar sits
        above it, so that chrome is reserved before centering.
        """
        screen_w = max(int(screen_w or 0), 1)
        screen_h = max(int(screen_h or 0), 1)
        side_margin = 16
        top_margin = 8
        title_px = 40
        taskbar_px = 48
        width = min(int(prefer_w), max(320, screen_w - side_margin * 2))
        max_h = int(screen_h * 0.85)
        usable_h = screen_h - top_margin - title_px - taskbar_px
        max_h = max(1, min(max_h, usable_h))
        height = max(1, int(content_h or 1))
        height = min(height, max_h)
        outer_h = height + title_px
        x = max(0, (screen_w - width) // 2)
        span = max(0, (screen_h - taskbar_px) - top_margin - outer_h)
        y = top_margin + span // 2
        if x + width > screen_w:
            x = max(0, screen_w - width)
        if y < 0:
            y = 0
        if y + outer_h > screen_h - taskbar_px:
            y = max(0, screen_h - taskbar_px - outer_h)
        return width, height, x, y

    def _mount_settings_scroller(self, parent):
        """Vertical canvas + scrollbar. Returns (canvas, scrollbar, body)."""
        canvas = tk.Canvas(parent, bg=self.color_white, highlightthickness=0, bd=0)
        scrollbar = ttk.Scrollbar(parent, orient="vertical", command=canvas.yview)
        canvas.configure(yscrollcommand=scrollbar.set)
        scrollbar.pack(side="right", fill="y")
        canvas.pack(side="left", fill="both", expand=True)
        body = ttk.Frame(canvas)
        window_id = canvas.create_window((0, 0), window=body, anchor="nw")

        def _sync_scroll(_event=None):
            try:
                canvas.configure(scrollregion=canvas.bbox("all") or (0, 0, 0, 0))
            except Exception:
                pass

        def _fit_width(event):
            try:
                canvas.itemconfigure(window_id, width=max(event.width, 1))
            except Exception:
                pass
            _sync_scroll()

        def _on_wheel(event):
            delta = getattr(event, "delta", 0)
            if delta:
                canvas.yview_scroll(int(-1 * (delta / 120)), "units")
            elif getattr(event, "num", None) == 4:
                canvas.yview_scroll(-1, "units")
            elif getattr(event, "num", None) == 5:
                canvas.yview_scroll(1, "units")
            else:
                return None
            return "break"

        def _bind_wheel(widget):
            widget.bind("<MouseWheel>", _on_wheel)
            widget.bind("<Button-4>", _on_wheel)
            widget.bind("<Button-5>", _on_wheel)
            for child in widget.winfo_children():
                _bind_wheel(child)

        body.bind("<Configure>", _sync_scroll)
        canvas.bind("<Configure>", _fit_width)
        canvas._rsp_window_id = window_id
        canvas._rsp_bind_wheel = _bind_wheel
        canvas._rsp_sync_scroll = _sync_scroll
        _bind_wheel(canvas)
        _bind_wheel(body)
        return canvas, scrollbar, body

    def _place_settings_window(self, win, content_h):
        try:
            screen_w = win.winfo_screenwidth()
            screen_h = win.winfo_screenheight()
        except Exception:
            screen_w, screen_h = 1280, 720
        width, height, x, y = self._settings_popup_geometry(screen_w, screen_h, content_h)
        try:
            anchor_x = self.root.winfo_rootx()
            anchor_y = self.root.winfo_rooty()
            anchor_w = max(self.root.winfo_width(), 1)
            anchor_h = max(self.root.winfo_height(), 1)
            x = anchor_x + max(0, (anchor_w - width) // 2)
            y = anchor_y + max(0, (anchor_h - height) // 2)
        except Exception:
            pass
        x = min(max(0, int(x)), max(0, screen_w - width))
        title_px = 40
        taskbar_px = 48
        outer_h = height + title_px
        y = min(max(0, int(y)), max(0, screen_h - taskbar_px - outer_h))
        win.geometry(f"{width}x{height}+{x}+{y}")
        try:
            win.minsize(min(480, width), min(320, height))
        except Exception:
            pass
        return width, height

    def _validate_license_on_startup(self):
        def work():
            message = licensing.validate_on_startup()

            def apply():
                self.license_state = licensing.load_state()
                self._refresh_account_panel()
                self._refresh_tool_lock_styles()
                if message:
                    messagebox.showerror("License", message, parent=self.root)

            try:
                self.root.after(0, apply)
            except Exception:
                pass

        threading.Thread(target=work, daemon=True).start()

    def open_settings_window(self, focus_license=False):
        existing = getattr(self, "_settings_win", None)
        if existing is not None:
            try:
                if existing.winfo_exists():
                    existing.lift()
                    existing.focus_force()
                    if focus_license:
                        open_license_dialog(self)
                    return
            except Exception:
                pass

        win = tk.Toplevel(self.root)
        win.title("Global Settings")
        win.configure(bg=self.color_white)
        win.transient(self.root)
        self._settings_win = win
        # Cap immediately so a short screen never shows the old fixed 860px height.
        self._place_settings_window(win, 10 ** 6)
        win.grab_set()

        def _close_settings():
            self._settings_win = None
            self._license_entry = None
            self._settings_notebook = None
            self._settings_pref_tab = None
            self._settings_pref_canvas = None
            self._settings_pref_scroll = None
            try:
                win.destroy()
            except Exception:
                pass

        win.protocol("WM_DELETE_WINDOW", _close_settings)

        notebook = ttk.Notebook(win)
        notebook.pack(fill="both", expand=True, padx=10, pady=10)
        self._settings_notebook = notebook

        pref_frame = ttk.Frame(notebook)
        notebook.add(pref_frame, text="Preferences")
        self._settings_pref_tab = pref_frame
        pref_canvas, pref_scroll, pref_body = self._mount_settings_scroller(pref_frame)
        self._settings_pref_canvas = pref_canvas
        self._settings_pref_scroll = pref_scroll

        acct = ttk.LabelFrame(pref_body, text="Account", padding=10)
        acct.pack(fill="x", padx=10, pady=10)
        self._account_status_var = tk.StringVar(value=licensing.status_line(self.license_state))
        self._account_sentence_var = tk.StringVar(value=licensing.status_sentence(self.license_state))
        tk.Label(
            acct, textvariable=self._account_status_var,
            bg=self.color_white, fg=self.color_navy, font=("Arial", 10, "bold"), anchor="w",
        ).pack(anchor="w")
        tk.Label(
            acct, textvariable=self._account_sentence_var,
            bg=self.color_white, fg=self.color_navy, font=("Arial", 9), anchor="w", justify="left",
        ).pack(anchor="w", pady=(4, 8))
        tk.Label(
            acct, text=licensing.FREE_TOOLS,
            bg=self.color_white, fg=self.color_navy, font=("Arial", 9), anchor="w", justify="left",
        ).pack(anchor="w")
        tk.Label(
            acct, text=licensing.PRO_TOOLS,
            bg=self.color_white, fg=self.color_navy, font=("Arial", 9),
            anchor="w", justify="left", wraplength=540,
        ).pack(anchor="w", pady=(2, 8))

        self._license_key_var = tk.StringVar()
        self._create_btn(
            acct, "Activate / check license", self.color_lime, self.color_navy,
            lambda: open_license_dialog(self),
        ).pack(fill="x", pady=(4, 2))
        self._create_btn(
            acct, "Purchase Monthly", self.color_lime, self.color_navy, self._open_buy_monthly,
        ).pack(fill="x", pady=(8, 2))
        self._create_btn(
            acct, "Purchase Yearly", self.color_lime, self.color_navy, self._open_buy_yearly,
        ).pack(fill="x", pady=(2, 0))

        if focus_license:
            win.after(50, lambda: open_license_dialog(self))

        tf = ttk.LabelFrame(pref_body, text="Application Theme", padding=10)
        tf.pack(fill="x", padx=10, pady=10)
        theme_combo = ttk.Combobox(tf, values=list(self.themes.keys()), textvariable=self.current_theme_var, state="readonly", width=30)
        theme_combo.pack(anchor="w")
        
        def apply_and_save_theme(e):
            self.save_settings()
            self.change_theme()
            win.destroy()
        theme_combo.bind("<<ComboboxSelected>>", apply_and_save_theme)

        def handle_unit_change():
            old = getattr(self, "_vdp_form_unit", self.global_unit_var.get())
            new = self.global_unit_var.get()
            self._convert_vdp_lengths(old, new)
            self._vdp_form_unit = new
            self._refresh_vdp_unit_labels()
            self._refresh_page_geometry_summary()
            self.save_settings()
            self.render_live_preview()
            if hasattr(self, "vdp_canvas"):
                self.draw_vdp_layout_fields()

        uf = ttk.LabelFrame(pref_body, text="Global Unit of Measurement", padding=10)
        uf.pack(fill="x", padx=10, pady=5)
        ttk.Radiobutton(uf, text="Inches (in)", variable=self.global_unit_var, value="inches", command=handle_unit_change).pack(anchor="w", pady=2)
        ttk.Radiobutton(uf, text="Millimeters (mm)", variable=self.global_unit_var, value="mm", command=handle_unit_change).pack(anchor="w", pady=2)
        ttk.Radiobutton(uf, text="Points (pt)", variable=self.global_unit_var, value="points", command=handle_unit_change).pack(anchor="w", pady=2)
        tk.Label(uf, text="* This unit will instantly apply to all functions across the software.", font=("Arial", 8, "italic"), fg=self.color_steel, bg=self.color_white).pack(anchor="w", pady=(10,0))

        updates = ttk.LabelFrame(pref_body, text="Updates", padding=10)
        updates.pack(fill="x", padx=10, pady=5)
        self._create_btn(
            updates, "Check for Hot-Fixes", self.color_steel, self.color_white,
            lambda: self.check_for_hotfixes(win),
        ).pack(fill="x")
        tk.Label(
            updates, textvariable=self.hotfix_status_var,
            bg=self.color_white, fg=self.color_navy, font=("Arial", 9),
            anchor="w", justify="left", wraplength=540,
        ).pack(anchor="w", pady=(6, 0))
        pref_canvas._rsp_bind_wheel(pref_body)

        size_frame = ttk.Frame(notebook)
        notebook.add(size_frame, text="Custom Page Sizes")

        list_f = tk.Frame(size_frame, bg=self.color_white)
        list_f.pack(fill="both", expand=True, padx=10, pady=10)
        size_listbox = tk.Listbox(list_f, bg=self.color_pale, fg=self.color_navy, selectbackground=self.color_steel, relief="flat")
        size_listbox.pack(side="left", fill="both", expand=True)

        add_f = ttk.LabelFrame(size_frame, text="Add / Edit Preset", padding=10)
        add_f.pack(fill="x", padx=10, pady=10)
        tk.Label(
            add_f,
            text="Enter width × height for portrait (short side × long side). Landscape is applied per tool with the Landscape checkbox.\nUse a period or a comma as the decimal (for example 8.5 or 8,5). Do not type thousand separators.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"), justify="left", wraplength=540,
        ).pack(anchor="w", pady=(0, 8))
        r1 = tk.Frame(add_f, bg=self.color_white); r1.pack(fill="x", pady=2)
        tk.Label(r1, text="Name:", bg=self.color_white, fg=self.color_navy, width=6, anchor="w").pack(side="left");
        name_var = tk.StringVar()
        tk.Entry(r1, textvariable=name_var, bg=self.color_pale).pack(side="left", fill="x", expand=True, padx=5)

        r2 = tk.Frame(add_f, bg=self.color_white); r2.pack(fill="x", pady=5)
        tk.Label(r2, text="Width:", bg=self.color_white, fg=self.color_navy, width=6, anchor="w").pack(side="left");
        w_var = tk.StringVar()
        tk.Entry(r2, textvariable=w_var, width=8, bg=self.color_pale).pack(side="left", padx=5)
        tk.Label(r2, text="Height:", bg=self.color_white, fg=self.color_navy).pack(side="left");
        h_var = tk.StringVar()
        tk.Entry(r2, textvariable=h_var, width=8, bg=self.color_pale).pack(side="left", padx=5)
        tk.Label(r2, text="*(Uses Global Unit)", bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic")).pack(side="left", padx=10)

        def ordered_names():
            names = [n for n in self.custom_size_order if n in self.custom_sizes]
            for n in self.custom_sizes:
                if n not in names:
                    names.append(n)
            self.custom_size_order = names
            return names

        def refresh_listbox():
            size_listbox.delete(0, tk.END)
            for k in ordered_names():
                v = self.custom_sizes[k]
                size_listbox.insert(tk.END, f"{k} ({v.get('w', '')} x {v.get('h', '')})")

        refresh_listbox()

        def selected_name():
            sel = size_listbox.curselection()
            if not sel:
                return None
            return size_listbox.get(sel[0]).split(" (")[0]

        def save_custom_size():
            nm = name_var.get().strip()
            w = w_var.get().strip()
            h = h_var.get().strip()
            if not (nm and w and h):
                messagebox.showwarning("Missing Size", "Enter a name, width, and height.", parent=win)
                return
            if self.parse_locale_number(w) is None or self.parse_locale_number(h) is None:
                messagebox.showwarning("Invalid Number", "Width and height must be numbers (comma or period is OK for decimals).", parent=win)
                return
            pt_w = self.to_points(w)
            pt_h = self.to_points(h)
            old = selected_name()
            if old and old != nm and old in self.custom_sizes:
                del self.custom_sizes[old]
                self.custom_size_order = [nm if x == old else x for x in self.custom_size_order]
            self.custom_sizes[nm] = {"w_pt": pt_w, "h_pt": pt_h, "w": w, "h": h}
            if nm not in self.custom_size_order:
                self.custom_size_order.append(nm)
            self.save_settings()
            refresh_listbox()
            self.update_preset_dropdowns()

        def load_edit_size():
            nm = selected_name()
            if not nm or nm not in self.custom_sizes:
                return
            v = self.custom_sizes[nm]
            name_var.set(nm)
            w_var.set(str(v.get("w", "")))
            h_var.set(str(v.get("h", "")))

        def del_custom_size():
            nm = selected_name()
            if nm and nm in self.custom_sizes:
                del self.custom_sizes[nm]
                self.custom_size_order = [x for x in self.custom_size_order if x != nm]
                self.save_settings()
                refresh_listbox()
                self.update_preset_dropdowns()

        def move_custom_size(delta):
            nm = selected_name()
            names = ordered_names()
            if not nm or nm not in names:
                return
            i = names.index(nm)
            j = i + delta
            if j < 0 or j >= len(names):
                return
            names[i], names[j] = names[j], names[i]
            self.custom_size_order = names
            self.save_settings()
            refresh_listbox()
            self.update_preset_dropdowns()
            size_listbox.selection_set(j)

        btn_col = tk.Frame(list_f, bg=self.color_white)
        btn_col.pack(side="right", fill="y", padx=(5, 0))
        self._create_btn(btn_col, "✎ Edit", self.color_mint, self.color_navy, load_edit_size, compact=True).pack(fill="x", pady=2)
        self._create_btn(btn_col, "▲ Up", self.color_steel, self.color_white, lambda: move_custom_size(-1), compact=True).pack(fill="x", pady=2)
        self._create_btn(btn_col, "▼ Down", self.color_steel, self.color_white, lambda: move_custom_size(1), compact=True).pack(fill="x", pady=2)
        self._create_btn(btn_col, "❌ Delete", self.color_steel, self.color_white, del_custom_size, compact=True).pack(fill="x", pady=2)
        self._create_btn(add_f, "💾 Save Custom Preset", self.color_lime, self.color_navy, save_custom_size).pack(pady=5, fill="x")

        def _fit_settings():
            try:
                if not win.winfo_exists():
                    return
                pref_canvas.update_idletasks()
                pref_canvas.itemconfigure(pref_canvas._rsp_window_id, width=560)
                win.update_idletasks()
                pref_h = pref_body.winfo_reqheight()
                size_h = size_frame.winfo_reqheight()
                # Notebook tab strip plus the outer padding around the notebook.
                content_h = max(pref_h, size_h) + 56
                self._place_settings_window(win, content_h)
                pref_canvas._rsp_sync_scroll()
            except Exception:
                try:
                    self._place_settings_window(win, 640)
                except Exception:
                    pass

        win.after_idle(_fit_settings)

    def update_preset_dropdowns(self):
        customs = [n for n in self.custom_size_order if n in self.custom_sizes]
        for n in self.custom_sizes:
            if n not in customs:
                customs.append(n)
        if hasattr(self, 'resize_combo'): self.resize_combo['values'] = ["Letter", "Legal", "Tabloid", "A4"] + customs
        if hasattr(self, 'grid_combo'): self.grid_combo['values'] = ["12x18", "13x19", "Letter", "Tabloid"] + customs
        if hasattr(self, 'booklet_combo'): self.booklet_combo['values'] = ["Tabloid (11x17)", "Letter (8.5x11)"] + customs
        if hasattr(self, 'fold_combo'): self.fold_combo['values'] = ["Letter", "Legal", "Tabloid", "A4", "Use current PDF"] + customs

    def add_bg_task(self, task_name):
        self.background_tasks.append(task_name)
        self.refresh_dashboard()
        
    def remove_bg_task(self, task_name):
        if task_name in self.background_tasks:
            self.background_tasks.remove(task_name)
        self.refresh_dashboard()
        
    def refresh_dashboard(self):
        if not self.background_tasks:
            self.task_display_var.set("Idle - Ready for tasks.")
        else:
            self.task_display_var.set(" | ".join(self.background_tasks))

    def setup_styles(self):
        self.style = ttk.Style(); self.style.theme_use('clam')
        self.style.configure("TLabelframe", background=self.color_white, bordercolor=self.color_steel, borderwidth=1)
        self.style.configure("TLabelframe.Label", background=self.color_white, foreground=self.color_navy, font=("Arial", 11, "bold"))
        self.style.configure("TFrame", background=self.color_white)
        self.style.configure("TCheckbutton", background=self.color_white, foreground=self.color_navy, font=("Arial", 9))
        self.style.map("TCheckbutton", background=[("active", self.color_white)])
        self.style.configure("TRadiobutton", background=self.color_white, foreground=self.color_navy, font=("Arial", 9))
        self.style.map("TRadiobutton", background=[("active", self.color_white)])

    def _create_btn(self, parent, text, bg, fg, command, width=None, compact=False, tooltip=None):
        padx, pady = (8, 3) if compact else (15, 8)
        font = ("Arial", 9, "bold") if compact else ("Arial", 10, "bold")
        btn = tk.Button(parent, text=text, bg=bg, fg=fg, activebackground=self.color_navy, activeforeground=self.color_white,
                        relief="flat", borderwidth=0, font=font, padx=padx, pady=pady, cursor="hand2", command=command)
        btn._rsp_bg = bg
        btn._rsp_fg = fg
        if width: btn.config(width=width)
        if tooltip:
            ToolTip(btn, tooltip, self)
        return btn

    def _set_commit_btn_enabled(self, btn, enabled):
        if btn is None:
            return
        if enabled:
            btn.config(
                state="normal",
                bg=getattr(btn, "_rsp_bg", self.color_steel),
                fg=getattr(btn, "_rsp_fg", self.color_white),
                cursor="hand2",
            )
        else:
            btn.config(state="disabled", bg="#c5c5c5", fg="#6a6a6a", cursor="arrow")

    def _register_step_commit_buttons(self, step_type, overwrite_btn, add_btn):
        self._step_commit_buttons.append({"type": step_type, "overwrite": overwrite_btn, "add": add_btn})
        self._sync_step_commit_buttons()

    def _build_step_commit_buttons(self, parent, step_type, add_label):
        wrap = tk.Frame(parent, bg=self.color_white)
        overwrite_btn = self._create_btn(
            wrap, "↻ Overwrite saved step", self.color_mint, self.color_navy,
            lambda: self.overwrite_selected_step(step_type),
            tooltip="Replace the selected stack step with the values on this pane. Enabled when the selected step is this type.",
        )
        overwrite_btn.pack(fill="x", pady=(0, 5))
        add_btn = self._create_btn(
            wrap, add_label, self.color_steel, self.color_white,
            lambda: self.add_step_to_queue(step_type),
        )
        add_btn.pack(fill="x")
        self._register_step_commit_buttons(step_type, overwrite_btn, add_btn)
        return wrap

    def _selected_step(self):
        idx = self.active_history_index
        if idx is None or idx < 0 or idx >= len(self.action_queue):
            return None
        return self.action_queue[idx]

    def _sync_step_commit_buttons(self):
        selected = self._selected_step()
        selected_type = selected.get("type") if selected else None
        pane_type = LIVE_PREVIEW_TABS.get(getattr(self, "current_active_tab", ""), None)
        if getattr(self, "current_active_tab", "") == "VDP":
            pane_type = "VDP Mail Merge"
        elif getattr(self, "current_active_tab", "") == "OCR":
            pane_type = "OCR Extraction"
        elif getattr(self, "current_active_tab", "") == "Unlock":
            pane_type = "Unlock PDF"
        elif getattr(self, "current_active_tab", "") == "JoinSplit":
            mode = getattr(self, "join_split_mode_var", None)
            pane_type = "Split PDFs" if mode is not None and mode.get() == "split" else "Join PDFs"
        for row in getattr(self, "_step_commit_buttons", []):
            matches = bool(selected_type) and row["type"] == selected_type
            pane_is_this = row["type"] == pane_type
            self._set_commit_btn_enabled(row.get("overwrite"), matches and pane_is_this)
            self._set_commit_btn_enabled(row.get("add"), pane_is_this)

    def _add_tab_btn(self, parent, text, key):
        """Create a tool tab button (parent unused; buttons live on tab_btns_host and are reflowed)."""
        btn = tk.Button(
            self.tab_btns_host, text=text, bg=self.color_mint, fg=self.color_navy,
            activebackground=self.color_steel, activeforeground=self.color_white,
            relief="flat", borderwidth=0, font=("Arial", 10, "bold"),
            padx=4, pady=5, cursor="hand2", justify="center",
            # width=1 lets the grid stretch/shrink the button to fill its cell
            width=1,
            command=lambda k=key: self._click_tool_tab(k),
        )
        self.tab_btns[key] = btn
        self._tab_btn_order.append(key)
        btn.bind("<ButtonPress-1>", lambda e, k=key: self._tab_drag_start(k, e), add="+")
        tip = TAB_TOOLTIPS.get(key)
        if tip:
            ToolTip(btn, tip, self)

    def _click_tool_tab(self, key):
        if getattr(self, "_tab_suppress_click", False):
            self._tab_suppress_click = False
            return
        self.select_tab(key)

    def _tab_drag_start(self, key, event):
        self._tab_suppress_click = False
        self._tab_drag = {"key": key, "x": event.x_root, "y": event.y_root, "moved": False}
        self.root.bind_all("<B1-Motion>", self._tab_drag_motion)
        self.root.bind_all("<ButtonRelease-1>", self._tab_drag_release)

    def _tab_key_at(self, x_root, y_root):
        host = getattr(self, "tab_btns_host", None)
        if host is None:
            return None
        x = x_root - host.winfo_rootx()
        y = y_root - host.winfo_rooty()
        for key in self._tab_btn_order:
            btn = self.tab_btns.get(key)
            if btn is None:
                continue
            try:
                if not btn.winfo_ismapped():
                    continue
                bx, by = btn.winfo_x(), btn.winfo_y()
                if bx <= x <= bx + btn.winfo_width() and by <= y <= by + btn.winfo_height():
                    return key
            except Exception:
                continue
        return None

    def _tab_drag_motion(self, event):
        drag = getattr(self, "_tab_drag", None)
        if not drag:
            return
        if abs(event.x_root - drag["x"]) + abs(event.y_root - drag["y"]) < 8:
            return
        if not drag["moved"]:
            drag["moved"] = True
            self._tab_suppress_click = True
            btn = self.tab_btns.get(drag["key"])
            if btn is not None:
                try:
                    btn.config(cursor="fleur")
                except Exception:
                    pass
        target = self._tab_key_at(event.x_root, event.y_root)
        if not target or target == drag["key"]:
            return
        order = self._tab_btn_order
        if drag["key"] not in order or target not in order:
            return
        src = order.index(drag["key"])
        dst = order.index(target)
        order.insert(dst, order.pop(src))
        self._reflow_tab_buttons()

    def _tab_drag_release(self, event):
        drag = getattr(self, "_tab_drag", None)
        self._tab_drag = None
        try:
            self.root.unbind_all("<B1-Motion>")
            self.root.unbind_all("<ButtonRelease-1>")
        except Exception:
            pass
        if not drag:
            return
        btn = self.tab_btns.get(drag["key"])
        if btn is not None:
            try:
                btn.config(cursor="hand2")
            except Exception:
                pass
        if drag["moved"]:
            self.settings["tab_order"] = list(self._tab_btn_order)
            self.save_settings()
            self.root.after_idle(lambda: setattr(self, "_tab_suppress_click", False))
        else:
            self._tab_suppress_click = False

    def _resolve_tab_order(self, default_keys):
        saved = self.settings.get("tab_order") or []
        if not isinstance(saved, list):
            saved = []
        order = []
        known = set(default_keys)
        for key in saved:
            if key in known and key not in order:
                order.append(key)
        for key in default_keys:
            if key not in order:
                order.append(key)
        saved_list = saved if isinstance(saved, list) else []
        if "JoinSplit" in order and "JoinSplit" not in saved_list and "Rotate" in order:
            order.remove("JoinSplit")
            order.insert(order.index("Rotate") + 1, "JoinSplit")
        return order

    def _tab_column_count(self, width, n_buttons):
        """Pick a column count so cells stay usable and every button stays on-screen."""
        width = max(int(width or 0), 1)
        # Prefer fewer rows when there is room; always keep all buttons visible.
        for cols in (7, 5, 4, 3, 2, 1):
            if cols > n_buttons:
                continue
            cell = width / float(cols)
            if cell >= 86 or cols == 1:
                return cols
        return 1

    def _middle_chrome_scale(self, cell_w):
        """Return (font, padx, pady, wraplength) for one tab cell width."""
        cell_w = max(int(cell_w or 0), 1)
        wrap = max(48, cell_w - 10)
        if cell_w < 72:
            return ("Arial", 7, "bold"), 1, 3, wrap
        if cell_w < 96:
            return ("Arial", 8, "bold"), 2, 4, wrap
        if cell_w < 130:
            return ("Arial", 9, "bold"), 3, 5, wrap
        return ("Arial", 10, "bold"), 4, 6, wrap

    def _reflow_tab_buttons(self, event=None):
        """Fill the center width with an even grid of every tool button.

        Equal column weights + sticky stretch remove the ragged gaps. Column count
        drops as the pane narrows so buttons shrink instead of disappearing.
        """
        if getattr(self, "_tab_reflowing", False):
            return
        host = getattr(self, "tab_btns_host", None)
        if host is None or not getattr(self, "tab_btns", None):
            return
        width = host.winfo_width()
        if event is not None and getattr(event, "width", 0):
            width = event.width
        if width < 40:
            return

        keys = [k for k in self._tab_btn_order if k in self.tab_btns]
        n = len(keys)
        if n == 0:
            return
        cols = self._tab_column_count(width, n)
        cell_w = max(width / float(cols), 1.0)
        layout_key = (int(width), cols, tuple(keys))
        if layout_key == getattr(self, "_tab_reflow_key", None):
            sample = self.tab_btns.get(keys[0])
            try:
                if sample is not None and sample.winfo_ismapped():
                    return
            except Exception:
                pass

        self._tab_reflowing = True
        try:
            font, padx, pady, wraplength = self._middle_chrome_scale(cell_w)
            tip = getattr(self, "tab_pro_tip", None)
            if tip is not None:
                tip.config(
                    wraplength=max(120, width - 8),
                    font=("Arial", 8 if width < 340 else 9, "italic"),
                )

            for btn in self.tab_btns.values():
                btn.grid_forget()
                btn.pack_forget()

            # Reset old column weights, then make the active columns share space evenly
            for c in range(16):
                host.grid_columnconfigure(c, weight=0, minsize=0, uniform="")
            for c in range(cols):
                host.grid_columnconfigure(c, weight=1, uniform="rsp_tabs")

            rows = (n + cols - 1) // cols
            for r in range(rows + 2):
                host.grid_rowconfigure(r, weight=0)

            for i, key in enumerate(keys):
                btn = self.tab_btns.get(key)
                if btn is None:
                    continue
                try:
                    if not btn.winfo_exists():
                        continue
                except Exception:
                    continue
                r, c = divmod(i, cols)
                btn.config(font=font, padx=padx, pady=pady, wraplength=wraplength, width=1)
                btn.grid(row=r, column=c, sticky="nsew", padx=1, pady=1)

            self._tab_reflow_key = layout_key
            self._tab_reflow_width = width
            self._update_middle_scrollregion()
        finally:
            self._tab_reflowing = False

    def _update_middle_scrollregion(self, event=None):
        canvas = getattr(self, "_middle_canvas", None)
        if canvas is None:
            return
        try:
            canvas.update_idletasks()
            bbox = canvas.bbox("all")
            if bbox:
                canvas.configure(scrollregion=bbox)
        except Exception:
            pass

    def _on_middle_canvas_configure(self, event):
        canvas = getattr(self, "_middle_canvas", None)
        win = getattr(self, "_middle_window", None)
        if canvas is None or win is None:
            return
        try:
            # Match inner width to canvas; leave height to content so Y-scroll works
            canvas.itemconfigure(win, width=max(event.width, 1))
        except Exception:
            pass
        # Debounce reflow so Configure storms do not thrash the tab bar
        job = getattr(self, "_tab_reflow_job", None)
        if job is not None:
            try:
                self.root.after_cancel(job)
            except Exception:
                pass
        self._tab_reflow_job = self.root.after(30, self._reflow_tab_buttons)

    def _on_middle_mousewheel(self, event):
        canvas = getattr(self, "_middle_canvas", None)
        if canvas is None:
            return
        delta = getattr(event, "delta", 0)
        if delta:
            canvas.yview_scroll(int(-1 * (delta / 120)), "units")
        elif getattr(event, "num", None) == 4:
            canvas.yview_scroll(-1, "units")
        elif getattr(event, "num", None) == 5:
            canvas.yview_scroll(1, "units")

    def _bind_middle_mousewheel(self, widget):
        def _enter(_event=None):
            widget.bind_all("<MouseWheel>", self._on_middle_mousewheel)
            widget.bind_all("<Button-4>", self._on_middle_mousewheel)
            widget.bind_all("<Button-5>", self._on_middle_mousewheel)

        def _leave(_event=None):
            widget.unbind_all("<MouseWheel>")
            widget.unbind_all("<Button-4>")
            widget.unbind_all("<Button-5>")

        widget.bind("<Enter>", _enter, add="+")
        widget.bind("<Leave>", _leave, add="+")

    def select_tab(self, key):
        if self._tool_tab_locked(key):
            open_license_dialog(self)
            return
        self.current_active_tab = key
        try:
            if key not in self.tab_btns or not self.tab_btns[key].winfo_exists():
                return
        except Exception:
            return
        self._refresh_tool_lock_styles()
        for k, tab in self.tabs.items():
            tab.pack_forget()
        # fill-x so tall panes grow the scrollable center instead of clipping
        self.tabs[key].pack(fill="x", expand=False, anchor="nw")
        self._sync_step_commit_buttons()
        self.root.after_idle(self._update_middle_scrollregion)
        if getattr(self, "_loading_form", False):
            return
        if key == "VDP":
            self.root.after(40, self.render_vdp_layout_preview)
        # Skip while the window is being rebuilt: the open document is still
        # set, but the preview canvas from the previous theme is already gone.
        if getattr(self, "preview_doc", None) and self._widget_alive(getattr(self, "preview_canvas", None)):
            self.render_live_preview()

    def _toggle_engine_panel(self):
        self._engine_expanded = not getattr(self, "_engine_expanded", False)
        self._apply_engine_panel()

    def _apply_engine_panel(self):
        detail = getattr(self, "_engine_detail", None)
        toggle = getattr(self, "_engine_toggle_var", None)
        if detail is None or toggle is None:
            return
        if self._engine_expanded:
            toggle.set("▾")
            if not detail.winfo_ismapped():
                detail.pack(fill="x", padx=20, pady=(0, 6))
        else:
            toggle.set("▸")
            if detail.winfo_ismapped():
                detail.pack_forget()

    def _wire_engine_pipelines(self):
        detail = getattr(self, "_engine_detail", None)
        if detail is None:
            return
        for child in detail.winfo_children():
            child.destroy()
        for pipe in getattr(self, "batch_pipelines", []) or []:
            row = tk.Frame(detail, bg=self.color_navy)
            row.pack(fill="x", pady=1)
            tk.Label(
                row, text=f"Pipeline {pipe['index'] + 1}", width=14, anchor="w",
                bg=self.color_navy, fg=self.color_mint, font=("Arial", 9, "bold"),
            ).pack(side="left")
            tk.Label(
                row, textvariable=pipe["status"], anchor="w",
                bg=self.color_navy, fg=self.color_white, font=("Arial", 9),
            ).pack(side="left", fill="x", expand=True)
            pipe["status"].trace_add("write", lambda *_a: self._refresh_engine_summary())
        self._engine_extra_label = tk.Label(
            detail, textvariable=self._engine_extra_var, anchor="w", justify="left",
            bg=self.color_navy, fg=self.color_white, font=("Arial", 9),
        )
        self._refresh_engine_summary()
        self._apply_engine_panel()

    def _refresh_engine_summary(self):
        if not getattr(self, "task_display_var", None):
            return
        quiet = {"", "Idle", "Stopped", "Not configured"}
        bits = []
        for pipe in getattr(self, "batch_pipelines", []) or []:
            status = pipe["status"].get()
            if status not in quiet:
                bits.append(f"Pipeline {pipe['index'] + 1}: {status}")
        extras = []
        for task in getattr(self, "background_tasks", []) or []:
            if task.startswith("🔥 Pipeline") or task.startswith("⚙️ Pipeline"):
                continue
            extras.append(task)
        extra = getattr(self, "_engine_extra_var", None)
        extra_lbl = getattr(self, "_engine_extra_label", None)
        if extra is not None:
            extra.set("  ·  ".join(extras))
        if extra_lbl is not None:
            try:
                if extras and not extra_lbl.winfo_ismapped():
                    extra_lbl.pack(fill="x", pady=(2, 0))
                elif not extras and extra_lbl.winfo_ismapped():
                    extra_lbl.pack_forget()
            except Exception:
                pass
        if bits:
            self.task_display_var.set("  ·  ".join(bits))
        elif extras:
            self.task_display_var.set("  ·  ".join(extras))
        else:
            self.task_display_var.set("Idle - Ready for tasks.")

    def setup_ui(self):
        self._step_commit_buttons = []
        h = tk.Frame(self.main_container, bg=self.color_white, padx=20, pady=15); h.pack(fill="x")
        if os.path.exists(self.logo_path):
            try:
                pil_img = Image.open(self.logo_path)
                ratio = 50.0 / float(pil_img.height); new_w = int(float(pil_img.width) * ratio)
                pil_img = pil_img.resize((new_w, 50)); self.header_logo_img = ImageTk.PhotoImage(pil_img)
                tk.Label(h, image=self.header_logo_img, bg=self.color_white).pack(side="left", padx=(0, 10))
            except Exception: pass
                
        tk.Label(h, text=f"ReadySetPDF  {APP_VERSION}", font=("Arial", 22, "bold"), bg=self.color_white, fg=self.color_navy).pack(side="left")
        
        self._create_btn(h, "🚀 Build & Save Final PDF", self.color_lime, self.color_navy, self.show_export_dialog).pack(side="right")
        self._create_btn(h, "🖼️ Export Proof Images", self.color_mint, self.color_navy, self.export_as_images).pack(side="right", padx=(15, 0))
        self._create_btn(h, "⚙️ Global Settings", self.color_steel, self.color_white, self.open_settings_window).pack(side="right", padx=(15, 0))
        self._create_btn(h, "ℹ️ About", self.color_steel, self.color_white, self.show_about_dialog).pack(side="right", padx=(15, 0))
        
        self._engine_expanded = False
        self.dashboard_frame = tk.Frame(self.main_container, bg=self.color_navy)
        self.dashboard_frame.pack(fill="x")
        engine_head = tk.Frame(self.dashboard_frame, bg=self.color_navy, padx=20, pady=6, cursor="hand2")
        engine_head.pack(fill="x")
        self._engine_toggle_var = tk.StringVar(value="▸")
        toggle_lbl = tk.Label(
            engine_head, textvariable=self._engine_toggle_var,
            bg=self.color_navy, fg=self.color_mint, font=("Arial", 9, "bold"), cursor="hand2",
        )
        toggle_lbl.pack(side="left")
        title_lbl = tk.Label(
            engine_head, text="⚡ Background Engine:",
            bg=self.color_navy, fg=self.color_mint, font=("Arial", 9, "bold"), cursor="hand2",
        )
        title_lbl.pack(side="left", padx=(6, 0))
        self.task_display_var = tk.StringVar(value="Idle - Ready for tasks.")
        summary_lbl = tk.Label(
            engine_head, textvariable=self.task_display_var,
            bg=self.color_navy, fg=self.color_white, font=("Arial", 9), cursor="hand2",
        )
        summary_lbl.pack(side="left", padx=10)
        for widget in (engine_head, toggle_lbl, title_lbl, summary_lbl):
            widget.bind("<Button-1>", lambda _e: self._toggle_engine_panel())
        self._engine_detail = tk.Frame(self.dashboard_frame, bg=self.color_navy, padx=28, pady=2)
        self._engine_extra_var = tk.StringVar(value="")

        footer = tk.Frame(self.main_container, bg=self.color_white, padx=10, pady=5); footer.pack(fill="x", side="bottom")
        tk.Label(footer, text="System Ready.", fg=self.color_steel, bg=self.color_white, font=("Arial", 10, "bold")).pack(side="left")
        btn_feedback = tk.Button(footer, text="🐞 Report Bug / Feedback", bg=self.color_white, fg=self.color_steel, relief="flat", bd=0, font=("Arial", 9, "underline", "bold"), cursor="hand2", activebackground=self.color_white, activeforeground=self.color_navy, command=self.open_feedback_form)
        btn_feedback.pack(side="left", padx=(10, 0))
        self.footer_status_var = tk.StringVar(value=f"Rev {APP_VERSION} | {licensing.footer_text(self.license_state)}")
        tk.Label(footer, textvariable=self.footer_status_var, fg=self.color_steel, bg=self.color_white, font=("Arial", 9, "italic")).pack(side="right", padx=10)
        
        paned = ttk.PanedWindow(self.main_container, orient=tk.HORIZONTAL); paned.pack(fill="both", expand=True, padx=15, pady=10)
        l = ttk.PanedWindow(paned, orient=tk.VERTICAL)
        self._side_paned = l
        self._assets_float = None
        self._steps_float = None
        self._saved_side_sash = None
        self._saved_left_sash = None

        assets_hdr, self._assets_pop_btn = self._side_pane_labelwidget(
            "1. Assets Manager", "assets",
            "Pop the Assets Manager out into its own window.",
        )
        f = ttk.LabelFrame(l, labelwidget=assets_hdr)
        self._assets_home = f
        self._assets_dock_strip = tk.Frame(f, bg=self.color_white)
        self._create_btn(
            self._assets_dock_strip, "Assets\nDock", self.color_mint, self.color_navy,
            lambda: self._dock_side_panel("assets"), compact=True,
            tooltip="Put the Assets Manager back in the main window.",
        ).pack(fill="both", expand=True, padx=2, pady=4)
        self._assets_body = tk.Frame(self.root, bg=self.color_white)
        self._assets_body.pack(in_=f, fill="both", expand=True)
        self._mount_assets_panel(self._assets_body)
        self._register_file_drop(self.root)
        l.add(f, weight=1)

        steps_hdr, self._steps_pop_btn = self._side_pane_labelwidget(
            "2. Applied Steps Stack", "steps",
            "Pop the Applied Steps stack out into its own window.",
        )
        q = ttk.LabelFrame(l, labelwidget=steps_hdr)
        self._steps_home = q
        self._steps_dock_strip = tk.Frame(q, bg=self.color_white)
        self._create_btn(
            self._steps_dock_strip, "Steps\nDock", self.color_mint, self.color_navy,
            lambda: self._dock_side_panel("steps"), compact=True,
            tooltip="Put the Applied Steps stack back in the main window.",
        ).pack(fill="both", expand=True, padx=2, pady=4)
        self._steps_body = tk.Frame(self.root, bg=self.color_white)
        self._steps_body.pack(in_=q, fill="both", expand=True)
        self._mount_steps_panel(self._steps_body)
        l.add(q, weight=1); paned.add(l, weight=1)

        self.middle_pane = tk.Frame(paned, bg=self.color_white)
        paned.add(self.middle_pane, weight=1)

        # Scrollable center: tool tabs + pane body stay reachable when side panels squeeze the middle
        self._middle_canvas = tk.Canvas(self.middle_pane, bg=self.color_white, highlightthickness=0, bd=0)
        self._middle_scroll_y = ttk.Scrollbar(self.middle_pane, orient="vertical", command=self._middle_canvas.yview)
        self._middle_scroll_x = ttk.Scrollbar(self.middle_pane, orient="horizontal", command=self._middle_canvas.xview)
        self._middle_canvas.configure(
            yscrollcommand=self._middle_scroll_y.set,
            xscrollcommand=self._middle_scroll_x.set,
        )
        self._middle_scroll_y.pack(side="right", fill="y")
        self._middle_scroll_x.pack(side="bottom", fill="x")
        self._middle_canvas.pack(side="left", fill="both", expand=True)

        self._middle_inner = tk.Frame(self._middle_canvas, bg=self.color_white)
        self._middle_window = self._middle_canvas.create_window((0, 0), window=self._middle_inner, anchor="nw")
        self._middle_inner.bind("<Configure>", self._update_middle_scrollregion)
        self._middle_canvas.bind("<Configure>", self._on_middle_canvas_configure)
        self._bind_middle_mousewheel(self._middle_canvas)
        self._bind_middle_mousewheel(self._middle_inner)

        self.tab_nav_frame = tk.Frame(self._middle_inner, bg=self.color_white)
        self.tab_nav_frame.pack(fill="x", padx=4, pady=(4, 0))
        self.tab_pro_tip = tk.Label(
            self.tab_nav_frame,
            text="* Pro tools. Drag a button to rearrange.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 9, "italic"),
            anchor="w", justify="left",
        )
        self.tab_pro_tip.pack(anchor="w", fill="x", pady=(0, 5))

        self.tab_btns_host = tk.Frame(self.tab_nav_frame, bg=self.color_white)
        self.tab_btns_host.pack(fill="x", pady=(0, 5))

        def _on_tab_host_configure(event=None):
            job = getattr(self, "_tab_reflow_job", None)
            if job is not None:
                try:
                    self.root.after_cancel(job)
                except Exception:
                    pass
            self._tab_reflow_job = self.root.after(30, self._reflow_tab_buttons)

        self.tab_btns_host.bind("<Configure>", _on_tab_host_configure)

        self.tab_content_frame = tk.Frame(
            self._middle_inner, bg=self.color_white,
            highlightbackground=self.color_steel, highlightthickness=1,
        )
        self.tab_content_frame.pack(fill="x", expand=False, padx=4, pady=(0, 4))
        self.tab_content_frame.bind("<Configure>", self._update_middle_scrollregion)

        self.tabs = {}
        self.tab_btns = {}
        self._tab_btn_order = []
        self._tab_reflowing = False
        self._tab_reflow_width = -1
        self._tab_reflow_key = None
        self._tab_reflow_job = None
        self.build_resize_tab(); self.build_crop_tab(); self.build_grid_tab()
        self.build_booklet_tab(); self.build_cutter_tab(); self.build_rotate_tab(); self.build_join_split_tab(); self.build_vdp_tab()
        self.build_color_tab(); self.build_preflight_tab(); self.build_batch_tab(); self.build_unlock_tab()
        self.build_ocr_tab(); self.build_folds_tab()

        # Free tools first so they fill the top row; Pro tools follow.
        labels = {key: text for text, key in TAB_BUTTONS}
        default_keys = [key for _text, key in TAB_BUTTONS]
        for key in self._resolve_tab_order(default_keys):
            self._add_tab_btn(None, labels[key], key)

        self.update_preset_dropdowns()
        self.select_tab("Resize")
        self.root.after_idle(self._reflow_tab_buttons)

        self._main_paned = paned
        try:
            paned.pane(l, minsize=160)
            paned.pane(self.middle_pane, minsize=200)
        except Exception:
            pass

        # weight 1 (not 2) so the monitor does not claim half the window on open
        r = ttk.LabelFrame(paned, text=" 4. Real-Time Monitor "); paned.add(r, weight=1)
        self._preview_home = r
        try:
            paned.pane(r, minsize=180)
        except Exception:
            pass
        self.root.after(150, self._set_initial_preview_width)
        self.root.after(220, self._ensure_side_pane_space)

        # Slim stand-in shown only while the monitor is in a floating window
        self._monitor_dock_strip = tk.Frame(r, bg=self.color_white)
        self._create_btn(
            self._monitor_dock_strip, "◀\nDock", self.color_mint, self.color_navy, self._dock_preview, compact=True,
            tooltip="Put the Real-Time Monitor back in the main window.",
        ).pack(fill="both", expand=True, padx=2, pady=6)

        # Whole monitor (controls + preview) is parented on the root so it can live in the pane or a Toplevel
        self._monitor_body = tk.Frame(self.root, bg=self.color_white)
        self._monitor_body.pack(in_=r, fill="both", expand=True)
        self._preview_float = None

        self._build_monitor_chrome(self._monitor_body, corner="pop").pack(fill="x", padx=4, pady=(2, 0))

        self.preview_container = tk.Frame(self._monitor_body, bg=self.color_navy, bd=0)
        self.preview_container.pack(fill="both", expand=True, padx=5, pady=5)
        self.preview_container.grid_rowconfigure(0, weight=1); self.preview_container.grid_columnconfigure(0, weight=1)
        self.preview_canvas = tk.Canvas(self.preview_container, bg=self.color_navy, highlightthickness=0); self.preview_canvas.grid(row=0, column=0, sticky="nsew")
        self.v_scroll = ttk.Scrollbar(self.preview_container, orient="vertical", command=self.preview_canvas.yview); self.v_scroll.grid(row=0, column=1, sticky="ns")
        self.h_scroll = ttk.Scrollbar(self.preview_container, orient="horizontal", command=self.preview_canvas.xview); self.h_scroll.grid(row=1, column=0, sticky="ew")
        self.preview_canvas.configure(yscrollcommand=self.v_scroll.set, xscrollcommand=self.h_scroll.set)

        self._dock_preview_canvas = self.preview_canvas
        self._bind_preview_canvas(self.preview_canvas)

    def _build_monitor_chrome(self, parent, corner="pop"):
        """File, page, and preview controls that wrap instead of clipping."""
        host = tk.Frame(parent, bg=self.color_white, height=40)
        host.pack_propagate(False)
        groups = []

        def cluster():
            frame = tk.Frame(host, bg=self.color_white)
            groups.append(frame)
            return frame

        file_g = cluster()
        self.btn_prev_file = self._create_btn(file_g, "⏪ File", self.color_steel, self.color_white, lambda: self.navigate_file(-1), compact=True)
        self.btn_prev_file.pack(side="left")
        self.preview_file_label = tk.Label(file_g, text="File: 0 / 0", font=("Arial", 11, "bold"), bg=self.color_white, fg=self.color_navy)
        self.preview_file_label.pack(side="left", padx=4)
        self.btn_next_file = self._create_btn(file_g, "File ⏩", self.color_steel, self.color_white, lambda: self.navigate_file(1), compact=True)
        self.btn_next_file.pack(side="left")

        page_g = cluster()
        self._create_btn(page_g, "◀ Page", self.color_steel, self.color_white, lambda: self.navigate_preview(-1), compact=True).pack(side="left")
        self.preview_page_label = tk.Label(page_g, text="Page: 0 / 0", font=("Arial", 11, "bold"), bg=self.color_white, fg=self.color_navy)
        self.preview_page_label.pack(side="left", padx=4)
        self._create_btn(page_g, "Page ▶", self.color_steel, self.color_white, lambda: self.navigate_preview(1), compact=True).pack(side="left")

        status_g = cluster()
        self.history_status_label = tk.Label(
            status_g, text="Viewing: Original Baseline", fg=self.color_steel, bg=self.color_white,
            font=("Arial", 10, "bold"), anchor="w", justify="left",
        )
        self.history_status_label.pack(side="left")

        merge_g = cluster()
        cb_merge = ttk.Checkbutton(merge_g, text="Preview Merged", variable=self.preview_merge_var, command=self.render_live_preview)
        cb_merge.pack(side="left")
        ToolTip(cb_merge, "Toggle between previewing individual files or all files merged together.", self)

        rulers_g = cluster()
        self.measure_toggle = ttk.Checkbutton(rulers_g, text="📏 Show Rulers", variable=self.show_measurements_var, command=self.render_live_preview)
        self.measure_toggle.pack(side="left")
        ToolTip(self.measure_toggle, "Tick rulers along the page. Hover the preview for distance from the left and top edges.", self)

        zoom_g = cluster()
        tk.Label(zoom_g, text="🔎 Zoom:", font=("Arial", 10, "bold"), bg=self.color_white, fg=self.color_navy).pack(side="left", padx=(0, 4))
        self.zoom_combo = ttk.Combobox(
            zoom_g,
            values=["1.0x (Fit Width)", "Fit Height", "1.5x Zoom", "2.0x High Zoom", "3.0x Max Detail"],
            textvariable=self.preview_zoom_var, width=18, state="readonly", font=("Arial", 9),
        )
        self.zoom_combo.pack(side="left")
        self.zoom_combo.bind("<<ComboboxSelected>>", lambda e: self.render_live_preview())

        if corner == "dock":
            corner_btn = self._create_btn(host, "Dock", self.color_mint, self.color_navy, self._dock_preview, compact=True)
        else:
            corner_btn = tk.Button(
                host, text="⧉", command=self.toggle_preview_float,
                bg=self.color_mint, fg=self.color_navy,
                activebackground=self.color_navy, activeforeground=self.color_white,
                relief="flat", borderwidth=0, font=("Arial", 12, "bold"),
                padx=6, pady=1, cursor="hand2",
            )
            self._preview_pop_btn = corner_btn
            ToolTip(corner_btn, "Pop the Real-Time Monitor out into its own window.", self)
        corner_btn.place(in_=host, relx=1.0, x=-4, y=2, anchor="ne")

        host._groups = groups
        host._corner = corner_btn
        host._status_label = self.history_status_label
        host._flow_key = None
        host._reflowing = False
        if getattr(self, "_monitor_chrome_hosts", None) is None:
            self._monitor_chrome_hosts = []
        self._monitor_chrome_hosts.append(host)
        host.bind("<Configure>", lambda _event, widget=host: self._layout_monitor_chrome(widget))
        self.root.after_idle(lambda widget=host: self._layout_monitor_chrome(widget))
        return host

    def _schedule_monitor_chrome_reflow(self):
        if getattr(self, "_monitor_reflow_pending", False):
            return
        self._monitor_reflow_pending = True
        try:
            self.root.after_idle(self._flush_monitor_chrome_reflow)
        except Exception:
            self._monitor_reflow_pending = False

    def _flush_monitor_chrome_reflow(self):
        self._monitor_reflow_pending = False
        alive = []
        for host in getattr(self, "_monitor_chrome_hosts", []):
            try:
                if not host.winfo_exists():
                    continue
            except Exception:
                continue
            alive.append(host)
            host._flow_key = None
            self._layout_monitor_chrome(host)
        self._monitor_chrome_hosts = alive

    def _layout_monitor_chrome(self, host):
        """Place each control group on the next line when the row runs out of room."""
        if host is None or getattr(host, "_reflowing", False):
            return
        try:
            if not host.winfo_exists():
                return
        except Exception:
            return
        width = host.winfo_width()
        if width < 40:
            return
        groups = [g for g in getattr(host, "_groups", []) if self._widget_alive(g)]
        if not groups:
            return
        status = getattr(host, "_status_label", None)
        if self._widget_alive(status):
            try:
                status.config(wraplength=max(140, width - 16))
            except Exception:
                pass
        sizes = []
        for group in groups:
            try:
                sizes.append((max(group.winfo_reqwidth(), 1), max(group.winfo_reqheight(), 1)))
            except Exception:
                sizes.append((1, 1))
        key = (int(width), tuple(sizes))
        if key == getattr(host, "_flow_key", None):
            return

        corner = getattr(host, "_corner", None)
        corner_w = 0
        corner_h = 0
        if self._widget_alive(corner):
            try:
                corner_w = corner.winfo_reqwidth() + 10
                corner_h = corner.winfo_reqheight() + 4
                corner.lift()
            except Exception:
                corner_w = 0

        gap_x, gap_y = 10, 4
        rows = []
        current = []
        used = 0
        first = True
        for group, (gw, gh) in zip(groups, sizes):
            limit = max(48, width - (corner_w if first else 0) - 8)
            extra = gw if not current else gap_x + gw
            if current and used + extra > limit:
                rows.append(current)
                current = []
                used = 0
                first = False
                extra = gw
            current.append((group, gw, gh))
            used += extra
        if current:
            rows.append(current)

        host._reflowing = True
        try:
            y = 2
            for row in rows:
                row_h = max(item[2] for item in row)
                x = 4
                for group, gw, gh in row:
                    group.place(in_=host, x=x, y=y + max(0, (row_h - gh) // 2))
                    x += gw + gap_x
                y += row_h + gap_y
            needed = max(y + 2, corner_h, 32)
            if int(host.cget("height")) != int(needed):
                host.configure(height=needed)
            host._flow_key = key
        finally:
            host._reflowing = False

    def _widget_alive(self, widget):
        if widget is None:
            return False
        try:
            return bool(widget.winfo_exists())
        except Exception:
            return False

    def _mount_assets_panel(self, parent):
        # Pack fixed controls from the bottom first so Add/Clear and Page Geometry
        # stay visible when the side pane is short (same pattern as the steps panel).
        self._build_page_geometry_panel(parent)
        btn_row_f = ttk.Frame(parent)
        btn_row_f.pack(side="bottom", fill="x", pady=(0, 5), padx=5)
        self._create_btn(btn_row_f, "➕ Add Files", self.color_steel, self.color_white, self.load_pdfs).pack(side="left", fill="x", expand=True, padx=(0, 2))
        self._create_btn(btn_row_f, "❌ Clear", self.color_mint, self.color_navy, self.clear_files).pack(side="left", fill="x", expand=True, padx=(2, 0))
        drop_zone = tk.Frame(parent, bg=self.color_pale, highlightthickness=0)
        drop_zone.pack(fill="both", expand=True, padx=5, pady=5)
        self.file_list = tk.Listbox(
            drop_zone, height=4, bg=self.color_pale, fg=self.color_navy,
            selectbackground=self.color_steel, relief="flat", highlightthickness=1,
        )
        self.file_list.pack(fill="both", expand=True)
        self._register_file_drop(drop_zone)
        self._register_file_drop(self.file_list)
        self.file_list.bind("<<ListboxSelect>>", self._on_asset_file_selected)

    def _mount_steps_panel(self, parent):
        btn_row_q3 = ttk.Frame(parent)
        btn_row_q3.pack(side="bottom", fill="x", pady=(0, 5), padx=5)
        self._create_btn(btn_row_q3, "💾 Save Recipe", self.color_lime, self.color_navy, self.save_recipe).pack(side="left", fill="x", expand=True, padx=(0, 2))
        self._create_btn(btn_row_q3, "📂 Load Recipe", self.color_lime, self.color_navy, self.load_recipe).pack(side="left", fill="x", expand=True, padx=(2, 0))
        btn_row_q2 = ttk.Frame(parent)
        btn_row_q2.pack(side="bottom", fill="x", pady=(0, 2), padx=5)
        self._create_btn(btn_row_q2, "🗑️ Remove", self.color_steel, self.color_white, self.remove_queue_step).pack(side="left", fill="x", expand=True, padx=(0, 2))
        self._create_btn(btn_row_q2, "🔄 Reset", self.color_mint, self.color_navy, self.clear_queue).pack(side="left", fill="x", expand=True, padx=(2, 0))
        btn_row_q1 = ttk.Frame(parent)
        btn_row_q1.pack(side="bottom", fill="x", pady=(0, 2), padx=5)
        self._create_btn(btn_row_q1, "🔼 Move Up", self.color_steel, self.color_white, lambda: self.move_queue_step(-1)).pack(side="left", fill="x", expand=True, padx=(0, 2))
        self._create_btn(btn_row_q1, "🔽 Move Down", self.color_steel, self.color_white, lambda: self.move_queue_step(1)).pack(side="left", fill="x", expand=True, padx=(2, 0))
        self.queue_box = tk.Listbox(
            parent, height=4, bg=self.color_pale, fg=self.color_navy,
            selectbackground=self.color_steel, relief="flat", highlightthickness=1, font=("Arial", 10, "bold"),
        )
        self.queue_box.pack(fill="both", expand=True, padx=5, pady=5)
        self.queue_box.bind("<<ListboxSelect>>", self.handle_history_selection)
        self._register_file_drop(self.queue_box)

    def _sync_file_list_widget(self):
        box = getattr(self, "file_list", None)
        if not self._widget_alive(box):
            return
        box.delete(0, tk.END)
        for path in self.files:
            box.insert(tk.END, os.path.basename(path))

    def _sync_queue_widget(self):
        box = getattr(self, "queue_box", None)
        if not self._widget_alive(box):
            return
        box.delete(0, tk.END)
        for step in self.action_queue:
            box.insert(tk.END, self._get_step_display_text(step))
        if self.active_history_index >= 0:
            try:
                box.selection_set(self.active_history_index)
            except Exception:
                pass

    def _side_pane_labelwidget(self, title, which, tip):
        """Title + popout control for a LabelFrame border (keeps the button out of the pane body)."""
        hdr = tk.Frame(self.root, bg=self.color_white)
        tk.Label(
            hdr, text=f" {title} ", bg=self.color_white, fg=self.color_navy,
            font=("Arial", 9, "bold"),
        ).pack(side="left")
        btn = tk.Button(
            hdr, text="⧉", command=lambda: self._toggle_side_panel(which),
            bg=self.color_mint, fg=self.color_navy,
            activebackground=self.color_navy, activeforeground=self.color_white,
            relief="flat", borderwidth=0, font=("Arial", 11, "bold"),
            padx=5, pady=0, cursor="hand2",
        )
        btn.pack(side="left", padx=(2, 2))
        ToolTip(btn, tip, self)
        return hdr, btn

    def _panel_floating(self, which):
        win = getattr(self, f"_{which}_float", None)
        if win is None:
            return False
        try:
            return bool(win.winfo_exists())
        except Exception:
            return False

    def _toggle_side_panel(self, which):
        if self._panel_floating(which):
            self._dock_side_panel(which)
        else:
            self._pop_side_panel(which)

    def _pop_side_panel(self, which):
        """Open a new window. Tk cannot move the existing frame into it, so the controls are built again."""
        body = getattr(self, f"_{which}_body", None)
        home = getattr(self, f"_{which}_home", None)
        if body is None or home is None or self._panel_floating(which):
            return
        title = "Assets Manager" if which == "assets" else "Applied Steps"
        win = tk.Toplevel(self.root)
        win.title(f"ReadySetPDF — {title}")
        win.geometry("460x640" if which == "assets" else "460x560")
        win.minsize(300, 280)
        win.configure(bg=self.color_white)
        win.protocol("WM_DELETE_WINDOW", lambda: self._dock_side_panel(which))
        setattr(self, f"_{which}_float", win)
        if which == "assets":
            self._dock_assets_refs = {
                "file": self.file_list,
                "geo_btn": getattr(self, "page_geo_toggle_btn", None),
                "geo_body": getattr(self, "page_geo_body", None),
                "geo_wrap": getattr(self, "page_geo_wrap", None),
            }
            self._mount_assets_panel(win)
            self._sync_file_list_widget()
        else:
            self._dock_steps_refs = {
                "queue": self.queue_box,
            }
            self._mount_steps_panel(win)
            self._sync_queue_widget()
        try:
            body.pack_forget()
        except Exception:
            pass
        strip = getattr(self, f"_{which}_dock_strip", None)
        if strip is not None:
            strip.pack(fill="both", expand=True)
        btn = getattr(self, f"_{which}_pop_btn", None)
        if btn is not None:
            try:
                btn.config(text="Dock")
            except Exception:
                pass
        self._fit_side_panes()
        self.root.after(80, self._size_float_to_content, which)
        win.lift()

    def _dock_side_panel(self, which):
        win = getattr(self, f"_{which}_float", None)
        setattr(self, f"_{which}_float", None)
        body = getattr(self, f"_{which}_body", None)
        home = getattr(self, f"_{which}_home", None)
        if which == "assets":
            refs = getattr(self, "_dock_assets_refs", None) or {}
            if self._widget_alive(refs.get("file")):
                self.file_list = refs["file"]
            if refs.get("geo_btn") is not None:
                self.page_geo_toggle_btn = refs["geo_btn"]
            if refs.get("geo_body") is not None:
                self.page_geo_body = refs["geo_body"]
            if refs.get("geo_wrap") is not None:
                self.page_geo_wrap = refs["geo_wrap"]
            self._dock_assets_refs = None
            self._sync_file_list_widget()
        elif which == "steps":
            refs = getattr(self, "_dock_steps_refs", None) or {}
            if self._widget_alive(refs.get("queue")):
                self.queue_box = refs["queue"]
            self._dock_steps_refs = None
            self._sync_queue_widget()
        if win is not None:
            try:
                if win.winfo_exists():
                    win.destroy()
            except Exception:
                pass
        strip = getattr(self, f"_{which}_dock_strip", None)
        if strip is not None:
            try:
                strip.pack_forget()
            except Exception:
                pass
        if body is not None and home is not None:
            try:
                if body.winfo_exists() and home.winfo_exists():
                    body.pack(in_=home, fill="both", expand=True)
            except Exception:
                pass
        btn = getattr(self, f"_{which}_pop_btn", None)
        if btn is not None:
            try:
                if btn.winfo_exists():
                    btn.config(text="⧉")
            except Exception:
                pass
        self._fit_side_panes()

    def _fit_side_panes(self):
        """Leave a dock strip where a popped panel used to sit."""
        side = getattr(self, "_side_paned", None)
        main = getattr(self, "_main_paned", None)
        assets_home = getattr(self, "_assets_home", None)
        steps_home = getattr(self, "_steps_home", None)
        if side is None or main is None or assets_home is None or steps_home is None:
            return
        assets_out = self._panel_floating("assets")
        steps_out = self._panel_floating("steps")
        try:
            if assets_out and steps_out:
                if getattr(self, "_saved_left_sash", None) is None:
                    self._saved_left_sash = main.sashpos(0)
                main.pane(side, minsize=48)
                total = main.winfo_width()
                if total > 200:
                    main.sashpos(0, 56)
                return
            if getattr(self, "_saved_left_sash", None) is not None:
                main.pane(side, minsize=160)
                main.sashpos(0, self._saved_left_sash)
                self._saved_left_sash = None
            total = side.winfo_height()
            if total < 80:
                return
            if assets_out:
                if getattr(self, "_saved_side_sash", None) is None:
                    self._saved_side_sash = side.sashpos(0)
                side.pane(assets_home, minsize=36)
                side.sashpos(0, 44)
            elif steps_out:
                if getattr(self, "_saved_side_sash", None) is None:
                    self._saved_side_sash = side.sashpos(0)
                side.pane(steps_home, minsize=36)
                side.sashpos(0, max(total - 44, 80))
            else:
                side.pane(assets_home, minsize=80)
                side.pane(steps_home, minsize=80)
                saved = getattr(self, "_saved_side_sash", None)
                if saved:
                    side.sashpos(0, saved)
                self._saved_side_sash = None
                self.root.after(40, self._ensure_side_pane_space)
        except Exception:
            pass

    def _ensure_side_pane_space(self):
        """Keep Assets Manager tall enough that Add/Clear and Page Geometry stay on screen."""
        side = getattr(self, "_side_paned", None)
        assets_home = getattr(self, "_assets_home", None)
        steps_home = getattr(self, "_steps_home", None)
        if side is None or assets_home is None or steps_home is None:
            return
        if self._panel_floating("assets") or self._panel_floating("steps"):
            return
        try:
            side.update_idletasks()
            total = side.winfo_height()
        except Exception:
            return
        if total < 120:
            self.root.after(120, self._ensure_side_pane_space)
            return
        body = getattr(self, "_assets_body", None)
        try:
            body.update_idletasks()
            # Prefer measured fixed-control height; fall back to a safe minimum.
            req = 0
            for child in body.winfo_children():
                try:
                    info = child.pack_info()
                except Exception:
                    continue
                if info.get("side") == "bottom":
                    req += max(child.winfo_reqheight(), 1)
            assets_min = max(200, req + 90)
            steps_min = 180
            if total < assets_min + steps_min:
                # Grow the main window so both panes can show their controls.
                try:
                    cur_h = self.root.winfo_height()
                    cur_w = self.root.winfo_width()
                    need = (assets_min + steps_min + 220) - total
                    if need > 0 and cur_h > 0:
                        self.root.geometry(f"{cur_w}x{cur_h + need}")
                        self.root.after(120, self._ensure_side_pane_space)
                        return
                except Exception:
                    pass
            side.pane(assets_home, minsize=min(assets_min, max(total - steps_min, 120)))
            side.pane(steps_home, minsize=min(steps_min, max(total // 3, 100)))
            target = max(assets_min, min(int(total * 0.52), total - steps_min))
            side.sashpos(0, target)
        except Exception:
            pass

    def _size_float_to_content(self, which):
        """Grow a popped Assets/Steps window so its buttons are not clipped."""
        win = getattr(self, f"_{which}_float", None)
        if win is None:
            return
        try:
            if not win.winfo_exists():
                return
            win.update_idletasks()
            req_w = max(win.winfo_reqwidth(), 420)
            req_h = max(win.winfo_reqheight(), 520 if which == "assets" else 480)
            win.geometry(f"{req_w}x{req_h}")
            win.minsize(min(req_w, 360), min(req_h, 400))
        except Exception:
            pass

    def _set_initial_preview_width(self):
        """Open with a narrow Real-Time Monitor so the tool pane has room."""
        paned = getattr(self, "_main_paned", None)
        if paned is None:
            return
        try:
            total = paned.winfo_width()
        except Exception:
            return
        if total < 400:
            self.root.after(120, self._set_initial_preview_width)
            return
        preview_w = 280
        try:
            paned.sashpos(0, min(280, max(180, total // 5)))
            paned.sashpos(1, max(total - preview_w, 420))
        except Exception:
            pass

    def _bind_preview_canvas(self, canvas):
        canvas.bind("<MouseWheel>", self._on_mousewheel)
        canvas.bind("<Button-1>", self.on_canvas_click)
        canvas.bind("<Motion>", self._on_preview_motion, add="+")
        canvas.bind("<Leave>", self._clear_ruler_hover, add="+")
        canvas.bind("<Configure>", self._on_preview_canvas_configure, add="+")

    def _on_preview_canvas_configure(self, event):
        """Refit when the monitor pane finishes opening or the user resizes it."""
        if event.widget is not getattr(self, "preview_canvas", None):
            return
        if event.width < 20 or event.height < 20:
            return
        size = (int(event.width), int(event.height))
        self._preview_canvas_px = size
        if size == getattr(self, "_preview_rendered_size", None):
            return
        job = getattr(self, "_preview_fit_job", None)
        if job:
            try:
                self.root.after_cancel(job)
            except Exception:
                pass
        self._preview_fit_job = self.root.after(60, self.render_live_preview)

    def _preview_viewport_size(self):
        """Pixel size to fit the page into. Prefer the latest canvas resize."""
        seen = getattr(self, "_preview_canvas_px", None)
        if seen and seen[0] >= 20 and seen[1] >= 20:
            return int(seen[0]), int(seen[1])
        canvas = getattr(self, "preview_canvas", None)
        w = h = 0
        if canvas is not None:
            try:
                w = int(canvas.winfo_width())
                h = int(canvas.winfo_height())
            except Exception:
                w = h = 0
        if w >= 20 and h >= 20:
            return w, h
        win = getattr(self, "_preview_float", None)
        if win is not None:
            try:
                if win.winfo_exists():
                    win.update_idletasks()
                    fw = int(win.winfo_width())
                    fh = int(win.winfo_height())
                    if fw >= 40 and fh >= 40:
                        return max(fw - 28, 200), max(fh - 170, 240)
            except Exception:
                pass
        return 700, 600

    def _collapse_monitor_pane(self):
        """Shrink the right pane to a thin Dock strip while the monitor floats."""
        paned = getattr(self, "_main_paned", None)
        home = getattr(self, "_preview_home", None)
        if paned is None or home is None:
            return
        try:
            self._saved_monitor_sash = paned.sashpos(1)
        except Exception:
            self._saved_monitor_sash = None
        try:
            paned.pane(home, minsize=44)
        except Exception:
            pass
        try:
            total = paned.winfo_width()
            if total > 200:
                paned.sashpos(1, max(total - 52, 200))
        except Exception:
            pass

    def _restore_monitor_pane(self):
        paned = getattr(self, "_main_paned", None)
        home = getattr(self, "_preview_home", None)
        if paned is None or home is None:
            return
        try:
            paned.pane(home, minsize=180)
        except Exception:
            pass
        saved = getattr(self, "_saved_monitor_sash", None)
        try:
            if saved:
                paned.sashpos(1, saved)
            else:
                total = paned.winfo_width()
                if total > 400:
                    paned.sashpos(1, max(total - 280, 420))
        except Exception:
            pass

    def toggle_preview_float(self):
        win = getattr(self, "_preview_float", None)
        if win is not None:
            try:
                if win.winfo_exists():
                    self._dock_preview()
                    return
            except Exception:
                pass
        self._pop_preview()

    def _pop_preview(self):
        """Open a new monitor window. Do not reparent the in-app widgets; Tk blanks them."""
        body = getattr(self, "_monitor_body", None)
        if body is None:
            return
        win = tk.Toplevel(self.root)
        win.title("ReadySetPDF — Real-Time Monitor")
        win.geometry("980x860")
        win.minsize(640, 480)
        win.configure(bg=self.color_white)
        win.protocol("WM_DELETE_WINDOW", self._dock_preview)

        self._dock_preview_refs = {
            "canvas": self.preview_canvas,
            "file": self.preview_file_label,
            "page": self.preview_page_label,
            "status": self.history_status_label,
            "prev": self.btn_prev_file,
            "next": self.btn_next_file,
            "zoom": self.zoom_combo,
            "measure": self.measure_toggle,
        }
        self._build_monitor_chrome(win, corner="dock").pack(fill="x", padx=8, pady=(8, 4))

        host = tk.Frame(win, bg=self.color_navy)
        host.pack(fill="both", expand=True, padx=8, pady=4)
        host.grid_rowconfigure(0, weight=1)
        host.grid_columnconfigure(0, weight=1)
        canvas = tk.Canvas(host, bg=self.color_navy, highlightthickness=0, width=900, height=640)
        vs = ttk.Scrollbar(host, orient="vertical", command=canvas.yview)
        hs = ttk.Scrollbar(host, orient="horizontal", command=canvas.xview)
        canvas.configure(yscrollcommand=vs.set, xscrollcommand=hs.set)
        canvas.grid(row=0, column=0, sticky="nsew")
        vs.grid(row=0, column=1, sticky="ns")
        hs.grid(row=1, column=0, sticky="ew")
        self._bind_preview_canvas(canvas)

        self.preview_canvas = canvas
        self._preview_float = win

        body.pack_forget()
        strip = getattr(self, "_monitor_dock_strip", None)
        if strip is not None:
            strip.pack(fill="both", expand=True)
        self._collapse_monitor_pane()

        def _draw_when_shown(_event=None):
            if getattr(self, "_preview_float", None) is not win:
                return
            try:
                win.update_idletasks()
            except Exception:
                return
            self.render_live_preview()

        win.bind("<Map>", _draw_when_shown)
        win.after(160, _draw_when_shown)

    def _dock_preview(self):
        """Close the floating monitor and show the in-app one again."""
        refs = getattr(self, "_dock_preview_refs", None) or {}
        if refs.get("canvas") is not None:
            try:
                if refs["canvas"].winfo_exists():
                    self.preview_canvas = refs["canvas"]
                    self.preview_file_label = refs["file"]
                    self.preview_page_label = refs["page"]
                    self.history_status_label = refs["status"]
                    self.btn_prev_file = refs["prev"]
                    self.btn_next_file = refs["next"]
                    if refs.get("zoom") is not None:
                        self.zoom_combo = refs["zoom"]
                    if refs.get("measure") is not None:
                        self.measure_toggle = refs["measure"]
            except Exception:
                pass
        self._dock_preview_refs = None
        win = getattr(self, "_preview_float", None)
        self._preview_float = None
        if win is not None:
            try:
                if win.winfo_exists():
                    win.destroy()
            except Exception:
                pass
        strip = getattr(self, "_monitor_dock_strip", None)
        if strip is not None:
            try:
                strip.pack_forget()
            except Exception:
                pass
        body = getattr(self, "_monitor_body", None)
        home = getattr(self, "_preview_home", None)
        if body is not None and home is not None:
            try:
                if body.winfo_exists() and home.winfo_exists():
                    body.pack_forget()
                    body.pack(in_=home, fill="both", expand=True)
            except Exception:
                pass
        self._restore_monitor_pane()
        self.root.after(50, self.render_live_preview)

    def show_about_dialog(self):
        about_win = tk.Toplevel(self.root)
        about_win.title("About ReadySetPDF")
        about_win.geometry("460x430")
        about_win.minsize(420, 380)
        about_win.configure(bg=self.color_white)
        about_win.transient(self.root)
        about_win.grab_set()

        body = tk.Frame(about_win, bg=self.color_white)
        body.pack(fill="both", expand=True, padx=28, pady=24)

        tk.Label(
            body, text="ReadySetPDF",
            bg=self.color_white, fg=self.color_navy, font=("Arial", 18, "bold"),
        ).pack(pady=(8, 0))
        tk.Label(
            body, text=f"Version {APP_VERSION}",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 10),
        ).pack(pady=(2, 10))
        tk.Label(
            body, text="ReadySetPDF LLC",
            bg=self.color_white, fg=self.color_navy, font=("Arial", 11),
        ).pack(pady=(0, 12))

        site = tk.Button(
            body, text="www.readysetpdf.com",
            bg=self.color_white, fg=self.color_steel,
            activebackground=self.color_white, activeforeground=self.color_navy,
            relief="flat", borderwidth=0, highlightthickness=0,
            font=("Arial", 10, "underline"), cursor="hand2",
            command=lambda: webbrowser.open("https://www.readysetpdf.com/"),
        )
        site.pack()

        mail = tk.Button(
            body, text="darren@readysetpdf.com",
            bg=self.color_white, fg=self.color_steel,
            activebackground=self.color_white, activeforeground=self.color_navy,
            relief="flat", borderwidth=0, highlightthickness=0,
            font=("Arial", 10, "underline"), cursor="hand2",
            command=lambda: webbrowser.open("mailto:darren@readysetpdf.com"),
        )
        mail.pack(pady=(4, 16))

        tk.Label(
            body,
            text="Copyright © 2026 ReadySetPDF LLC. All rights reserved. Proprietary Software.",
            bg=self.color_white, fg=self.color_navy, font=("Arial", 9),
            justify="center", wraplength=380,
        ).pack(pady=(4, 8))

        self._create_btn(
            body, "Check for Hot-Fixes", self.color_steel, self.color_white,
            lambda: self.check_for_hotfixes(about_win),
        ).pack(pady=(8, 0))
        tk.Label(
            body, textvariable=self.hotfix_status_var,
            bg=self.color_white, fg=self.color_navy, font=("Arial", 9),
            justify="center", wraplength=380,
        ).pack(pady=(6, 0))

        self._create_btn(
            body, "Close", self.color_steel, self.color_white, about_win.destroy,
        ).pack(pady=(12, 0))

    def check_for_hotfixes(self, parent=None):
        if self._hotfix_busy:
            return
        self._hotfix_busy = True
        self.hotfix_status_var.set("Checking for hot-fixes...")
        threading.Thread(
            target=self._hotfix_check_worker, args=(parent,), daemon=True,
        ).start()

    def _hotfix_parent(self, parent):
        try:
            if parent is not None and parent.winfo_exists():
                return parent
        except Exception:
            pass
        return self.root

    def _hotfix_check_worker(self, parent):
        try:
            manifest = hotfix.fetch_manifest()
        except Exception as exc:
            self.root.after(0, lambda error=str(exc): self._hotfix_check_failed(error, parent))
            return
        self.root.after(0, lambda found=manifest: self._hotfix_offer(found, parent))

    def _hotfix_check_failed(self, error, parent):
        self._hotfix_busy = False
        self.hotfix_status_var.set("Could not check for hot-fixes.")
        messagebox.showerror("Hot-Fixes", error, parent=self._hotfix_parent(parent))

    def _hotfix_offer(self, manifest, parent):
        self._hotfix_busy = False
        parent = self._hotfix_parent(parent)
        remote = manifest.get("version") or ""
        notes = manifest.get("release_notes") or "No release notes."
        if not hotfix.version_is_newer(remote, APP_VERSION):
            self.hotfix_status_var.set(f"ReadySetPDF {APP_VERSION} is up to date.")
            messagebox.showinfo(
                "Hot-Fixes",
                f"ReadySetPDF {APP_VERSION} is up to date.",
                parent=parent,
            )
            return
        self.hotfix_status_var.set(f"Hot-fix {remote} is available.")
        if not messagebox.askyesno(
            "Hot-Fix Available",
            f"Version {remote} is available (you have {APP_VERSION}).\n\n{notes}\n\n"
            "Download and install it now? ReadySetPDF will close and reopen.",
            parent=parent,
        ):
            return
        if not manifest.get("patch_url"):
            messagebox.showerror("Hot-Fixes", "This hot-fix has no download address.", parent=parent)
            return
        self._hotfix_busy = True
        self.hotfix_status_var.set("Downloading hot-fix...")
        threading.Thread(
            target=self._hotfix_apply_worker, args=(manifest, parent), daemon=True,
        ).start()

    def _hotfix_apply_worker(self, manifest, parent):
        try:
            bat_path = hotfix.stage_update(manifest)
        except Exception as exc:
            self.root.after(0, lambda error=str(exc): self._hotfix_check_failed(error, parent))
            return
        self.root.after(0, lambda path=bat_path: self._hotfix_relaunch(path))

    def _hotfix_relaunch(self, bat_path):
        self.hotfix_status_var.set("Installing hot-fix...")
        try:
            hotfix.launch_updater(bat_path)
        except Exception as exc:
            self._hotfix_busy = False
            self.hotfix_status_var.set("Could not start the installer.")
            messagebox.showerror("Hot-Fixes", str(exc), parent=self.root)
            return
        try:
            self.root.destroy()
        except Exception:
            pass
        sys.exit(0)

    def parse_locale_number(self, val_str):
        if val_str is None:
            return None
        s = str(val_str).strip().replace(" ", "").replace("\u00a0", "")
        if not s:
            return None
        if "," in s and "." in s:
            if s.rfind(",") > s.rfind("."):
                s = s.replace(".", "").replace(",", ".")
            else:
                s = s.replace(",", "")
        elif "," in s:
            s = s.replace(",", ".")
        try:
            return float(s)
        except ValueError:
            return None

    def to_points(self, val_str, override_unit=None):
        val = self.parse_locale_number(val_str)
        if val is None:
            return 0.0

        unit = override_unit if override_unit else self.global_unit_var.get()

        if unit == "inches": return val * 72.0
        elif unit == "mm": return (val / 25.4) * 72.0
        elif unit == "points": return val
        return val * 72.0 
        
    def points_to_global_unit(self, pt_val):
        unit = self.global_unit_var.get()
        if unit == "inches": return pt_val / 72.0
        elif unit == "mm": return (pt_val / 72.0) * 25.4
        elif unit == "points": return pt_val
        return pt_val / 72.0

    def populate_standard_size(self, w_inches, h_inches, w_var, h_var):
        unit = self.global_unit_var.get()
        if unit == "mm":
            w_var.set(f"{w_inches * 25.4:.2f}")
            h_var.set(f"{h_inches * 25.4:.2f}")
        elif unit == "points":
            w_var.set(f"{w_inches * 72.0:.2f}")
            h_var.set(f"{h_inches * 72.0:.2f}")
        else:
            w_var.set(f"{w_inches}")
            h_var.set(f"{h_inches}")

    def _on_mousewheel(self, event):
        self.preview_canvas.yview_scroll(int(-1*(event.delta/120)), "units")
        
    def parse_page_selection(self, page_str, total_pages):
        p_str = str(page_str or "").strip().lower()
        if p_str in ("all", ""):
            return list(range(total_pages))
        if p_str in ("odd", "odds", "odd pages", "front", "fronts", "front side"):
            return [i for i in range(total_pages) if i % 2 == 0]
        if p_str in ("even", "evens", "even pages", "back", "backs", "back side"):
            return [i for i in range(total_pages) if i % 2 == 1]
        pages = set()
        for part in p_str.split(","):
            part = part.strip()
            if "-" in part:
                try:
                    start, end = part.split("-", 1)
                    for i in range(max(1, int(start)), min(total_pages, int(end)) + 1):
                        pages.add(i - 1)
                except ValueError:
                    continue
            else:
                try:
                    p_num = int(part)
                    if 1 <= p_num <= total_pages:
                        pages.add(p_num - 1)
                except ValueError:
                    continue
        return sorted(list(pages))

    def _add_page_target_row(self, parent, var):
        row = tk.Frame(parent, bg=self.color_white)
        row.pack(fill="x", pady=(4, 0))
        for label, value in (("All", "all"), ("Odd / Front", "odd"), ("Even / Back", "even")):
            self._create_btn(row, label, self.color_mint, self.color_navy, lambda v=value: var.set(v), compact=True).pack(side="left", padx=(0, 4))
        return row

    # --- TAB BUILDERS ---
    def build_resize_tab(self):
        tab = ttk.Frame(self.tab_content_frame, padding=15); self.tabs["Resize"] = tab
        dim_frame = ttk.LabelFrame(tab, text="Target Fixed Paper Size Settings", padding=10); dim_frame.pack(fill="x", pady=10)
        tk.Label(dim_frame, text="Presets:", bg=self.color_white, fg=self.color_navy).grid(row=0, column=0, sticky="w")
        self.resize_combo = ttk.Combobox(dim_frame, values=[], textvariable=self.resize_preset_var, width=15, state="readonly")
        self.resize_combo.grid(row=0, column=1, padx=5, pady=5); self.resize_combo.bind("<<ComboboxSelected>>", lambda e: self.handle_resize_preset())
        tk.Label(dim_frame, text="Width:", bg=self.color_white, fg=self.color_navy).grid(row=1, column=0, sticky="w"); tk.Entry(dim_frame, textvariable=self.resize_w_var, width=8, bg=self.color_pale).grid(row=1, column=1, padx=5, pady=5)
        tk.Label(dim_frame, text="Height:", bg=self.color_white, fg=self.color_navy).grid(row=2, column=0, sticky="w"); tk.Entry(dim_frame, textvariable=self.resize_h_var, width=8, bg=self.color_pale).grid(row=2, column=1, padx=5, pady=5)
        cb_land = ttk.Checkbutton(tab, text="Force Landscape Orientation Layout", variable=self.resize_landscape_var); cb_land.pack(anchor="w", pady=2)
        cb_stretch = ttk.Checkbutton(tab, text="Stretch content layer to fit bounding box", variable=self.resize_stretch_var); cb_stretch.pack(anchor="w", pady=2)
        ToolTip(cb_stretch, "If checked, ignore aspect ratio to forcefully stretch the graphic to the exact bounding box.", self)
        self._build_step_commit_buttons(tab, "Resize", "➕ Add Resize Step").pack(fill="x", side="bottom", pady=10)

    def handle_resize_preset(self):
        val = self.resize_preset_var.get()
        if val in self.custom_sizes:
            c = self.custom_sizes[val]
            self.resize_w_var.set(str(c.get("w") or f"{self.points_to_global_unit(c.get('w_pt', 0)):.3f}"))
            self.resize_h_var.set(str(c.get("h") or f"{self.points_to_global_unit(c.get('h_pt', 0)):.3f}"))
        elif val == "Letter": self.populate_standard_size(8.5, 11, self.resize_w_var, self.resize_h_var)
        elif val == "Legal": self.populate_standard_size(8.5, 14, self.resize_w_var, self.resize_h_var)
        elif val == "Tabloid": self.populate_standard_size(11, 17, self.resize_w_var, self.resize_h_var)
        elif val == "A4": self.populate_standard_size(8.27, 11.69, self.resize_w_var, self.resize_h_var)

    def build_crop_tab(self):
        tab = ttk.Frame(self.tab_content_frame, padding=15); self.tabs["Crop"] = tab
        tk.Label(tab, text="Trim white space or margins from the document.", bg=self.color_white, fg=self.color_steel, font=("Arial", 10, "italic")).pack(anchor="w", pady=(0, 10))
        margin_frame = ttk.LabelFrame(tab, text="Margin Crop Settings", padding=10); margin_frame.pack(fill="x", pady=5)
        grid_f = tk.Frame(margin_frame, bg=self.color_white); grid_f.pack(fill="x", pady=5)
        tk.Label(grid_f, text="Top:", bg=self.color_white, fg=self.color_navy).grid(row=0, column=2, padx=5, pady=5); tk.Entry(grid_f, textvariable=self.crop_top_var, width=6, bg=self.color_pale).grid(row=0, column=3, padx=5)
        tk.Label(grid_f, text="Left:", bg=self.color_white, fg=self.color_navy).grid(row=1, column=0, padx=5, pady=5); tk.Entry(grid_f, textvariable=self.crop_left_var, width=6, bg=self.color_pale).grid(row=1, column=1, padx=5)
        tk.Label(grid_f, text="Right:", bg=self.color_white, fg=self.color_navy).grid(row=1, column=4, padx=5, pady=5); tk.Entry(grid_f, textvariable=self.crop_right_var, width=6, bg=self.color_pale).grid(row=1, column=5, padx=5)
        tk.Label(grid_f, text="Bottom:", bg=self.color_white, fg=self.color_navy).grid(row=2, column=2, padx=5, pady=5); tk.Entry(grid_f, textvariable=self.crop_bottom_var, width=6, bg=self.color_pale).grid(row=2, column=3, padx=5)
        ToolTip(margin_frame, "Enter the exact dimensional amount to shave off each specific edge of the paper.", self)
        self._build_step_commit_buttons(tab, "Crop Margin", "➕ Add Crop Step").pack(fill="x", side="bottom", pady=10)

    def _build_duplex_edge_controls(self, parent, double_var, flip_var, row=0, column=2):
        box = tk.Frame(parent, bg=self.color_white)
        box.grid(row=row, column=column, rowspan=2, padx=(8, 0), sticky="nw")
        short_rb = ttk.Radiobutton(box, text="Short edge", variable=flip_var, value="short")
        long_rb = ttk.Radiobutton(box, text="Long edge", variable=flip_var, value="long")
        short_rb.pack(anchor="w")
        long_rb.pack(anchor="w")
        def _sync(*_):
            state = "normal" if double_var.get() else "disabled"
            short_rb.configure(state=state)
            long_rb.configure(state=state)
        double_var.trace_add("write", lambda *a: _sync())
        _sync()
        ToolTip(box, "When Double sided is on, even sheets (backs) reverse columns (long edge) or rows (short edge) so fronts and backs line up after the flip.", self)
        return box

    def _build_anchor_pad(self, parent, var, center_var=None, tooltip=None):
        wrap = tk.Frame(parent, bg=self.color_white)
        pad = tk.Frame(wrap, bg=self.color_white, bd=1, relief="solid", highlightthickness=0)
        pad.pack(side="left")
        keys = (("nw", "n", "ne"), ("w", "c", "e"), ("sw", "s", "se"))
        buttons = {}
        def refresh(*_):
            cur = var.get() or "c"
            for k, b in buttons.items():
                on = (k == cur)
                b.config(
                    bg=self.color_navy if on else self.color_pale,
                    fg=self.color_white if on else self.color_navy,
                    text="●" if on else " ",
                )
        def pick(k, event=None):
            var.set(k)
            if center_var is not None:
                center_var.set(k == "c")
            else:
                self.grid_center_var.set(k == "c")
            return "break"
        for r, row in enumerate(keys):
            for c, k in enumerate(row):
                b = tk.Button(
                    pad, width=2, height=1, relief="solid", bd=1, font=("Arial", 8),
                    takefocus=0, highlightthickness=0,
                    command=lambda key=k: pick(key), bg=self.color_pale, fg=self.color_navy,
                )
                b.grid(row=r, column=c, padx=1, pady=1)
                b.bind("<Button-1>", lambda e, key=k: pick(key), add="+")
                buttons[k] = b
                b.lift()
        var.trace_add("write", lambda *a: refresh())
        refresh()
        help_lbl = tk.Label(wrap, text="?", width=2, bg=self.color_mint, fg=self.color_navy, font=("Arial", 9, "bold"), cursor="question_arrow")
        help_lbl.pack(side="left", padx=(6, 0), anchor="n")
        ToolTip(
            help_lbl,
            tooltip or "Anchor for the n-up block. Margins are measured from this point.\nOn double-sided even pages the anchor mirrors with the duplex edge.",
            self,
        )
        return wrap

    def _build_source_trim_frame(self, parent, bleed_var, trim_w_var, trim_h_var):
        frame = ttk.LabelFrame(parent, text="Source Trim (artwork already has bleed)", padding=10)
        row = tk.Frame(frame, bg=self.color_white)
        tk.Label(row, text="Finished trim W × H:", bg=self.color_white, fg=self.color_navy).pack(side="left")
        w_e = tk.Entry(row, textvariable=trim_w_var, width=6, bg=self.color_pale)
        w_e.pack(side="left", padx=(8, 4))
        h_e = tk.Entry(row, textvariable=trim_h_var, width=6, bg=self.color_pale)
        h_e.pack(side="left")
        ttk.Checkbutton(
            frame, text="PDF already includes bleed", variable=bleed_var,
        ).pack(anchor="w")
        row.pack(fill="x", pady=(6, 0))
        tk.Label(
            frame,
            text="Layout steps by this finished trim in the current unit (mm, in, or pt). Gutter 0 = trims touch; bleed hangs into the gutter (and can overlap a neighbor). A 3 mm bleed does not add extra space unless you enter it as gutter. Crop marks sit on the trim. Leave W×H blank to use the PDF TrimBox when it is smaller than the page.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"), wraplength=420, justify="left",
        ).pack(anchor="w", pady=(6, 0))
        bleed_var.trace_add("write", lambda *a: self._sync_trim_fields(bleed_var, w_e, h_e))
        self._sync_trim_fields(bleed_var, w_e, h_e)
        return frame

    def _build_page_geometry_panel(self, parent):
        wrap = tk.Frame(parent, bg=self.color_white)
        wrap.pack(side="bottom", fill="x", padx=5, pady=(0, 4))
        self.page_geo_wrap = wrap
        header = tk.Frame(wrap, bg=self.color_white)
        header.pack(fill="x")
        self.page_geo_toggle_btn = tk.Label(
            header, text="▸ Page Geometry / Box Settings",
            bg=self.color_white, fg=self.color_navy, font=("Arial", 9, "bold"),
            cursor="hand2",
        )
        self.page_geo_toggle_btn.pack(side="left")
        self.page_geo_toggle_btn.bind("<Button-1>", lambda e: self._toggle_page_geometry())
        ToolTip(
            self.page_geo_toggle_btn,
            "Import pre-processing for MediaBox / CropBox / TrimBox.\nApplies to preview, export, and batch. Missing TrimBox falls back to CropBox, then MediaBox.",
            self,
        )
        self.page_geo_body = tk.Frame(wrap, bg=self.color_white, highlightbackground=self.color_steel, highlightthickness=1)
        tk.Label(
            self.page_geo_body, textvariable=self.page_geo_summary_var,
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8),
            wraplength=280, justify="left", anchor="w",
        ).pack(fill="x", padx=8, pady=(6, 4))
        for mode, label in (
            ("keep", PAGE_BOX_LABELS["keep"]),
            ("crop_to_trim", PAGE_BOX_LABELS["crop_to_trim"]),
            ("normalize_to_trim", PAGE_BOX_LABELS["normalize_to_trim"]),
        ):
            ttk.Radiobutton(
                self.page_geo_body, text=label, variable=self.page_box_mode_var, value=mode,
            ).pack(anchor="w", padx=8, pady=1)
        tk.Label(
            self.page_geo_body,
            text="Keep leaves boxes alone (still origin-aligns Crop/Media for preview). CropBox=TrimBox hides bleed without deleting it. Remove extra margins clips the page to TrimBox.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"),
            wraplength=280, justify="left",
        ).pack(fill="x", padx=8, pady=(4, 8))

    def _toggle_page_geometry(self):
        if self.page_geo_body.winfo_ismapped():
            self.page_geo_body.pack_forget()
            self.page_geo_toggle_btn.config(text="▸ Page Geometry / Box Settings")
        else:
            self.page_geo_body.pack(fill="x", pady=(2, 0))
            self.page_geo_toggle_btn.config(text="▾ Page Geometry / Box Settings")
            self._refresh_page_geometry_summary()
            self.root.after(40, self._ensure_side_pane_space)

    def _refresh_page_geometry_summary(self):
        if not getattr(self, "page_geo_summary_var", None):
            return
        if not self.files:
            self.page_geo_summary_var.set("Load a file to read Media / Crop / Trim.")
            return
        idx = 0
        try:
            sel = self.file_list.curselection()
            if sel:
                idx = sel[0]
        except Exception:
            idx = 0
        if idx < 0 or idx >= len(self.files):
            idx = 0
        self.page_geo_summary_var.set(
            format_page_boxes_summary(self.files[idx], unit=self.global_unit_var.get())
        )

    def _on_asset_file_selected(self, event=None):
        """Show the clicked asset. A Join step otherwise keeps the monitor on every file."""
        if getattr(self, "_syncing_asset_selection", False):
            return
        self._refresh_page_geometry_summary()
        box = getattr(self, "file_list", None)
        if not self._widget_alive(box):
            return
        try:
            sel = box.curselection()
        except Exception:
            return
        if not sel:
            return
        idx = int(sel[0])
        if idx < 0 or idx >= len(self.files):
            return
        self._preview_selected_file = True
        if self.preview_merge_var.get():
            self.preview_merge_var.set(False)
        self.current_preview_file_index = idx
        self.current_preview_page = 0
        self.render_live_preview()

    def _select_asset_row(self, index):
        box = getattr(self, "file_list", None)
        if not self._widget_alive(box):
            return
        self._syncing_asset_selection = True
        try:
            box.selection_clear(0, tk.END)
            if 0 <= index < box.size():
                box.selection_set(index)
                box.activate(index)
                box.see(index)
        except Exception:
            pass
        finally:
            self._syncing_asset_selection = False

    def _on_page_geometry_change(self, *args):
        self.save_settings()
        job = getattr(self, "_live_preview_job", None)
        if job:
            try:
                self.root.after_cancel(job)
            except Exception:
                pass
        self._live_preview_job = self.root.after(280, self.render_live_preview)

    def _build_printer_marks_frame(self, parent, draw_var, dist_var, thick_var, overlap_var, color_var, draw_label):
        marks_frame = ttk.LabelFrame(parent, text="Printer's Marks", padding=10)
        ttk.Checkbutton(marks_frame, text=draw_label, variable=draw_var).grid(row=0, column=0, columnspan=4, sticky="w")
        tk.Label(marks_frame, text="Gap distance:", bg=self.color_white, fg=self.color_navy).grid(row=1, column=0, sticky="w", pady=(5, 0))
        gap_e = tk.Entry(marks_frame, textvariable=dist_var, width=8, bg=self.color_pale)
        gap_e.grid(row=1, column=1, pady=(5, 0), padx=5, sticky="w")
        ToolTip(
            gap_e,
            "Distance from the trim to the inner end of the mark. Positive keeps a space off the live. Negative overlaps into the trim (hand cutting). Older recipes that stored a separate Overlap value are still honored.",
            self,
        )
        tk.Label(marks_frame, text="Line thickness:", bg=self.color_white, fg=self.color_navy).grid(row=2, column=0, sticky="w")
        tk.Entry(marks_frame, textvariable=thick_var, width=8, bg=self.color_pale).grid(row=2, column=1, padx=5, sticky="w")
        color_row = tk.Frame(marks_frame, bg=self.color_white)
        color_row.grid(row=3, column=0, columnspan=4, sticky="w", pady=(6, 0))
        tk.Label(color_row, text="Mark color:", bg=self.color_white, fg=self.color_navy).pack(side="left")
        ttk.Radiobutton(color_row, text="Black", variable=color_var, value="black").pack(side="left", padx=(8, 0))
        ttk.Radiobutton(color_row, text="Grey", variable=color_var, value="grey").pack(side="left", padx=(8, 0))
        ttk.Radiobutton(color_row, text="White", variable=color_var, value="white").pack(side="left", padx=(8, 0))
        return marks_frame

    def _sync_trim_fields(self, bleed_var, *entries):
        state = "normal" if bleed_var.get() else "disabled"
        for e in entries:
            try:
                e.configure(state=state)
            except Exception:
                pass

    def build_grid_tab(self):
        main_frame = ttk.Frame(self.tab_content_frame); self.tabs["Grid"] = main_frame
        tab = ttk.Frame(main_frame, padding=10); tab.pack(fill="x", expand=False)
        paper_frame = ttk.LabelFrame(tab, text="Paper Size", padding=10); paper_frame.pack(fill="x", pady=(0, 5))
        self.grid_combo = ttk.Combobox(paper_frame, values=[], textvariable=self.grid_preset_var, width=15, state="readonly")
        self.grid_combo.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0,5)); self.grid_combo.bind("<<ComboboxSelected>>", lambda e: self.handle_grid_preset())
        tk.Label(paper_frame, text="Width", bg=self.color_white, fg=self.color_navy).grid(row=1, column=0, sticky="w"); tk.Entry(paper_frame, textvariable=self.grid_w_var, width=6, bg=self.color_pale).grid(row=1, column=1, sticky="w")
        tk.Label(paper_frame, text="Height", bg=self.color_white, fg=self.color_navy).grid(row=2, column=0, sticky="w", pady=(5,0)); tk.Entry(paper_frame, textvariable=self.grid_h_var, width=6, bg=self.color_pale).grid(row=2, column=1, sticky="w", pady=(5,0))
        ttk.Checkbutton(paper_frame, text="Landscape", variable=self.grid_landscape_var).grid(row=3, column=0, columnspan=3, sticky="w", pady=(5,0))
        order_frame = ttk.LabelFrame(tab, text="Page Order", padding=10); order_frame.pack(fill="x", pady=5)
        ttk.Combobox(order_frame, values=["Sequential", "Step and Repeat"], textvariable=self.grid_order_var, width=15, state="readonly").grid(row=0, column=0, sticky="w")
        ttk.Checkbutton(order_frame, text="Double sided", variable=self.grid_double_sided_var).grid(row=0, column=1, padx=10)
        self._build_duplex_edge_controls(order_frame, self.grid_double_sided_var, self.grid_flip_edge_var)
        tk.Label(order_frame, text="Repeat each page", bg=self.color_white, fg=self.color_navy).grid(row=1, column=0, sticky="w", pady=(5,0)); tk.Entry(order_frame, textvariable=self.grid_repeat_var, width=6, bg=self.color_pale).grid(row=1, column=1, sticky="w", pady=(5,0))
        
        layout_frame = ttk.LabelFrame(tab, text="Layout Configuration", padding=10); layout_frame.pack(fill="x", pady=5)
        cb_fit = ttk.Checkbutton(layout_frame, text="Auto max-fit", variable=self.grid_auto_fit_var, command=self._sync_grid_auto_fit)
        cb_fit.grid(row=0, column=0, columnspan=4, sticky="w")
        ToolTip(cb_fit, "Fit as many native-size copies as the sheet will hold.\nColumns and rows are calculated from the piece, the margins, and the gutters.", self)
        dir_row = tk.Frame(layout_frame, bg=self.color_white)
        dir_row.grid(row=1, column=0, columnspan=4, sticky="ew", pady=(6, 0))
        tk.Radiobutton(dir_row, text="[ Z ➔ ] Left-to-Right", variable=self.grid_direction_var, value="LTR", indicatoron=0, bg=self.color_pale, fg=self.color_navy, relief="flat", wraplength=160, justify="center").pack(side="left", padx=(0, 5), fill="x", expand=True)
        tk.Radiobutton(dir_row, text="[ ⬅ Z ] Right-to-Left", variable=self.grid_direction_var, value="RTL", indicatoron=0, bg=self.color_pale, fg=self.color_navy, relief="flat", wraplength=160, justify="center").pack(side="left", padx=5, fill="x", expand=True)
        tk.Label(layout_frame, text="Columns", bg=self.color_white, fg=self.color_navy).grid(row=2, column=0, sticky="w", pady=(5,0))
        self._grid_cols_entry = tk.Entry(layout_frame, textvariable=self.grid_cols_var, width=6, bg=self.color_pale)
        self._grid_cols_entry.grid(row=2, column=1, sticky="w", pady=(5,0), padx=(0,10))
        tk.Label(layout_frame, text="Rows", bg=self.color_white, fg=self.color_navy).grid(row=2, column=2, sticky="w", pady=(5,0))
        self._grid_rows_entry = tk.Entry(layout_frame, textvariable=self.grid_rows_var, width=6, bg=self.color_pale)
        self._grid_rows_entry.grid(row=2, column=3, sticky="w", pady=(5,0))

        cb_auto = ttk.Checkbutton(layout_frame, text="Autoscale graphic to fit cell", variable=self.grid_autoscale_var)
        cb_auto.grid(row=3, column=0, columnspan=2, sticky="w", pady=(5,0))
        self._grid_autoscale_cb = cb_auto
        ToolTip(cb_auto, "Off at startup so the preview is native size (106 mm stays 106 mm). When on, artwork is scaled to fill the cell; White Space only changes the cell, not the PDF millimetre size.", self)

        cb_aspect = ttk.Checkbutton(layout_frame, text="Maintain aspect ratio", variable=self.grid_aspect_var)
        cb_aspect.grid(row=3, column=2, columnspan=2, sticky="w", pady=(5,0))
        self._grid_aspect_cb = cb_aspect
        ToolTip(cb_aspect, "Only used with Autoscale. Prevents distortion while filling the cell. Ignored when Autoscale is off (native page size).", self)
        self._sync_grid_auto_fit()

        space_frame = ttk.LabelFrame(tab, text="White Space", padding=10); space_frame.pack(fill="x", pady=5)
        anchor_pad = self._build_anchor_pad(space_frame, self.grid_anchor_var, center_var=self.grid_center_var)
        anchor_pad.grid(row=1, column=0, rowspan=3, padx=(0, 10), pady=2, sticky="nw")
        anchor_pad.lift()
        tk.Label(space_frame, text="Margins:", bg=self.color_white, fg=self.color_navy).grid(row=1, column=1, sticky="w")
        tk.Entry(space_frame, textvariable=self.grid_margin_l_var, width=6, bg=self.color_pale).grid(row=1, column=2, padx=(0,5))
        tk.Entry(space_frame, textvariable=self.grid_margin_t_var, width=6, bg=self.color_pale).grid(row=1, column=3, padx=(0,5))
        tk.Label(space_frame, text="Gutters:", bg=self.color_white, fg=self.color_navy).grid(row=3, column=1, sticky="w")
        tk.Entry(space_frame, textvariable=self.grid_gutter_h_var, width=6, bg=self.color_pale).grid(row=3, column=2, padx=(0,5))
        tk.Entry(space_frame, textvariable=self.grid_gutter_v_var, width=6, bg=self.color_pale).grid(row=3, column=3, padx=(0,5))
        tk.Label(
            space_frame, text="H / V values use the global unit. With Source Trim, gutter is the space between finished trims (0 = trims touch). Negative gutter overlaps trims. Turn Autoscale off to park native-size cards in a corner.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"), wraplength=280, justify="left",
        ).grid(row=4, column=1, columnspan=3, sticky="w", pady=(6, 0))
        self._build_source_trim_frame(tab, self.grid_art_has_bleed_var, self.grid_trim_w_var, self.grid_trim_h_var).pack(fill="x", pady=5)
        self._build_printer_marks_frame(
            tab, self.grid_draw_marks_var, self.grid_mark_dist_var, self.grid_mark_thick_var,
            self.grid_mark_overlap_var, self.grid_mark_color_var,
            "Draw crop marks (at trim when bleed is set)",
        ).pack(fill="x", pady=5)
        self._build_step_commit_buttons(tab, "Grid Imposition", "➕ Add Grid Imposition").pack(fill="x", pady=10)

    def handle_grid_preset(self):
        val = self.grid_preset_var.get()
        if val in self.custom_sizes:
            c = self.custom_sizes[val]
            self.grid_w_var.set(str(c.get("w") or f"{self.points_to_global_unit(c.get('w_pt', 0)):.3f}"))
            self.grid_h_var.set(str(c.get("h") or f"{self.points_to_global_unit(c.get('h_pt', 0)):.3f}"))
        elif val == "12x18": self.populate_standard_size(12, 18, self.grid_w_var, self.grid_h_var)
        elif val == "13x19": self.populate_standard_size(13, 19, self.grid_w_var, self.grid_h_var)
        elif val == "Letter": self.populate_standard_size(8.5, 11, self.grid_w_var, self.grid_h_var)
        elif val == "Tabloid": self.populate_standard_size(11, 17, self.grid_w_var, self.grid_h_var)

    def _sync_grid_auto_fit(self):
        """Auto max-fit calculates columns and rows and keeps the artwork at native size."""
        locked = bool(self.grid_auto_fit_var.get())
        state = "disabled" if locked else "normal"
        for widget in (
            getattr(self, "_grid_cols_entry", None),
            getattr(self, "_grid_rows_entry", None),
            getattr(self, "_grid_autoscale_cb", None),
            getattr(self, "_grid_aspect_cb", None),
        ):
            if widget is None:
                continue
            try:
                widget.configure(state=state)
            except Exception:
                pass

    def build_booklet_tab(self):
        main_frame = ttk.Frame(self.tab_content_frame); self.tabs["Booklet"] = main_frame
        tab = ttk.Frame(main_frame, padding=10); tab.pack(fill="x", expand=False)
        tk.Label(tab, text="Note: Source document page count must be divisible by 4.", bg=self.color_white, fg=self.color_steel, font=("Arial", 10, "bold", "italic")).pack(anchor="w", pady=(0, 10))
        blank_frame = ttk.LabelFrame(tab, text="Pad Document", padding=10); blank_frame.pack(fill="x", pady=(0, 10))
        tk.Label(blank_frame, text="Insert blank page at:", bg=self.color_white, fg=self.color_navy).pack(side="left")
        ttk.Combobox(blank_frame, values=["End of Document", "Beginning of Document", "After Page #"], textvariable=self.blank_pos_var, state="readonly", width=20).pack(side="left", padx=5)
        pg_entry = tk.Entry(blank_frame, textvariable=self.blank_page_num_var, width=5, bg=self.color_pale)
        pg_entry.pack(side="left", padx=5)
        ToolTip(pg_entry, "Only needed if you selected 'After Page #' in the dropdown.", self)
        self._create_btn(blank_frame, "➕ Insert Blank Page", self.color_mint, self.color_navy, lambda: self.add_step_to_queue("Insert Blank Page")).pack(side="right")
        paper_frame = ttk.LabelFrame(tab, text="Paper Size", padding=10); paper_frame.pack(fill="x", pady=(0, 5))
        self.booklet_combo = ttk.Combobox(paper_frame, values=[], textvariable=self.booklet_preset_var, width=18, state="readonly")
        self.booklet_combo.grid(row=0, column=0, columnspan=2, sticky="w", pady=(0,5)); self.booklet_combo.bind("<<ComboboxSelected>>", lambda e: self.handle_booklet_preset())
        tk.Label(paper_frame, text="Width", bg=self.color_white, fg=self.color_navy).grid(row=1, column=0, sticky="w"); tk.Entry(paper_frame, textvariable=self.booklet_w_var, width=6, bg=self.color_pale).grid(row=1, column=1, sticky="w")
        tk.Label(paper_frame, text="Height", bg=self.color_white, fg=self.color_navy).grid(row=2, column=0, sticky="w", pady=(5,0)); tk.Entry(paper_frame, textvariable=self.booklet_h_var, width=6, bg=self.color_pale).grid(row=2, column=1, sticky="w", pady=(5,0))
        ttk.Checkbutton(paper_frame, text="Landscape", variable=self.booklet_landscape_var).grid(row=3, column=0, columnspan=3, sticky="w", pady=(5,0))
        space_frame = ttk.LabelFrame(tab, text="White Space", padding=10); space_frame.pack(fill="x", pady=5)
        anchor_pad = self._build_anchor_pad(
            space_frame, self.booklet_anchor_var, center_var=self.booklet_center_var,
            tooltip="Anchor for the facing-page pair. Margins are offsets from this point.\nCenter matches the old Center output on page option.",
        )
        anchor_pad.grid(row=1, column=0, rowspan=5, padx=(0, 10), pady=2, sticky="nw")
        anchor_pad.lift()
        tk.Label(space_frame, text="Margins:", bg=self.color_white, fg=self.color_navy).grid(row=1, column=1, sticky="w")
        tk.Entry(space_frame, textvariable=self.booklet_margin_l_var, width=6, bg=self.color_pale).grid(row=1, column=2, padx=(0,5))
        tk.Entry(space_frame, textvariable=self.booklet_margin_t_var, width=6, bg=self.color_pale).grid(row=1, column=3, padx=(0,5))
        tk.Label(space_frame, text="Center Gutter:", bg=self.color_white, fg=self.color_navy).grid(row=2, column=1, sticky="e", pady=(5,0))
        tk.Entry(space_frame, textvariable=self.booklet_center_gutter_var, width=6, bg=self.color_pale).grid(row=2, column=2, pady=(5,0), padx=(0,5))
        tk.Label(space_frame, text="Creep / sheet:", bg=self.color_white, fg=self.color_navy).grid(row=3, column=1, sticky="e", pady=(5,0))
        creep_e = tk.Entry(space_frame, textvariable=self.booklet_creep_var, width=6, bg=self.color_pale)
        creep_e.grid(row=3, column=2, pady=(5,0), padx=(0,5))
        ToolTip(creep_e, "Paper thickness per sheet. Cover (preview page 1) is always 0; each inner sheet adds this amount again. Page forward to see inner signatures.", self)
        ttk.Radiobutton(space_frame, text="Creep Outward", variable=self.booklet_creep_dir_var, value="Outward").grid(row=4, column=1, columnspan=3, sticky="w")
        ttk.Radiobutton(space_frame, text="Creep Inward", variable=self.booklet_creep_dir_var, value="Inward").grid(row=5, column=1, columnspan=3, sticky="w")
        tk.Label(
            space_frame, text="H / V offsets are relative to the selected anchor. Outward moves pages toward the spine; Inward opens the gutter. Creep is per sheet (cover = 0).",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"), wraplength=280, justify="left",
        ).grid(row=6, column=1, columnspan=3, sticky="w", pady=(6, 0))
        self._build_source_trim_frame(tab, self.booklet_art_has_bleed_var, self.booklet_trim_w_var, self.booklet_trim_h_var).pack(fill="x", pady=5)
        self._build_printer_marks_frame(
            tab, self.booklet_draw_marks_var, self.booklet_mark_dist_var, self.booklet_mark_thick_var,
            self.booklet_mark_overlap_var, self.booklet_mark_color_var,
            "Draw crop marks at the source trim",
        ).pack(fill="x", pady=5)
        self._build_step_commit_buttons(tab, "Booklet Spread", "➕ Add Booklet Step").pack(fill="x", pady=10)

    def handle_booklet_preset(self):
        val = self.booklet_preset_var.get()
        if val in self.custom_sizes:
            c = self.custom_sizes[val]
            self.booklet_w_var.set(str(c.get("w") or f"{self.points_to_global_unit(c.get('w_pt', 0)):.3f}"))
            self.booklet_h_var.set(str(c.get("h") or f"{self.points_to_global_unit(c.get('h_pt', 0)):.3f}"))
        elif "Tabloid" in val: self.populate_standard_size(17, 11, self.booklet_w_var, self.booklet_h_var)
        elif "Letter" in val: self.populate_standard_size(11, 8.5, self.booklet_w_var, self.booklet_h_var)

    def build_cutter_tab(self):
        tab = ttk.Frame(self.tab_content_frame, padding=15); self.tabs["Cutter"] = tab
        marks_frame = ttk.LabelFrame(tab, text="Registration Marks", padding=10); marks_frame.pack(fill="x", pady=5)
        row1 = ttk.Frame(marks_frame); row1.pack(fill="x", pady=2)
        tk.Label(row1, text="Size:", bg=self.color_white, fg=self.color_navy).pack(side="left"); tk.Entry(row1, textvariable=self.cutter_size_var, width=6, bg=self.color_pale).pack(side="left", padx=5)
        tk.Label(row1, text="Thickness:", bg=self.color_white, fg=self.color_navy).pack(side="left"); tk.Entry(row1, textvariable=self.cutter_thick_var, width=6, bg=self.color_pale).pack(side="left", padx=5)
        row2 = ttk.Frame(marks_frame); row2.pack(fill="x", pady=8)
        ttk.Combobox(row2, values=["Inside", "Outside"], textvariable=self.cutter_placement_var, width=8, state="readonly").pack(side="left")
        tk.Label(row2, text="Media box", bg=self.color_white, fg=self.color_navy).pack(side="left", padx=5)
        row3 = ttk.Frame(marks_frame); row3.pack(fill="x", pady=2)
        tk.Label(row3, text="Margins:", bg=self.color_white, fg=self.color_navy).pack(side="left"); tk.Entry(row3, textvariable=self.cutter_margin_var, width=6, bg=self.color_pale).pack(side="left", padx=5)
        color_row = ttk.Frame(marks_frame); color_row.pack(fill="x", pady=6)
        tk.Label(color_row, text="Mark color:", bg=self.color_white, fg=self.color_navy).pack(side="left")
        ttk.Radiobutton(color_row, text="Black", variable=self.cutter_mark_color_var, value="black").pack(side="left", padx=(8, 0))
        ttk.Radiobutton(color_row, text="Grey", variable=self.cutter_mark_color_var, value="grey").pack(side="left", padx=(8, 0))
        ttk.Radiobutton(color_row, text="White", variable=self.cutter_mark_color_var, value="white").pack(side="left", padx=(8, 0))
        row4 = ttk.Frame(marks_frame); row4.pack(fill="x", pady=8)
        tk.Label(row4, text="Pages:", bg=self.color_white, fg=self.color_navy).pack(side="left")
        
        cutter_pg_entry = tk.Entry(row4, textvariable=self.cutter_pages_var, width=15, bg=self.color_pale)
        cutter_pg_entry.pack(side="left", padx=5)
        ToolTip(cutter_pg_entry, "all, odd/front, even/back, or pages like 1,3,5 or 1-4", self)
        self._add_page_target_row(marks_frame, self.cutter_pages_var)

        extra_frame = ttk.LabelFrame(tab, text="Finishing / Collating Marks", padding=10); extra_frame.pack(fill="x", pady=8)
        ttk.Checkbutton(extra_frame, text="Draw L cut marks in all four corners", variable=self.cutter_l_marks_var).pack(anchor="w")
        extra_row = tk.Frame(extra_frame, bg=self.color_white); extra_row.pack(fill="x", pady=(6, 0))
        tk.Label(extra_row, text="Extra mark:", bg=self.color_white, fg=self.color_navy).pack(side="left")
        ttk.Combobox(
            extra_row,
            values=["None", "Round Dots", "Registration Cross", "Registration L"],
            textvariable=self.cutter_collate_var, width=20, state="readonly",
        ).pack(side="left", padx=5)
        tk.Label(extra_row, text="Corner:", bg=self.color_white, fg=self.color_navy).pack(side="left", padx=(10, 0))
        ttk.Combobox(
            extra_row,
            values=["Top Left", "Top Right", "Bottom Left", "Bottom Right"],
            textvariable=self.cutter_corner_var, width=12, state="readonly",
        ).pack(side="left", padx=5)
        tk.Label(
            extra_frame,
            text="Dots print in all corners. Cross and L print in the selected corner (use with Odd/Front or Even/Back for duplex finishing).",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"), wraplength=480, justify="left",
        ).pack(anchor="w", pady=(6, 0))

        art_frame = ttk.LabelFrame(tab, text="Artwork", padding=10); art_frame.pack(fill="x", pady=10)
        ttk.Checkbutton(art_frame, text="Remove artwork (create a cut-marks only file)", variable=self.cutter_remove_art_var).pack(anchor="w")
        self._build_step_commit_buttons(tab, "Cutter Marks", "➕ Add Cutter Marks").pack(fill="x", side="bottom", pady=10)

    def build_rotate_tab(self):
        tab = ttk.Frame(self.tab_content_frame, padding=15); self.tabs["Rotate"] = tab
        rot_frame = ttk.LabelFrame(tab, text="Rotate Pages Control", padding=12); rot_frame.pack(fill="x", pady=5)
        rot_row = ttk.Frame(rot_frame); rot_row.pack(fill="x")
        tk.Entry(rot_row, textvariable=self.rotate_deg_var, width=8, justify="center", bg=self.color_pale).pack(side="left")
        tk.Label(rot_row, text="degrees", bg=self.color_white, fg=self.color_navy).pack(side="left", padx=5)
        tk.Label(rot_frame, text="Pages Selector Filter: ", bg=self.color_white, fg=self.color_navy).pack(anchor="w", pady=(4,0))
        
        pages_entry = tk.Entry(rot_frame, textvariable=self.rotate_pages_var, bg=self.color_pale)
        pages_entry.pack(fill="x", pady=2)
        ToolTip(pages_entry, "all, odd/front, even/back, or pages like 1,3,5 or 1-4", self)
        self._add_page_target_row(rot_frame, self.rotate_pages_var)
        tk.Label(
            rot_frame,
            text="90° and 270° swap the page width and height so the sheet actually turns. Odd = fronts, Even = backs.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"), wraplength=480, justify="left",
        ).pack(anchor="w", pady=(6, 0))

        self._build_step_commit_buttons(rot_frame, "Rotate Pages", "➕ Add Rotation Step").pack(fill="x", pady=8)

    def build_join_split_tab(self):
        tab = ttk.Frame(self.tab_content_frame, padding=15)
        self.tabs["JoinSplit"] = tab
        tk.Label(
            tab,
            text="Join combines every file in Assets into one PDF so later steps run on that file. Split writes one PDF per page, with the page number in the name.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 9, "italic"),
            wraplength=480, justify="left",
        ).pack(anchor="w", pady=(0, 8))

        mode_frame = ttk.LabelFrame(tab, text="Mode", padding=10)
        mode_frame.pack(fill="x", pady=5)
        join_rb = ttk.Radiobutton(
            mode_frame, text="Join", variable=self.join_split_mode_var, value="join",
            command=self._sync_join_split_pane,
        )
        split_rb = ttk.Radiobutton(
            mode_frame, text="Split", variable=self.join_split_mode_var, value="split",
            command=self._sync_join_split_pane,
        )
        join_rb.pack(anchor="w", pady=2)
        split_rb.pack(anchor="w", pady=2)
        ToolTip(join_rb, "Join every file in Assets into one PDF.\nLater steps in the stack run on that combined file.", self)
        ToolTip(split_rb, "Split every file in Assets into one-page PDFs.\nThe page number is added to the name, such as card_p1.pdf.", self)

        self._join_opts_frame = ttk.LabelFrame(tab, text="Joined file name", padding=10)
        first_rb = ttk.Radiobutton(
            self._join_opts_frame, text="Combined + first file name",
            variable=self.join_name_var, value="first_file", command=self._refresh_join_split_example,
        )
        when_rb = ttk.Radiobutton(
            self._join_opts_frame, text="Combined + date and time",
            variable=self.join_name_var, value="datetime", command=self._refresh_join_split_example,
        )
        first_rb.pack(anchor="w", pady=2)
        when_rb.pack(anchor="w", pady=2)
        ToolTip(first_rb, "Save one PDF named Combined plus the first file in Assets.\nExample: Combined_card.pdf. A source file is not overwritten.", self)
        ToolTip(when_rb, "Save one PDF named Combined plus the date and time of the save.\nExample: Combined_2026-10-07_134522.pdf.", self)

        self._split_opts_frame = ttk.LabelFrame(tab, text="Split file name", padding=10)
        tk.Label(
            self._split_opts_frame,
            text="Each page is its own PDF. The page number is added to the file name. Steps above Split in the stack run first.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"),
            wraplength=460, justify="left",
        ).pack(anchor="w", pady=(0, 4))
        ToolTip(self._split_opts_frame, "card.pdf becomes card_p1.pdf, card_p2.pdf, and so on.\nA source file is not overwritten.", self)

        example = tk.Label(
            tab, textvariable=self.join_split_example_var,
            bg=self.color_pale, fg=self.color_navy, font=("Arial", 9, "bold"),
            anchor="w", padx=8, pady=6,
        )
        example.pack(fill="x", pady=(8, 4))
        self._join_split_example_label = example
        ToolTip(example, "This is the file name Build & Save and a hot folder will write.\nAdding the step does not ask for a file.", self)

        commit_host = tk.Frame(tab, bg=self.color_white)
        commit_host.pack(fill="x", side="bottom", pady=10)
        self._join_commit_wrap = self._build_step_commit_buttons(commit_host, "Join PDFs", "➕ Add Join Step")
        self._split_commit_wrap = self._build_step_commit_buttons(commit_host, "Split PDFs", "➕ Add Split Step")
        self._sync_join_split_pane()

    def _sync_join_split_pane(self):
        mode = self.join_split_mode_var.get() if hasattr(self, "join_split_mode_var") else "join"
        join_opts = getattr(self, "_join_opts_frame", None)
        split_opts = getattr(self, "_split_opts_frame", None)
        join_btns = getattr(self, "_join_commit_wrap", None)
        split_btns = getattr(self, "_split_commit_wrap", None)

        example = getattr(self, "_join_split_example_label", None)

        def _show(widget, show, before=None):
            if widget is None:
                return
            try:
                if not widget.winfo_exists():
                    return
            except Exception:
                return
            if show:
                if not widget.winfo_ismapped():
                    kwargs = {"fill": "x", "pady": (0, 4)}
                    if before is not None:
                        try:
                            if before.winfo_exists():
                                kwargs["before"] = before
                        except Exception:
                            pass
                    widget.pack(**kwargs)
            elif widget.winfo_ismapped():
                widget.pack_forget()

        _show(join_opts, mode != "split", example)
        _show(split_opts, mode == "split", example)
        _show(join_btns, mode != "split")
        _show(split_btns, mode == "split")
        self._refresh_join_split_example()
        if not getattr(self, "_loading_form", False):
            self._sync_step_commit_buttons()

    def _refresh_join_split_example(self):
        label = getattr(self, "join_split_example_var", None)
        if label is None:
            return
        sample = "card"
        files = getattr(self, "files", None) or []
        if files:
            sample = os.path.splitext(os.path.basename(files[0]))[0] or "card"
        mode = self.join_split_mode_var.get() if hasattr(self, "join_split_mode_var") else "join"
        if mode == "split":
            name = split_page_stem(sample, 1) + ".pdf"
        elif self.join_name_var.get() == "datetime":
            name = join_output_stem("datetime", sample) + ".pdf"
        else:
            name = join_output_stem("first_file", sample) + ".pdf"
        label.set(f"Example: {name}")

    def _viewed_steps(self):
        if self.active_history_index == -1:
            return list(self.action_queue)
        return list(self.action_queue[:self.active_history_index + 1])

    def _join_in_viewed_steps(self):
        return any(step.get("type") == "Join PDFs" for step in self._viewed_steps())

    def build_folds_tab(self):
        main_frame = ttk.Frame(self.tab_content_frame)
        self.tabs["Folds"] = main_frame
        tab = ttk.Frame(main_frame, padding=10)
        tab.pack(fill="x", expand=False)

        tk.Label(
            tab,
            text="Visual fold guide only. Guidelines draw on the Real-Time Monitor. Export is a die-line proof, not a production PDF.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 9, "italic"), wraplength=460, justify="left",
        ).pack(anchor="w", pady=(0, 8))

        type_f = ttk.LabelFrame(tab, text="Fold type", padding=8)
        type_f.pack(fill="x", pady=4)
        names = [item[1] for item in FOLD_TYPES]
        self.fold_name_var = tk.StringVar(value="Tri-fold Brochure")
        combo = ttk.Combobox(type_f, values=names, textvariable=self.fold_name_var, state="readonly")
        combo.pack(fill="x")
        combo.bind("<<ComboboxSelected>>", self._on_fold_type_chosen)
        tk.Label(
            type_f, textvariable=self.fold_desc_var, bg=self.color_white, fg=self.color_navy,
            font=("Arial", 8), wraplength=440, justify="left",
        ).pack(anchor="w", pady=(6, 0))

        paper_f = ttk.LabelFrame(tab, text="Finished flat size (trim)", padding=8)
        paper_f.pack(fill="x", pady=6)
        self.fold_combo = ttk.Combobox(paper_f, values=[], textvariable=self.fold_preset_var, width=18, state="readonly")
        self.fold_combo.grid(row=0, column=0, columnspan=3, sticky="w", pady=(0, 4))
        self.fold_combo.bind("<<ComboboxSelected>>", lambda e: self.handle_fold_preset())
        tk.Label(paper_f, text="Width", bg=self.color_white, fg=self.color_navy).grid(row=1, column=0, sticky="w")
        tk.Entry(paper_f, textvariable=self.fold_w_var, width=8, bg=self.color_pale).grid(row=1, column=1, sticky="w", padx=4)
        tk.Label(paper_f, text="Height", bg=self.color_white, fg=self.color_navy).grid(row=2, column=0, sticky="w", pady=(4, 0))
        tk.Entry(paper_f, textvariable=self.fold_h_var, width=8, bg=self.color_pale).grid(row=2, column=1, sticky="w", padx=4, pady=(4, 0))
        ttk.Checkbutton(paper_f, text="Landscape (swap width / height)", variable=self.fold_landscape_var, command=self._refresh_fold_preview).grid(row=3, column=0, columnspan=3, sticky="w", pady=(6, 0))
        ttk.Checkbutton(paper_f, text="Match loaded PDF page size", variable=self.fold_use_pdf_size_var, command=self._on_fold_use_pdf).grid(row=4, column=0, columnspan=3, sticky="w")

        bleed_f = ttk.LabelFrame(tab, text="Bleed", padding=8)
        bleed_f.pack(fill="x", pady=6)
        row_b = tk.Frame(bleed_f, bg=self.color_white)
        row_b.pack(fill="x")
        tk.Label(row_b, text="Each side:", bg=self.color_white, fg=self.color_navy).pack(side="left")
        tk.Entry(row_b, textvariable=self.fold_bleed_var, width=8, bg=self.color_pale).pack(side="left", padx=6)
        ttk.Checkbutton(
            bleed_f, text="Artwork already includes this bleed (inset guides from the page edge)",
            variable=self.fold_art_has_bleed_var, command=self._refresh_fold_preview,
        ).pack(anchor="w", pady=(6, 0))
        tk.Label(
            bleed_f,
            text="Fold lines sit on the trim. If the PDF is the die (trim + bleed), keep the checkbox on so panels are measured inside the bleed.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"), wraplength=440, justify="left",
        ).pack(anchor="w", pady=(4, 0))

        axis_f = ttk.LabelFrame(tab, text="Fold direction", padding=8)
        axis_f.pack(fill="x", pady=6)
        ttk.Radiobutton(axis_f, text="Along the width (vertical fold lines)", variable=self.fold_along_var, value="width", command=self._refresh_fold_preview).pack(anchor="w")
        ttk.Radiobutton(axis_f, text="Along the height (horizontal fold lines)", variable=self.fold_along_var, value="height", command=self._refresh_fold_preview).pack(anchor="w")

        tk.Label(
            tab, textvariable=self.fold_summary_var, bg=self.color_pale, fg=self.color_navy,
            font=("Arial", 9, "bold"), wraplength=440, justify="left", padx=6, pady=6,
        ).pack(fill="x", pady=6)

        self._create_btn(
            tab, "📄 Export Die-Line Proof…", self.color_lime, self.color_navy, self.export_fold_dielines,
        ).pack(fill="x", pady=(8, 4))
        tk.Label(
            tab,
            text="The original PDF is unchanged. This proof is trim, bleed, and fold marks only.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"), wraplength=440, justify="left",
        ).pack(anchor="w")
        self._on_fold_type_chosen()

    def _on_fold_type_chosen(self, event=None):
        name = self.fold_name_var.get()
        for key, label, desc in FOLD_TYPES:
            if label == name:
                self.fold_type_var.set(key)
                self.fold_desc_var.set(desc)
                break
        self._refresh_fold_preview()

    def handle_fold_preset(self):
        val = self.fold_preset_var.get()
        if val == "Use current PDF":
            self.fold_use_pdf_size_var.set(True)
            self._sync_fold_from_pdf()
        elif val in self.custom_sizes:
            self.fold_use_pdf_size_var.set(False)
            c = self.custom_sizes[val]
            self.fold_w_var.set(str(c.get("w") or f"{self.points_to_global_unit(c.get('w_pt', 0)):.3f}"))
            self.fold_h_var.set(str(c.get("h") or f"{self.points_to_global_unit(c.get('h_pt', 0)):.3f}"))
        else:
            self.fold_use_pdf_size_var.set(False)
            if val == "Letter":
                self.populate_standard_size(8.5, 11, self.fold_w_var, self.fold_h_var)
            elif val == "Legal":
                self.populate_standard_size(8.5, 14, self.fold_w_var, self.fold_h_var)
            elif val == "Tabloid":
                self.populate_standard_size(11, 17, self.fold_w_var, self.fold_h_var)
            elif val == "A4":
                self.populate_standard_size(8.27, 11.69, self.fold_w_var, self.fold_h_var)
        self._refresh_fold_preview()

    def _on_fold_use_pdf(self):
        if self.fold_use_pdf_size_var.get():
            self.fold_preset_var.set("Use current PDF")
            self._sync_fold_from_pdf()
        self._refresh_fold_preview()

    def _sync_fold_from_pdf(self):
        rect = None
        if self.preview_doc and len(self.preview_doc) > 0:
            idx = min(max(self.current_preview_page, 0), len(self.preview_doc) - 1)
            rect = self.preview_doc[idx].rect
        elif self.files:
            try:
                doc = pdfdoc.open(self.files[self.current_preview_file_index])
                rect = doc[0].rect
                doc.close()
            except Exception:
                rect = None
        if rect is None:
            return
        w, h = rect.width, rect.height
        bleed = self.to_points(self.fold_bleed_var.get()) if self.fold_art_has_bleed_var.get() else 0.0
        trim_w = max(w - 2 * bleed, 2.0)
        trim_h = max(h - 2 * bleed, 2.0)
        self.fold_landscape_var.set(trim_w >= trim_h)
        self.fold_w_var.set(f"{self.points_to_global_unit(trim_w):.3f}")
        self.fold_h_var.set(f"{self.points_to_global_unit(trim_h):.3f}")

    def _fold_trim_points(self):
        w = self.to_points(self.fold_w_var.get())
        h = self.to_points(self.fold_h_var.get())
        if self.fold_landscape_var.get() and w < h:
            w, h = h, w
        elif (not self.fold_landscape_var.get()) and h < w:
            w, h = h, w
        return max(w, 2.0), max(h, 2.0)

    def _current_fold_layout(self, page_w=None, page_h=None):
        bleed = max(self.to_points(self.fold_bleed_var.get()), 0.0)
        if page_w and page_h:
            if self.fold_art_has_bleed_var.get():
                trim_w = max(page_w - 2 * bleed, 2.0)
                trim_h = max(page_h - 2 * bleed, 2.0)
            else:
                trim_w, trim_h = page_w, page_h
                bleed = 0.0
        else:
            trim_w, trim_h = self._fold_trim_points()
        return compute_fold_layout(
            self.fold_type_var.get(), trim_w, trim_h, bleed=bleed,
            fold_along=self.fold_along_var.get(), nest_pt=FOLD_NEST_PT,
        )

    def _refresh_fold_preview(self, *args):
        try:
            layout = self._current_fold_layout()
        except Exception:
            return
        unit = self.global_unit_var.get()
        label = "in" if unit == "inches" else "mm" if unit == "mm" else "pt"
        parts = [self.points_to_global_unit(p) for p in layout.get("parts") or []]
        part_txt = "  |  ".join(f"{p:.3f}" for p in parts)
        die_w = self.points_to_global_unit(layout["sheet_w"])
        die_h = self.points_to_global_unit(layout["sheet_h"])
        self.fold_summary_var.set(
            f"Trim panels: {part_txt} {label}\nDie (trim + bleed): {die_w:.3f} × {die_h:.3f} {label}"
        )
        if getattr(self, "current_active_tab", "") != "Folds":
            return
        if getattr(self, "preview_img_w", 0):
            self.draw_fold_overlays()
        else:
            self.render_live_preview()

    def export_fold_dielines(self):
        layout = self._current_fold_layout()
        name = self.fold_name_var.get() or "Fold"
        path = filedialog.asksaveasfilename(
            title="Save die-line proof",
            defaultextension=".pdf",
            initialfile=f"{name.replace(' ', '_')}_dielines.pdf",
            filetypes=[("PDF Files", "*.pdf")],
        )
        if not path:
            return
        title = f"{name}  |  die-line proof (not for press)"
        doc = build_fold_proof_doc(layout, title=title)
        try:
            doc.save(path, garbage=4, deflate=True)
            messagebox.showinfo("Die-line proof", f"Saved fold guides only (not a production file):\n{path}")
        except Exception as e:
            messagebox.showerror("Save failed", str(e))
        finally:
            doc.close()

    def build_vdp_tab(self):
        main_frame = tk.Frame(self.tab_content_frame, bg=self.color_white)
        self.tabs["VDP"] = main_frame

        csv_frame = ttk.LabelFrame(main_frame, text="1. Spreadsheet / Record Count", padding=8)
        csv_frame.pack(fill="x", padx=8, pady=(8, 4))
        r1 = tk.Frame(csv_frame, bg=self.color_white); r1.pack(fill="x", pady=2)
        tk.Label(r1, text="Spreadsheet:", bg=self.color_white, fg=self.color_navy, width=14, anchor="w").pack(side="left")
        tk.Entry(r1, textvariable=self.vdp_csv_path_var, bg=self.color_pale, state="readonly").pack(side="left", fill="x", expand=True, padx=(0, 5))
        self._create_btn(r1, "Browse", self.color_mint, self.color_navy, self.load_vdp_csv).pack(side="left")
        self._create_btn(
            r1, "Reload", self.color_mint, self.color_navy, self.reload_vdp_spreadsheet,
            tooltip="Reloads the current spreadsheet without opening the file window.",
        ).pack(side="left", padx=(4, 0))
        self._create_btn(r1, "Clear", self.color_pale, self.color_navy, self.clear_vdp_spreadsheet).pack(side="left", padx=(4, 0))
        r2 = tk.Frame(csv_frame, bg=self.color_white); r2.pack(fill="x", pady=2)
        tk.Label(r2, text="If no file, generate:", bg=self.color_white, fg=self.color_navy, width=14, anchor="w").pack(side="left")
        tk.Entry(r2, textvariable=self.vdp_generate_count_var, width=6, bg=self.color_pale).pack(side="left")
        tk.Label(r2, text="records    Header columns appear as tags. ODS, XLSX, and CSV are supported. The footer count (e.g. 108 rows) is live data, not an error.", bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic")).pack(side="left", padx=6)

        style_frame = ttk.LabelFrame(main_frame, text="2. Field Style (applied when you place a tag)", padding=8)
        style_frame.pack(fill="x", padx=8, pady=4)
        r_type = tk.Frame(style_frame, bg=self.color_white); r_type.pack(fill="x", pady=2)
        ttk.Radiobutton(r_type, text="Column", variable=self.vdp_source_type_var, value="column").pack(side="left", padx=(0, 4))
        self.vdp_header_combo = ttk.Combobox(r_type, textvariable=self.vdp_col_var, state="readonly", width=16)
        self.vdp_header_combo.pack(side="left", padx=4)
        self.vdp_header_combo.bind("<<ComboboxSelected>>", lambda e: self.select_vdp_sidebar_field(self.vdp_col_var.get()))
        ttk.Radiobutton(r_type, text="Static / [NUM]", variable=self.vdp_source_type_var, value="custom").pack(side="left", padx=(12, 4))
        tk.Entry(r_type, textvariable=self.vdp_custom_text_var, width=16, bg=self.color_pale).pack(side="left", padx=2)
        tk.Label(r_type, text="Start:", bg=self.color_white, fg=self.color_navy).pack(side="left")
        tk.Entry(r_type, textvariable=self.vdp_num_start_var, width=4, bg=self.color_pale).pack(side="left", padx=2)
        tk.Label(r_type, text="Zeros:", bg=self.color_white, fg=self.color_navy).pack(side="left")
        tk.Entry(r_type, textvariable=self.vdp_num_pad_var, width=3, bg=self.color_pale).pack(side="left", padx=2)
        ttk.Combobox(r_type, values=["Text", "QR Code", "HTML"], textvariable=self.vdp_type_var, state="readonly", width=8).pack(side="left", padx=8)
        self._create_btn(
            r_type, "Address Block…", self.color_mint, self.color_navy,
            self.open_address_block_setup, compact=True,
            tooltip="Compose name, street, and City, ST  ZIP as one object",
        ).pack(side="left", padx=(12, 0))

        r_fmt = tk.Frame(style_frame, bg=self.color_white); r_fmt.pack(fill="x", pady=4)
        local_fonts = list(tkfont.families()); local_fonts.sort()
        ttk.Combobox(r_fmt, values=local_fonts, textvariable=self.vdp_font_var, state="readonly", width=16).pack(side="left")
        tk.Label(r_fmt, text="Size", bg=self.color_white, fg=self.color_navy).pack(side="left", padx=(8, 2))
        tk.Entry(r_fmt, textvariable=self.vdp_size_var, width=4, bg=self.color_pale).pack(side="left")
        ttk.Combobox(r_fmt, values=["Left", "Center", "Right"], textvariable=self.vdp_align_var, state="readonly", width=7).pack(side="left", padx=6)
        tk.Entry(r_fmt, textvariable=self.vdp_color_var, width=8, bg=self.color_pale).pack(side="left")
        ttk.Checkbutton(r_fmt, text="B", variable=self.vdp_bold_var).pack(side="left", padx=(8, 0))
        ttk.Checkbutton(r_fmt, text="I", variable=self.vdp_italic_var).pack(side="left")
        ttk.Checkbutton(r_fmt, text="U", variable=self.vdp_underline_var).pack(side="left")
        tk.Label(r_fmt, text="Rotate", bg=self.color_white, fg=self.color_navy).pack(side="left", padx=(8, 2))
        rotate_combo = ttk.Combobox(
            r_fmt, values=["0", "90", "180", "270"], textvariable=self.vdp_rotate_var, width=5,
        )
        rotate_combo.pack(side="left")
        ToolTip(
            rotate_combo,
            "Clockwise degrees for this field. 0 is upright. 90 reads top to bottom. 270 reads bottom to top. You can type another angle.",
            self,
        )
        tk.Label(r_fmt, textvariable=self.vdp_unit_label_var, bg=self.color_white, fg=self.color_steel, width=4, anchor="e").pack(side="left", padx=(10, 0))
        tk.Label(r_fmt, text="X", bg=self.color_white, fg=self.color_navy).pack(side="left", padx=(4, 2))
        tk.Entry(r_fmt, textvariable=self.vdp_x_var, width=6, bg=self.color_pale).pack(side="left")
        tk.Label(r_fmt, text="Y", bg=self.color_white, fg=self.color_navy).pack(side="left", padx=(6, 2))
        tk.Entry(r_fmt, textvariable=self.vdp_y_var, width=6, bg=self.color_pale).pack(side="left")
        tk.Label(r_fmt, text="W", bg=self.color_white, fg=self.color_navy).pack(side="left", padx=(6, 2))
        tk.Entry(r_fmt, textvariable=self.vdp_w_var, width=6, bg=self.color_pale).pack(side="left")
        tk.Label(r_fmt, text="H", bg=self.color_white, fg=self.color_navy).pack(side="left", padx=(6, 2))
        tk.Entry(r_fmt, textvariable=self.vdp_h_var, width=6, bg=self.color_pale).pack(side="left")
        cb_shrink = ttk.Checkbutton(r_fmt, text="Auto-shrink", variable=self.vdp_autoscale_var)
        cb_shrink.pack(side="left", padx=8)
        ToolTip(cb_shrink, "If the line is longer than the box, the preview/export shrinks the type to fit. On by default so 12 pt text still prints in a 6 mm window.", self)

        editor = tk.Frame(main_frame, bg=self.color_white)

        sidebar = ttk.LabelFrame(editor, text="Field Tags", padding=6)
        sidebar.pack(side="left", fill="y", padx=(0, 6))
        self.vdp_sidebar_canvas = tk.Canvas(sidebar, bg=self.color_pale, highlightthickness=0, width=176)
        sb_scroll = ttk.Scrollbar(sidebar, orient="vertical", command=self.vdp_sidebar_canvas.yview)
        self.vdp_field_list_inner = tk.Frame(self.vdp_sidebar_canvas, bg=self.color_pale)
        self.vdp_field_list_inner.bind("<Configure>", lambda e: self.vdp_sidebar_canvas.configure(scrollregion=self.vdp_sidebar_canvas.bbox("all")))
        self.vdp_sidebar_window = self.vdp_sidebar_canvas.create_window((0, 0), window=self.vdp_field_list_inner, anchor="nw")
        self.vdp_sidebar_canvas.configure(yscrollcommand=sb_scroll.set)
        placed = ttk.LabelFrame(sidebar, text="Placed fields", padding=4)
        placed.pack(side="bottom", fill="x", pady=(8, 0))
        self.vdp_layer_list = tk.Listbox(placed, height=6, bg=self.color_white, fg=self.color_navy, selectbackground=self.color_steel, relief="flat", font=("Arial", 8))
        self.vdp_layer_list.pack(fill="x")
        self.vdp_layer_list.bind("<<ListboxSelect>>", self._on_vdp_layer_select)
        tk.Label(placed, text="Click a row to select. Ctrl+Z undoes place/delete.", bg=self.color_white, fg=self.color_steel, font=("Arial", 7, "italic"), wraplength=160, justify="left").pack(fill="x", pady=(4, 0))
        self.vdp_sidebar_canvas.pack(side="left", fill="both", expand=True)
        sb_scroll.pack(side="right", fill="y")
        self.vdp_sidebar_canvas.bind("<Configure>", lambda e: self.vdp_sidebar_canvas.itemconfigure(self.vdp_sidebar_window, width=e.width))
        self.vdp_sidebar_canvas.bind("<MouseWheel>", self._on_vdp_sidebar_wheel)
        self.vdp_field_list_inner.bind("<MouseWheel>", self._on_vdp_sidebar_wheel)

        canvas_wrap = ttk.LabelFrame(editor, text="Template Preview — same page as the Real-Time Monitor", padding=4)
        canvas_wrap.pack(side="left", fill="both", expand=True)
        vdp_nav = tk.Frame(canvas_wrap, bg=self.color_white)
        vdp_nav.pack(fill="x", pady=(0, 4))
        self._create_btn(vdp_nav, "◀ Page", self.color_steel, self.color_white, lambda: self.navigate_preview(-1)).pack(side="left")
        tk.Label(vdp_nav, textvariable=self.vdp_page_label_var, bg=self.color_white, fg=self.color_navy, font=("Arial", 10, "bold")).pack(side="left", padx=8)
        self._create_btn(vdp_nav, "Page ▶", self.color_steel, self.color_white, lambda: self.navigate_preview(1)).pack(side="left")
        tk.Label(vdp_nav, text="Scroll to page  ·  drag can hang off the trim  ·  double-click an address block to edit", bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic")).pack(side="left", padx=10)
        self.vdp_canvas = tk.Canvas(canvas_wrap, bg="#1b1638", highlightthickness=0, cursor="arrow")
        self.vdp_canvas.pack(fill="both", expand=True)
        self.vdp_canvas.bind("<Configure>", self._on_vdp_canvas_configure)
        self.vdp_canvas.bind("<ButtonPress-1>", self.on_vdp_canvas_press)
        self.vdp_canvas.bind("<B1-Motion>", self.on_vdp_canvas_drag)
        self.vdp_canvas.bind("<ButtonRelease-1>", self.on_vdp_canvas_release)
        self.vdp_canvas.bind("<Button-3>", self.on_vdp_canvas_right_click)
        self.vdp_canvas.bind("<Double-Button-1>", self.on_vdp_canvas_double_click)
        self.vdp_canvas.bind("<Motion>", self.on_vdp_canvas_motion)
        self.vdp_canvas.bind("<Leave>", lambda e: self._clear_vdp_hover())
        self.vdp_canvas.bind("<Delete>", lambda e: self.remove_vdp_mapping())
        self.vdp_canvas.bind("<BackSpace>", lambda e: self.remove_vdp_mapping())
        self.vdp_canvas.bind("<Control-z>", lambda e: self._vdp_undo())
        self.vdp_canvas.bind("<Control-Z>", lambda e: self._vdp_undo())
        self.vdp_canvas.bind("<MouseWheel>", self._on_vdp_canvas_wheel)

        foot = tk.Frame(main_frame, bg=self.color_white)
        foot.pack(side="bottom", fill="x", padx=8, pady=(2, 8))
        tk.Label(foot, textvariable=self.vdp_hint_var, bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"), anchor="w").pack(side="left", fill="x", expand=True)
        self._create_btn(foot, "✕", self.color_steel, self.color_white, self.remove_vdp_mapping, compact=True, tooltip="Remove selected field tag").pack(side="right", padx=(4, 0))
        add_vdp = self._create_btn(foot, "Add to Stack", self.color_lime, self.color_navy, lambda: self.add_step_to_queue("VDP Mail Merge"), compact=True, tooltip="Add stamp / merge step to the Applied Steps stack")
        add_vdp.pack(side="right", padx=(4, 0))
        ow_vdp = self._create_btn(foot, "Overwrite", self.color_mint, self.color_navy, lambda: self.overwrite_selected_step("VDP Mail Merge"), compact=True, tooltip="Replace the selected VDP step with the current layout")
        ow_vdp.pack(side="right", padx=(4, 0))
        self._register_step_commit_buttons("VDP Mail Merge", ow_vdp, add_vdp)
        self._create_btn(foot, "Preview", self.color_mint, self.color_navy, self.preview_vdp_merge, compact=True, tooltip="Open a low-res preview of merged records").pack(side="right")
        editor.pack(fill="both", expand=True, padx=8, pady=4)
        self.refresh_vdp_field_sidebar()

    def build_unlock_tab(self):
        tab = ttk.Frame(self.tab_content_frame, padding=15)
        self.tabs["Unlock"] = tab
        tk.Label(
            tab,
            text="Clears Print Lock and Edit Lock written by ReadySetPDF. A PDF that will not open until a password is typed stays locked.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 9, "italic"),
            wraplength=480, justify="left",
        ).pack(anchor="w", pady=(0, 8))

        setup_f = ttk.LabelFrame(tab, text="ReadySetPDF master password", padding=10)
        setup_f.pack(fill="x", pady=5)
        pass_row = tk.Frame(setup_f, bg=self.color_white)
        pass_row.pack(fill="x", pady=4)
        tk.Label(pass_row, text="Master password:", bg=self.color_white, fg=self.color_navy, width=16, anchor="w").pack(side="left")
        tk.Entry(pass_row, textvariable=self.unlock_pass_var, bg=self.color_pale).pack(side="left", fill="x", expand=True, padx=5)
        tk.Label(
            setup_f,
            text="Owner password this program writes with those locks. It starts as readysetpdf.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"),
            wraplength=460, justify="left",
        ).pack(anchor="w", pady=(4, 0))
        self._build_step_commit_buttons(setup_f, "Unlock PDF", "➕ Add Unlock Step").pack(fill="x", pady=(8, 0))

        batch = ttk.LabelFrame(tab, text="Folder batch", padding=10)
        batch.pack(fill="x", pady=(12, 5))
        tk.Label(
            batch,
            text="Separate from the Applied Steps stack. card.pdf is written as card_unlocked.pdf.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"),
            wraplength=460, justify="left",
        ).pack(anchor="w", pady=(0, 4))

        def folder_row(label, variable):
            line = tk.Frame(batch, bg=self.color_white)
            line.pack(fill="x", pady=4)
            tk.Label(line, text=label, bg=self.color_white, fg=self.color_navy, width=16, anchor="w").pack(side="left")
            tk.Entry(line, textvariable=variable, bg=self.color_pale).pack(side="left", fill="x", expand=True, padx=5)
            self._create_btn(
                line, "Browse", self.color_mint, self.color_navy,
                lambda var=variable: var.set(filedialog.askdirectory() or var.get()),
                compact=True,
            ).pack(side="left")

        folder_row("Input Folder:", self.unlock_in_var)
        folder_row("Output Folder:", self.unlock_out_var)
        suffix_row = tk.Frame(batch, bg=self.color_white)
        suffix_row.pack(fill="x", pady=4)
        tk.Label(suffix_row, text="Name suffix:", bg=self.color_white, fg=self.color_navy, width=16, anchor="w").pack(side="left")
        tk.Entry(suffix_row, textvariable=self.unlock_suffix_var, bg=self.color_pale).pack(side="left", fill="x", expand=True, padx=5)
        tk.Label(
            batch,
            text="Output name is the original name plus this suffix. _unlocked turns card.pdf into card_unlocked.pdf.",
            bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic"),
            wraplength=460, justify="left",
        ).pack(anchor="w", pady=(2, 0))
        self._create_btn(
            batch, "Strip ReadySetPDF locks in folder", self.color_lime, self.color_navy, self.execute_folder_unlock,
        ).pack(fill="x", pady=(10, 2))

    def execute_folder_unlock(self):
        in_dir = self.unlock_in_var.get().strip()
        out_dir = self.unlock_out_var.get().strip()
        suffix = self.unlock_suffix_var.get().strip()
        password = self.unlock_pass_var.get()
        if not in_dir or not os.path.isdir(in_dir):
            messagebox.showwarning("Unlock", "Choose an input folder.")
            return
        if not out_dir or not os.path.isdir(out_dir):
            messagebox.showwarning("Unlock", "Choose an output folder.")
            return
        same_folder = os.path.normcase(os.path.abspath(in_dir)) == os.path.normcase(os.path.abspath(out_dir))
        if same_folder and not suffix:
            messagebox.showwarning(
                "Unlock",
                "The input folder and the output folder are the same, and the name suffix is empty.\n"
                "ReadySetPDF will not replace the original. Add a suffix or pick a different output folder.",
            )
            return
        try:
            names = os.listdir(in_dir)
        except OSError as exc:
            messagebox.showerror("Unlock", f"Could not open the input folder.\n{exc}")
            return
        pdfs = sorted(name for name in names if name.lower().endswith(".pdf") and os.path.isfile(os.path.join(in_dir, name)))
        if not pdfs:
            messagebox.showinfo("Unlock", "The input folder has no PDF files.")
            return
        limited = False
        if not licensing.allows_multiple_files(self.license_state):
            if len(pdfs) > 1:
                pdfs = pdfs[:1]
                limited = True
        cleared = 0
        written = 0
        errors = []
        for name in pdfs:
            src = os.path.join(in_dir, name)
            stem = os.path.splitext(name)[0]
            dest = os.path.join(out_dir, f"{stem}{suffix}.pdf")
            if os.path.normcase(os.path.abspath(dest)) == os.path.normcase(os.path.abspath(src)):
                errors.append(f"{name}: refusing to replace the original.")
                continue
            try:
                if save_unlocked_copy(src, dest, password):
                    cleared += 1
                written += 1
            except UnlockError as exc:
                errors.append(str(exc))
            except OSError as exc:
                errors.append(f"{name}: {exc}")
            except Exception as exc:
                errors.append(f"{name}: {exc}")
        if written:
            note = f"Cleared ReadySetPDF locks on {cleared} file(s).\nOutput folder:\n{out_dir}"
            if limited:
                note += "\n\nFree includes one file at a time."
            messagebox.showinfo("Unlock", note)
        if limited:
            open_license_dialog(self)
        if errors:
            messagebox.showerror("Unlock", "\n\n".join(errors))

    def extract_spreadsheet_headers(self, path):
        headers, _rows = read_spreadsheet(path)
        return headers

    def load_vdp_csv(self):
        path = filedialog.askopenfilename(filetypes=[
            ("Spreadsheet Files", "*.csv *.xlsx *.ods"),
            ("CSV Files", "*.csv"),
            ("Excel Files", "*.xlsx"),
            ("OpenDocument", "*.ods"),
        ])
        if not path:
            return
        self._apply_vdp_spreadsheet(path)

    def reload_vdp_spreadsheet(self):
        path = (self.vdp_csv_path_var.get() or "").strip()
        if not path:
            messagebox.showinfo("Spreadsheet", "Browse for a spreadsheet first.")
            return
        self._apply_vdp_spreadsheet(path)

    def _apply_vdp_spreadsheet(self, path):
        try:
            if not path or not os.path.isfile(path):
                raise FileNotFoundError(path or "No spreadsheet selected")
            headers = self.extract_spreadsheet_headers(path)
        except Exception as e:
            messagebox.showerror("File Error", f"Could not read headers:\n{e}")
            return
        self.vdp_csv_path_var.set(path)
        self.vdp_headers = headers
        self._vdp_sample_row_cache = None
        self.vdp_header_combo.config(values=self.vdp_headers)
        if self.vdp_headers:
            self.vdp_header_combo.current(0)
            self.select_vdp_sidebar_field(self.vdp_headers[0])
        self.refresh_vdp_field_sidebar()
        self._refresh_vdp_record_hint()

    def clear_vdp_spreadsheet(self):
        self.vdp_csv_path_var.set("")
        self.vdp_headers = []
        self._vdp_sample_row_cache = None
        self.vdp_header_combo.config(values=[])
        self.vdp_header_combo.set("")
        self.vdp_selected_column = None
        self.refresh_vdp_field_sidebar()
        self.vdp_hint_var.set("Spreadsheet cleared. Load a CSV, Excel, or ODS file to populate field tags.")

    def refresh_vdp_field_sidebar(self):
        if not hasattr(self, "vdp_field_list_inner"):
            return
        for child in self.vdp_field_list_inner.winfo_children():
            child.destroy()

        tk.Label(
            self.vdp_field_list_inner,
            text="Click a column tag to arm it, then click the envelope to place. Click a placed box to select (does not add another). Ctrl+Z undoes.",
            bg=self.color_pale, fg=self.color_steel, font=("Arial", 8, "italic"),
            wraplength=160, justify="left",
        ).pack(fill="x", padx=4, pady=(2, 6))

        self._add_vdp_sidebar_tag("Address Block…", source="address_block", special=True)

        if not self.vdp_headers:
            tk.Label(
                self.vdp_field_list_inner,
                text="No columns yet.\nBrowse a CSV, Excel, or ODS file.",
                bg=self.color_pale, fg=self.color_navy, font=("Arial", 9),
                wraplength=160, justify="left",
            ).pack(fill="x", padx=6, pady=8)
        else:
            for header in self.vdp_headers:
                self._add_vdp_sidebar_tag(header, source="column")

        self._add_vdp_sidebar_tag(self.vdp_custom_text_var.get() or "Ticket-[NUM]", source="custom", special=True)

    def _add_vdp_sidebar_tag(self, label, source="column", special=False):
        selected = (
            (source == "custom" and self.vdp_source_type_var.get() == "custom" and not self.vdp_selected_column)
            or (source == "column" and self.vdp_selected_column == label)
            or (source == "address_block" and self.vdp_source_type_var.get() == "address_block")
        )
        bg = self.color_navy if selected else (self.color_mint if not special else self.color_white)
        fg = self.color_lime if selected else self.color_navy
        if source == "address_block":
            text = "✉ Address Block…"
        elif source == "column":
            text = f"<<{label}>>"
        else:
            text = f"<<{label}>>  [NUM]"
        tag = tk.Label(
            self.vdp_field_list_inner, text=text, bg=bg, fg=fg,
            font=("Arial", 9, "bold"), padx=8, pady=6, cursor="hand2",
            wraplength=150, justify="left", relief="flat",
            highlightbackground=self.color_steel, highlightthickness=1,
        )
        tag.pack(fill="x", padx=4, pady=3)
        tag.bind("<MouseWheel>", self._on_vdp_sidebar_wheel)
        if source == "column":
            tag.bind("<Button-1>", lambda e, h=label: self.select_vdp_sidebar_field(h))
        elif source == "address_block":
            tag.bind("<Button-1>", lambda e: self.open_address_block_setup())
        else:
            tag.bind("<Button-1>", lambda e: self.select_vdp_sidebar_field(None, custom=True))

    def select_vdp_sidebar_field(self, header, custom=False, address_block=False):
        if address_block:
            self.vdp_selected_column = None
            self.vdp_source_type_var.set("address_block")
        elif custom:
            self.vdp_selected_column = None
            self.vdp_source_type_var.set("custom")
        else:
            self.vdp_selected_column = header
            self.vdp_source_type_var.set("column")
            self.vdp_col_var.set(header)
        if hasattr(self, "vdp_canvas"):
            self._vdp_place_armed = True
            self.vdp_canvas.config(cursor="crosshair")
            self.vdp_canvas.focus_set()
        self.refresh_vdp_field_sidebar()
        if address_block:
            self.vdp_hint_var.set("Address Block armed — click the template to place it. Or click Use This Block in the dialog to drop it now.")
        else:
            pretty = self.vdp_custom_text_var.get() if custom else header
            self.vdp_hint_var.set(f"Placing <<{pretty}>> — click the template, then drag to reposition.")

    def _on_vdp_sidebar_wheel(self, event):
        if hasattr(self, "vdp_sidebar_canvas"):
            self.vdp_sidebar_canvas.yview_scroll(int(-1 * (event.delta / 120)), "units")

    def _on_vdp_canvas_configure(self, event):
        size = (event.width, event.height)
        if size == getattr(self, "_vdp_canvas_size", None) or event.width < 20 or event.height < 20:
            return
        self._vdp_canvas_size = size
        self.render_vdp_layout_preview()

    def _on_vdp_geometry_change(self, *args):
        if getattr(self, "_vdp_syncing", False) or getattr(self, "_loading_form", False):
            return
        idx = self.vdp_selected_index
        if idx is not None and 0 <= idx < len(self.vdp_mapped_fields):
            field = self.vdp_mapped_fields[idx]
            field["x"] = self.vdp_x_var.get()
            field["y"] = self.vdp_y_var.get()
            field["w"] = self.vdp_w_var.get()
            field["h"] = self.vdp_h_var.get()
            field["font"] = self.vdp_font_var.get()
            field["size"] = self.vdp_size_var.get()
            field["align"] = self.vdp_align_var.get()
            field["color"] = self.vdp_color_var.get()
            field["type"] = self.vdp_type_var.get()
            field["autoscale"] = self.vdp_autoscale_var.get()
            field["bold"] = self.vdp_bold_var.get()
            field["italic"] = self.vdp_italic_var.get()
            field["underline"] = self.vdp_underline_var.get()
            field["rotate"] = self._format_vdp_rotate(self.vdp_rotate_var.get())
            self.draw_vdp_layout_fields()
        self.draw_vdp_overlays()

    def _vdp_page_index(self, page_count=None):
        idx = max(0, int(self.current_preview_page or 0))
        if page_count:
            idx = min(idx, page_count - 1)
        return idx

    def _vdp_field_on_current_page(self, field):
        page_count = len(self.preview_doc) if self.preview_doc else 0
        if page_count <= 0:
            page_count = max(int(self.current_preview_page or 0) + 1, 1)
        return _field_template_page(field, page_count) == self.current_preview_page

    def _sync_vdp_preview_if_open(self):
        if getattr(self, "_syncing_vdp_preview", False):
            return
        if getattr(self, "current_active_tab", "") != "VDP":
            return
        self._syncing_vdp_preview = True
        try:
            self.render_vdp_layout_preview()
        finally:
            self._syncing_vdp_preview = False

    def _on_vdp_canvas_wheel(self, event):
        self.navigate_preview(-1 if event.delta > 0 else 1)

    def _open_vdp_template_page(self):
        if self.preview_doc and len(self.preview_doc) > 0:
            page_index = self._vdp_page_index(len(self.preview_doc))
            return None, self.preview_doc[page_index], False

        if not self.files:
            return None, None, False
        file_idx = self.current_preview_file_index if 0 <= self.current_preview_file_index < len(self.files) else 0
        doc = pdfdoc.open()
        try:
            insert_source_file(
                doc, self.files[file_idx], max_dpi=self._export_max_dpi(),
                owner_password=self._unlock_owner_password(),
            )
            prepare_imported_doc(doc, self.page_box_mode_var.get(), max_dpi=self._export_max_dpi())
            if len(doc) == 0:
                doc.close()
                return None, None, False
            page_index = self._vdp_page_index(len(doc))
            return doc, doc[page_index], True
        except UnlockError:
            try:
                doc.close()
            except Exception:
                pass
            raise
        except Exception:
            try:
                doc.close()
            except Exception:
                pass
            return None, None, False

    def render_vdp_layout_preview(self):
        if not hasattr(self, "vdp_canvas"):
            return
        self.vdp_canvas.delete("all")
        cw = max(self.vdp_canvas.winfo_width(), 1)
        ch = max(self.vdp_canvas.winfo_height(), 1)
        if cw < 20 or ch < 20:
            return

        doc, page, owns_doc = self._open_vdp_template_page()
        total_pages = 0
        if self.preview_doc:
            total_pages = len(self.preview_doc)
        elif doc is not None:
            total_pages = len(doc)
        page_no = self._vdp_page_index(total_pages) + 1 if total_pages else 0
        self.vdp_page_label_var.set(f"Page: {page_no} / {total_pages}")

        if page is None:
            self.vdp_canvas.create_text(
                cw / 2, ch / 2,
                text="Load a PDF (or image) in Assets Manager\nto preview the merge template.",
                fill=self.color_mint, font=("Arial", 11), justify="center",
            )
            return

        try:
            pw, ph = page.rect.width, page.rect.height
            self.vdp_page_size = (pw, ph)
            pad = 28
            scale = min((cw - 2 * pad) / max(pw, 1.0), (ch - 2 * pad) / max(ph, 1.0))
            scale = max(0.08, min(scale, 4.0))
            self.vdp_layout_scale = scale
            source = doc if doc is not None else self.preview_doc
            img = render_page_image(source, page.number, scale, annots=True)
            self.vdp_layout_image = ImageTk.PhotoImage(img)
            ox = (cw - img.width) / 2.0
            oy = (ch - img.height) / 2.0
            self.vdp_layout_origin = (ox, oy)
            self.vdp_canvas.create_rectangle(ox, oy, ox + img.width, oy + img.height, fill="white", outline="")
            self.vdp_canvas.create_image(ox, oy, image=self.vdp_layout_image, anchor="nw", tags="vdp_bg")
            dpi = scale * 72.0
            self.vdp_canvas.create_text(
                ox, oy - 8,
                text=f"Page {page_no} / {total_pages}  ·  {pw:.1f} × {ph:.1f} pt  ·  {dpi:.0f} DPI preview",
                fill=self.color_mint, font=("Arial", 8), anchor="sw", tags="vdp_meta",
            )
            self.draw_vdp_layout_fields()
        finally:
            if owns_doc and doc is not None:
                doc.close()

    def _format_vdp_rotate(self, value):
        try:
            num = float(value or 0) % 360.0
        except (TypeError, ValueError):
            num = 0.0
        if abs(num) < 0.05 or abs(num - 360.0) < 0.05:
            return "0"
        if abs(num - round(num)) < 0.05:
            return str(int(round(num)) % 360)
        return f"{num:.1f}".rstrip("0").rstrip(".")

    def _rotate_offset(self, dx, dy, degrees):
        """Clockwise in canvas space, where y grows downward."""
        rad = math.radians(float(degrees or 0))
        cos_a = math.cos(rad)
        sin_a = math.sin(rad)
        return dx * cos_a - dy * sin_a, dx * sin_a + dy * cos_a

    def _vdp_field_canvas_box(self, field):
        ox, oy = self.vdp_layout_origin
        scale = self.vdp_layout_scale
        x = self.to_points(field.get("x", 0)) * scale
        y = self.to_points(field.get("y", 0)) * scale
        w = max(8.0, self.to_points(field.get("w", 2.0)) * scale)
        h = max(8.0, self.to_points(field.get("h", 0.5)) * scale)
        return ox + x, oy + y, ox + x + w, oy + y + h

    def _vdp_canvas_to_units(self, cx, cy):
        ox, oy = self.vdp_layout_origin
        scale = self.vdp_layout_scale or 1.0
        pdf_x = (cx - ox) / scale
        pdf_y = (cy - oy) / scale
        return self.points_to_global_unit(pdf_x), self.points_to_global_unit(pdf_y)

    def _vdp_field_label(self, field):
        if field.get("source_type") == "address_block":
            return "<<Address Block>>"
        name = field.get("column") or "Field"
        return f"<<{name}>>"

    def draw_vdp_layout_fields(self):
        if not hasattr(self, "vdp_canvas"):
            return
        self.vdp_canvas.delete("vdp_field")
        sample_row = self._vdp_sample_row()
        for idx, field in enumerate(self.vdp_mapped_fields):
            if not self._vdp_field_on_current_page(field):
                continue
            x0, y0, x1, y1 = self._vdp_field_canvas_box(field)
            selected = idx == self.vdp_selected_index
            hover = idx == getattr(self, "_vdp_hover_index", None)
            outline = self.color_lime if selected else ("#e6b800" if hover else "#27ae60")
            width = 3 if selected or hover else 2
            angle = field_rotation(field)
            cx = (x0 + x1) / 2.0
            cy = (y0 + y1) / 2.0
            if angle < 0.5:
                self.vdp_canvas.create_rectangle(
                    x0, y0, x1, y1, outline=outline, width=width, tags=("vdp_field", f"vdp_field_{idx}")
                )
                label_x, label_y = x0, y0
            else:
                corners = []
                for px, py in ((x0, y0), (x1, y0), (x1, y1), (x0, y1)):
                    rx, ry = self._rotate_offset(px - cx, py - cy, angle)
                    corners.extend((cx + rx, cy + ry))
                self.vdp_canvas.create_polygon(
                    corners, outline=outline, width=width, fill="",
                    tags=("vdp_field", f"vdp_field_{idx}"),
                )
                label_x, label_y = corners[0], corners[1]
            label = self._vdp_field_label(field)
            chip_w = min(max(x1 - x0, 24), 8 + len(label) * 7)
            self.vdp_canvas.create_rectangle(
                label_x, label_y, label_x + chip_w, label_y + 16, fill="white", outline=outline, tags=("vdp_field", f"vdp_field_{idx}")
            )
            self.vdp_canvas.create_text(
                label_x + 4, label_y + 8, text=label, fill=outline, anchor="w",
                font=("Arial", 8, "bold"), tags=("vdp_field", f"vdp_field_{idx}")
            )
            if field.get("source_type") == "address_block":
                sample = format_address_block(sample_row, field.get("block") or {})
            elif field.get("source_type") == "custom":
                sample = str(field.get("column") or "")
            else:
                sample = str(sample_row.get(field.get("column", ""), "") or "")
            if sample:
                weight = "bold" if style_on(field.get("bold")) else "normal"
                slant = "italic" if style_on(field.get("italic")) else "roman"
                wrap = (y1 - y0) if abs((angle - 90.0) % 180.0) < 0.5 else (x1 - x0)
                self.vdp_canvas.create_text(
                    cx, cy, text=sample, fill=self.color_navy, anchor="center",
                    angle=-angle, font=("Arial", 8, weight, slant), width=max(24, wrap - 8),
                    tags=("vdp_field", f"vdp_field_{idx}"),
                )
        self._refresh_vdp_layer_list()

    def _hit_vdp_field(self, cx, cy, pad=8):
        for idx in range(len(self.vdp_mapped_fields) - 1, -1, -1):
            field = self.vdp_mapped_fields[idx]
            if not self._vdp_field_on_current_page(field):
                continue
            x0, y0, x1, y1 = self._vdp_field_canvas_box(field)
            angle = field_rotation(field)
            mx, my = (x0 + x1) / 2.0, (y0 + y1) / 2.0
            lx, ly = self._rotate_offset(cx - mx, cy - my, -angle)
            if abs(lx) <= (x1 - x0) / 2.0 + pad and abs(ly) <= (y1 - y0) / 2.0 + pad:
                return idx
        return None

    def _vdp_unit_tag(self, unit=None):
        unit = unit or self.global_unit_var.get()
        return "mm" if unit == "mm" else "pt" if unit == "points" else "in"

    def _refresh_vdp_unit_labels(self):
        self.vdp_unit_label_var.set(self._vdp_unit_tag())

    def _vdp_default_box(self, unit):
        if unit == "mm":
            return "10", "10", "90", "8"
        if unit == "points":
            return "36", "36", "216", "24"
        return "0.5", "0.5", "2.0", "0.5"

    def _apply_vdp_unit_defaults(self, unit, force=False):
        self._vdp_form_unit = unit
        self._refresh_vdp_unit_labels()
        if not force:
            return
        x, y, w, h = self._vdp_default_box(unit)
        self.vdp_x_var.set(x)
        self.vdp_y_var.set(y)
        self.vdp_w_var.set(w)
        self.vdp_h_var.set(h)

    def _convert_one_length(self, value, old_unit, new_unit):
        pt = self.to_points(value, old_unit)
        if new_unit == "mm":
            return f"{(pt / 72.0) * 25.4:.3f}".rstrip("0").rstrip(".")
        if new_unit == "points":
            return f"{pt:.2f}".rstrip("0").rstrip(".")
        return f"{pt / 72.0:.3f}".rstrip("0").rstrip(".")

    def _convert_vdp_field_lengths(self, fields, old_unit, new_unit):
        for field in fields or []:
            for key in ("x", "y", "w", "h"):
                field[key] = self._convert_one_length(field.get(key, "0"), old_unit, new_unit)

    def _sync_vdp_stack_unit(self, new_unit, converted_ids=None):
        converted_ids = converted_ids or set()
        for step in getattr(self, "action_queue", []) or []:
            if step.get("type") != "VDP Mail Merge":
                continue
            params = step.setdefault("params", {})
            old = params.get("unit") or new_unit
            if old != new_unit:
                for field in params.get("fields") or []:
                    if id(field) in converted_ids:
                        continue
                    for key in ("x", "y", "w", "h"):
                        field[key] = self._convert_one_length(field.get(key, "0"), old, new_unit)
                    converted_ids.add(id(field))
            params["unit"] = new_unit

    def _convert_vdp_lengths(self, old_unit, new_unit):
        if not old_unit or old_unit == new_unit:
            return
        prev = getattr(self, "_vdp_syncing", False)
        self._vdp_syncing = True
        try:
            for var in (self.vdp_x_var, self.vdp_y_var, self.vdp_w_var, self.vdp_h_var):
                var.set(self._convert_one_length(var.get(), old_unit, new_unit))
            self._convert_vdp_field_lengths(self.vdp_mapped_fields, old_unit, new_unit)
            self._sync_vdp_stack_unit(new_unit, {id(f) for f in self.vdp_mapped_fields})
        finally:
            self._vdp_syncing = prev

    def _vdp_push_undo(self):
        snapshot = json.loads(json.dumps(self.vdp_mapped_fields))
        self._vdp_undo_stack.append((snapshot, self.vdp_selected_index))
        if len(self._vdp_undo_stack) > 40:
            self._vdp_undo_stack.pop(0)

    def _vdp_undo(self, event=None):
        if not self._vdp_undo_stack:
            return "break"
        fields, idx = self._vdp_undo_stack.pop()
        self.vdp_mapped_fields = fields
        self.vdp_selected_index = idx if idx is not None and 0 <= (idx or 0) < len(fields) else (len(fields) - 1 if fields else None)
        if self.vdp_selected_index is not None:
            self._load_vdp_field_into_form(self.vdp_selected_index)
        self.draw_vdp_layout_fields()
        self.draw_vdp_overlays()
        self._refresh_vdp_record_hint()
        return "break"

    def _refresh_vdp_layer_list(self):
        if not hasattr(self, "vdp_layer_list"):
            return
        self.vdp_layer_list.delete(0, tk.END)
        for field in self.vdp_mapped_fields:
            self.vdp_layer_list.insert(tk.END, self._vdp_field_label(field).strip("<>"))
        if self.vdp_selected_index is not None and 0 <= self.vdp_selected_index < len(self.vdp_mapped_fields):
            self.vdp_layer_list.selection_set(self.vdp_selected_index)
            self.vdp_layer_list.see(self.vdp_selected_index)

    def _on_vdp_layer_select(self, event=None):
        if not hasattr(self, "vdp_layer_list"):
            return
        sel = self.vdp_layer_list.curselection()
        if not sel:
            return
        idx = sel[0]
        if idx == self.vdp_selected_index:
            return
        self.vdp_selected_index = idx
        self._load_vdp_field_into_form(idx)
        self.draw_vdp_layout_fields()

    def on_vdp_canvas_motion(self, event):
        cx, cy = self.vdp_canvas.canvasx(event.x), self.vdp_canvas.canvasy(event.y)
        hit = self._hit_vdp_field(cx, cy)
        if hit != getattr(self, "_vdp_hover_index", None):
            self._vdp_hover_index = hit
            self.draw_vdp_layout_fields()
        if hit is not None:
            self.vdp_canvas.config(cursor="hand2")
        elif getattr(self, "_vdp_place_armed", False):
            self.vdp_canvas.config(cursor="crosshair")
        else:
            self.vdp_canvas.config(cursor="arrow")

    def _clear_vdp_hover(self, event=None):
        if getattr(self, "_vdp_hover_index", None) is not None:
            self._vdp_hover_index = None
            self.draw_vdp_layout_fields()

    def _load_vdp_field_into_form(self, idx):
        if not (0 <= idx < len(self.vdp_mapped_fields)):
            return
        field = self.vdp_mapped_fields[idx]
        self._vdp_syncing = True
        try:
            self.vdp_source_type_var.set(field.get("source_type", "column"))
            source_type = field.get("source_type", "column")
            if source_type == "address_block":
                self.vdp_selected_column = None
                self.vdp_address_block = field.get("block")
                self.vdp_address_map = dict(field.get("address_map") or {})
            elif source_type == "custom":
                self.vdp_custom_text_var.set(field.get("column", self.vdp_custom_text_var.get()))
                self.vdp_selected_column = None
            else:
                self.vdp_col_var.set(field.get("column", "") or self.vdp_col_var.get())
                self.vdp_selected_column = field.get("column")
            self.vdp_type_var.set(field.get("type", "Text"))
            self.vdp_x_var.set(str(field.get("x", "0")))
            self.vdp_y_var.set(str(field.get("y", "0")))
            self.vdp_w_var.set(str(field.get("w", "2.0")))
            self.vdp_h_var.set(str(field.get("h", "0.5")))
            self.vdp_font_var.set(field.get("font", self.vdp_font_var.get()))
            self.vdp_size_var.set(str(field.get("size", "12")))
            self.vdp_align_var.set(field.get("align", "Left"))
            self.vdp_color_var.set(field.get("color", "#000000"))
            self.vdp_autoscale_var.set(bool(field.get("autoscale", True)))
            self.vdp_bold_var.set(style_on(field.get("bold")))
            self.vdp_italic_var.set(style_on(field.get("italic")))
            self.vdp_underline_var.set(style_on(field.get("underline")))
            self.vdp_rotate_var.set(self._format_vdp_rotate(field.get("rotate", 0)))
            self.vdp_num_start_var.set(str(field.get("num_start", "1")))
            self.vdp_num_pad_var.set(str(field.get("num_pad", "3")))
        finally:
            self._vdp_syncing = False
        self.refresh_vdp_field_sidebar()

    def _build_vdp_mapping(self, x_u, y_u):
        source_type = self.vdp_source_type_var.get()
        extra = {}
        if source_type == "address_block":
            block = self.vdp_address_block or {}
            if not block.get("lines"):
                return None
            col = "Address Block"
            extra["block"] = json.loads(json.dumps(block))
            extra["address_map"] = dict(self.vdp_address_map or {})
        elif source_type == "column":
            col = self.vdp_selected_column or self.vdp_col_var.get()
            if not col:
                return None
        else:
            col = self.vdp_custom_text_var.get()
            if not col:
                return None
        self.vdp_field_id_seq += 1
        mapping = {
            "id": self.vdp_field_id_seq,
            "source_type": source_type,
            "column": col,
            "num_start": self.vdp_num_start_var.get(),
            "num_pad": self.vdp_num_pad_var.get(),
            "type": self.vdp_type_var.get() if source_type != "address_block" else "Text",
            "x": f"{x_u:.3f}",
            "y": f"{y_u:.3f}",
            "w": self.vdp_w_var.get(),
            "h": self.vdp_h_var.get(),
            "font": self.vdp_font_var.get(),
            "size": self.vdp_size_var.get(),
            "align": self.vdp_align_var.get(),
            "color": self.vdp_color_var.get(),
            "autoscale": self.vdp_autoscale_var.get(),
            "bold": self.vdp_bold_var.get(),
            "italic": self.vdp_italic_var.get(),
            "underline": self.vdp_underline_var.get(),
            "rotate": self._format_vdp_rotate(self.vdp_rotate_var.get()),
            "page": int(self.current_preview_page or 0),
        }
        mapping.update(extra)
        return mapping

    def _place_vdp_field_at_canvas(self, cx, cy):
        if not self.files:
            messagebox.showwarning("No Template", "Load a PDF template in Assets Manager first.")
            return None
        x_u, y_u = self._vdp_canvas_to_units(cx, cy)
        pw, ph = self.vdp_page_size
        x_u = max(0.0, min(x_u, self.points_to_global_unit(pw)))
        y_u = max(0.0, min(y_u, self.points_to_global_unit(ph)))
        mapping = self._build_vdp_mapping(x_u, y_u)
        if mapping is None:
            if self.vdp_source_type_var.get() == "address_block":
                messagebox.showwarning("Address Block", "Open Address Block… and pick the columns first, then click the template.")
            else:
                messagebox.showwarning("Select a Field", "Click a column tag in the sidebar first, then click the template to place it.")
            return None
        self._vdp_push_undo()
        self.vdp_mapped_fields.append(mapping)
        self.vdp_selected_index = len(self.vdp_mapped_fields) - 1
        self._vdp_syncing = True
        try:
            self.vdp_x_var.set(mapping["x"])
            self.vdp_y_var.set(mapping["y"])
        finally:
            self._vdp_syncing = False
        self.draw_vdp_layout_fields()
        self.draw_vdp_overlays()
        self._refresh_vdp_record_hint()
        self._vdp_place_armed = False
        if hasattr(self, "vdp_canvas"):
            self.vdp_canvas.config(cursor="arrow")
        return self.vdp_selected_index

    def _move_vdp_field_to_canvas(self, idx, cx, cy):
        if not (0 <= idx < len(self.vdp_mapped_fields)):
            return
        x_u, y_u = self._vdp_canvas_to_units(cx, cy)
        pw, ph = self.vdp_page_size
        w_u = self.to_points(self.vdp_mapped_fields[idx].get("w", 2.0))
        h_u = self.to_points(self.vdp_mapped_fields[idx].get("h", 0.5))
        handle = 16.0
        pdf_x = self.to_points(f"{x_u:.3f}")
        pdf_y = self.to_points(f"{y_u:.3f}")
        pdf_x = max(-w_u + handle, min(pdf_x, pw - handle))
        pdf_y = max(-h_u + handle, min(pdf_y, ph - handle))
        x_u = self.points_to_global_unit(pdf_x)
        y_u = self.points_to_global_unit(pdf_y)
        self.vdp_mapped_fields[idx]["x"] = f"{x_u:.3f}"
        self.vdp_mapped_fields[idx]["y"] = f"{y_u:.3f}"
        if idx == self.vdp_selected_index:
            self._vdp_syncing = True
            try:
                self.vdp_x_var.set(f"{x_u:.3f}")
                self.vdp_y_var.set(f"{y_u:.3f}")
            finally:
                self._vdp_syncing = False
        self.draw_vdp_layout_fields()

    def on_vdp_canvas_press(self, event):
        self.vdp_canvas.focus_set()
        cx, cy = self.vdp_canvas.canvasx(event.x), self.vdp_canvas.canvasy(event.y)
        hit = self._hit_vdp_field(cx, cy)
        if hit is not None:
            self.vdp_selected_index = hit
            self._load_vdp_field_into_form(hit)
            x0, y0, _, _ = self._vdp_field_canvas_box(self.vdp_mapped_fields[hit])
            self.vdp_drag = {"index": hit, "dx": cx - x0, "dy": cy - y0}
            self._vdp_place_armed = False
            self.vdp_canvas.config(cursor="arrow")
            self.draw_vdp_layout_fields()
            return
        if not getattr(self, "_vdp_place_armed", False):
            self.vdp_selected_index = None
            self.draw_vdp_layout_fields()
            self.vdp_hint_var.set("Click a column tag to arm placement, then click the page. Click a green box to select it.")
            return
        idx = self._place_vdp_field_at_canvas(cx, cy)
        if idx is not None:
            x0, y0, _, _ = self._vdp_field_canvas_box(self.vdp_mapped_fields[idx])
            self.vdp_drag = {"index": idx, "dx": cx - x0, "dy": cy - y0}

    def on_vdp_canvas_drag(self, event):
        if not self.vdp_drag:
            return
        cx, cy = self.vdp_canvas.canvasx(event.x), self.vdp_canvas.canvasy(event.y)
        self._move_vdp_field_to_canvas(self.vdp_drag["index"], cx - self.vdp_drag["dx"], cy - self.vdp_drag["dy"])

    def on_vdp_canvas_release(self, event):
        self.vdp_drag = None
        self.draw_vdp_overlays()

    def on_vdp_canvas_right_click(self, event):
        cx, cy = self.vdp_canvas.canvasx(event.x), self.vdp_canvas.canvasy(event.y)
        hit = self._hit_vdp_field(cx, cy)
        if hit is None:
            return
        self.vdp_selected_index = hit
        self.remove_vdp_mapping()

    def on_vdp_canvas_double_click(self, event):
        cx, cy = self.vdp_canvas.canvasx(event.x), self.vdp_canvas.canvasy(event.y)
        hit = self._hit_vdp_field(cx, cy)
        if hit is None:
            return
        field = self.vdp_mapped_fields[hit]
        if field.get("source_type") == "address_block":
            self.vdp_selected_index = hit
            self._load_vdp_field_into_form(hit)
            self.open_address_block_setup(field_index=hit)

    def _vdp_sample_row(self):
        path = self.vdp_csv_path_var.get()
        cached = getattr(self, "_vdp_sample_row_cache", None)
        if cached and cached.get("path") == path:
            return cached.get("row") or {}
        row = {}
        try:
            rows = load_merge_rows(csv_path=path, generate_count=1, mapped_columns=None)
            row = rows[0] if rows else {}
        except Exception:
            row = {}
        self._vdp_sample_row_cache = {"path": path, "row": row}
        return row

    def open_address_block_setup(self, field_index=None):
        if not self.vdp_headers:
            messagebox.showwarning("Spreadsheet Needed", "Load a CSV or Excel file first so the address block can pick columns.")
            return

        editing = field_index is not None and 0 <= field_index < len(self.vdp_mapped_fields)
        field = self.vdp_mapped_fields[field_index] if editing else None
        guessed = normalize_address_map(guess_address_columns(self.vdp_headers))
        if editing:
            picks = normalize_address_map(field.get("address_map") or guessed)
        elif self.vdp_address_map:
            picks = normalize_address_map(self.vdp_address_map)
        else:
            picks = guessed

        win = tk.Toplevel(self.root)
        win.title("Address Block")
        win.configure(bg=self.color_white)
        win.transient(self.root)
        win.resizable(False, False)
        win.grab_set()

        tk.Label(
            win, text="Build one address object",
            font=("Arial", 13, "bold"), bg=self.color_white, fg=self.color_navy,
        ).pack(anchor="w", padx=16, pady=(14, 2))
        tk.Label(
            win,
            text="Pick spreadsheet columns for each line, then click Use This Block to place it on the template.\nEmpty columns are skipped. City / region / postcode can be any headers (Dutch postcode + woonplaats works).",
            font=("Arial", 9), bg=self.color_white, fg=self.color_steel, justify="left",
        ).pack(anchor="w", padx=16, pady=(0, 10))

        form = tk.Frame(win, bg=self.color_white)
        form.pack(fill="x", padx=16)
        form.columnconfigure(1, weight=1)
        choices = [""] + list(self.vdp_headers)
        field_vars = []

        def combo_value(value):
            return value if value in self.vdp_headers else ""

        for i in range(ADDRESS_BLOCK_FIELD_COUNT):
            tk.Label(
                form, text=f"Field {i + 1}", bg=self.color_white, fg=self.color_navy,
                width=12, anchor="w",
            ).grid(row=i, column=0, sticky="w", pady=3)
            var = tk.StringVar(value=combo_value((picks.get("fields") or [])[i] if i < len(picks.get("fields") or []) else ""))
            field_vars.append(var)
            ttk.Combobox(form, textvariable=var, values=choices, state="readonly", width=36).grid(
                row=i, column=1, sticky="ew", pady=3, padx=(6, 0)
            )

        city_row = ADDRESS_BLOCK_FIELD_COUNT
        tk.Label(
            form, text="City / ZIP", bg=self.color_white, fg=self.color_navy,
            width=12, anchor="w",
        ).grid(row=city_row, column=0, sticky="w", pady=(10, 3))
        csz = tk.Frame(form, bg=self.color_white)
        csz.grid(row=city_row, column=1, sticky="ew", pady=(10, 3), padx=(6, 0))
        city_var = tk.StringVar(value=combo_value(picks.get("city", "")))
        state_var = tk.StringVar(value=combo_value(picks.get("state", "")))
        zip_var = tk.StringVar(value=combo_value(picks.get("zip", "")))
        ttk.Combobox(csz, textvariable=city_var, values=choices, state="readonly", width=16).pack(side="left", fill="x", expand=True)
        ttk.Combobox(csz, textvariable=state_var, values=choices, state="readonly", width=8).pack(side="left", padx=4)
        ttk.Combobox(csz, textvariable=zip_var, values=choices, state="readonly", width=10).pack(side="left")

        preview_var = tk.StringVar()
        preview_box = tk.Label(
            win, textvariable=preview_var, bg=self.color_pale, fg=self.color_navy,
            font=("Arial", 10), justify="left", anchor="nw", relief="flat",
            highlightbackground=self.color_steel, highlightthickness=1,
            padx=10, pady=8, width=46, height=6,
        )
        preview_box.pack(fill="x", padx=16, pady=(12, 8))

        def current_picks():
            return {
                "fields": [var.get().strip() for var in field_vars],
                "city": city_var.get().strip(),
                "state": state_var.get().strip(),
                "zip": zip_var.get().strip(),
            }

        def current_spec():
            p = current_picks()
            return build_address_block_spec(
                fields=p["fields"],
                city=p["city"],
                state=p["state"],
                zip_code=p["zip"],
            )

        def refresh_preview(*_args):
            sample = format_address_block(self._vdp_sample_row(), current_spec())
            preview_var.set(sample or "(empty — pick columns above)")

        for var in field_vars + [city_var, state_var, zip_var]:
            var.trace_add("write", refresh_preview)
        refresh_preview()

        btn_row = tk.Frame(win, bg=self.color_white)
        btn_row.pack(fill="x", padx=16, pady=(4, 16))

        def confirm():
            spec = current_spec()
            if not spec.get("lines"):
                messagebox.showwarning("Address Block", "Pick at least one column for the address block.", parent=win)
                return
            self.vdp_address_block = spec
            self.vdp_address_map = current_picks()
            if editing:
                field["source_type"] = "address_block"
                field["column"] = "Address Block"
                field["type"] = "Text"
                field["block"] = json.loads(json.dumps(spec))
                field["address_map"] = dict(self.vdp_address_map)
                self.vdp_selected_index = field_index
                self._load_vdp_field_into_form(field_index)
                self.draw_vdp_layout_fields()
                self.draw_vdp_overlays()
                win.destroy()
                return
            try:
                unit = self.global_unit_var.get()
                h_now = self.parse_locale_number(self.vdp_h_var.get()) or 0
                w_now = self.parse_locale_number(self.vdp_w_var.get()) or 0
                if unit == "mm":
                    if h_now < 16:
                        self.vdp_h_var.set("28")
                    if w_now < 40:
                        self.vdp_w_var.set("90")
                elif unit == "points":
                    if h_now < 48:
                        self.vdp_h_var.set("80")
                    if w_now < 120:
                        self.vdp_w_var.set("260")
                else:
                    if h_now <= 0.6:
                        self.vdp_h_var.set("1.25")
                    if w_now <= 2.1:
                        self.vdp_w_var.set("3.25")
            except ValueError:
                pass
            self.select_vdp_sidebar_field(None, address_block=True)
            x_u = self.parse_locale_number(self.vdp_x_var.get()) or 0
            y_u = self.parse_locale_number(self.vdp_y_var.get()) or 0
            mapping = self._build_vdp_mapping(x_u, y_u)
            if mapping:
                self._vdp_push_undo()
                self.vdp_mapped_fields.append(mapping)
                self.vdp_selected_index = len(self.vdp_mapped_fields) - 1
                self._load_vdp_field_into_form(self.vdp_selected_index)
                self.draw_vdp_layout_fields()
                self.draw_vdp_overlays()
                self._refresh_vdp_record_hint()
                self._vdp_place_armed = False
                if hasattr(self, "vdp_canvas"):
                    self.vdp_canvas.config(cursor="arrow")
            win.destroy()
            return

        confirm_label = "Update Block" if editing else "Use This Block"
        self._create_btn(btn_row, confirm_label, self.color_lime, self.color_navy, confirm, compact=True).pack(side="right")
        self._create_btn(btn_row, "Cancel", self.color_steel, self.color_white, win.destroy, compact=True).pack(side="right", padx=(0, 8))
        win.update_idletasks()
        win.geometry(f"+{self.root.winfo_rootx() + 80}+{self.root.winfo_rooty() + 80}")

    def activate_target_mode(self):
        if not self.preview_doc:
            messagebox.showwarning("No Document", "Load a PDF first to target coordinates.")
            return
        self.vdp_target_mode = True
        self.root.config(cursor="crosshair")

    def on_canvas_click(self, event):
        if getattr(self, "vdp_target_mode", False) and self.preview_doc:
            x_scroll = self.preview_canvas.canvasx(0)
            y_scroll = self.preview_canvas.canvasy(0)
            actual_x = event.x + x_scroll
            actual_y = event.y + y_scroll
            img_x_start = self.preview_pos_x - (self.preview_img_w / 2.0)
            img_y_start = self.preview_pos_y - (self.preview_img_h / 2.0)
            click_img_x = actual_x - img_x_start
            click_img_y = actual_y - img_y_start
            if 0 <= click_img_x <= self.preview_img_w and 0 <= click_img_y <= self.preview_img_h:
                pdf_x = click_img_x / self.preview_final_scale
                pdf_y = click_img_y / self.preview_final_scale
                self.vdp_x_var.set(f"{self.points_to_global_unit(pdf_x):.3f}")
                self.vdp_y_var.set(f"{self.points_to_global_unit(pdf_y):.3f}")
        self.vdp_target_mode = False
        self.root.config(cursor="")

    def add_vdp_mapping(self):
        try:
            x_u = float(self.vdp_x_var.get())
            y_u = float(self.vdp_y_var.get())
        except ValueError:
            x_u, y_u = 0.5, 0.5
        mapping = self._build_vdp_mapping(x_u, y_u)
        if mapping is None:
            messagebox.showwarning("Missing Data", "Select a spreadsheet column, static text, or set up an Address Block first.")
            return
        self.vdp_mapped_fields.append(mapping)
        self.vdp_selected_index = len(self.vdp_mapped_fields) - 1
        self.draw_vdp_layout_fields()
        self.draw_vdp_overlays()

    def remove_vdp_mapping(self):
        if not self.vdp_mapped_fields:
            return
        idx = self.vdp_selected_index
        if idx is None or not (0 <= idx < len(self.vdp_mapped_fields)):
            idx = len(self.vdp_mapped_fields) - 1
        self._vdp_push_undo()
        self.vdp_mapped_fields.pop(idx)
        self.vdp_selected_index = None if not self.vdp_mapped_fields else min(idx, len(self.vdp_mapped_fields) - 1)
        if self.vdp_selected_index is not None:
            self._load_vdp_field_into_form(self.vdp_selected_index)
        self.draw_vdp_layout_fields()
        self.draw_vdp_overlays()
        if not self.vdp_mapped_fields:
            self.vdp_hint_var.set("All tags removed. Select a field and click the template to place another.")
        else:
            self._refresh_vdp_record_hint()

    def _vdp_data_rows(self):
        return load_merge_rows(
            csv_path=self.vdp_csv_path_var.get(),
            generate_count=self.vdp_generate_count_var.get(),
            mapped_columns=mapped_merge_columns(self.vdp_mapped_fields),
        )

    def _refresh_vdp_record_hint(self):
        records = len(self._vdp_data_rows())
        template_pages = 0
        if self.preview_doc:
            template_pages = len(self.preview_doc)
        elif self.files:
            template_pages = 1
        output_pages = records * template_pages if template_pages else records
        if self.vdp_csv_path_var.get():
            self.vdp_hint_var.set(
                f"{len(self.vdp_headers)} columns · {records} data row{'s' if records != 1 else ''} "
                f"(blank rows skipped) · output {output_pages} page{'s' if output_pages != 1 else ''}."
            )
        else:
            self.vdp_hint_var.set("Select a field, then click the template to place <<Column>>.")

    def preview_vdp_merge(self):
        if not self.files:
            messagebox.showwarning("No Template", "Load a PDF template in Assets Manager first.")
            return
        if not self.vdp_mapped_fields:
            messagebox.showwarning("No Fields", "Place at least one merge field on the template first.")
            return

        rows = self._vdp_data_rows()
        if not rows:
            messagebox.showwarning(
                "No Merge Data",
                "No spreadsheet rows contain merge data.\nBlank rows are skipped and do not create output pages.",
            )
            return

        max_preview_records = 40
        preview_rows = rows[:max_preview_records]
        self.root.config(cursor="watch")
        self.root.update_idletasks()
        template = None
        merged = None
        try:
            template = self.compile_current_stack(flattening=False, preview_mode=True)
            if not template or len(template) == 0:
                messagebox.showerror("Preview Failed", "Could not build the template PDF.")
                return
            template_pages = len(template)
            merged = apply_vdp_merge(
                template,
                preview_rows,
                list(self.vdp_mapped_fields),
                self.to_points,
                self.global_unit_var.get(),
            )
        except Exception as e:
            messagebox.showerror("Preview Failed", str(e))
            if merged is not None:
                try:
                    merged.close()
                except Exception:
                    pass
            return
        finally:
            self.root.config(cursor="")
            if template is not None:
                try:
                    template.close()
                except Exception:
                    pass

        if merged is None or len(merged) == 0:
            messagebox.showwarning("Preview Failed", "The merge produced no pages.")
            return
        self._show_vdp_merge_preview(merged, len(preview_rows), len(rows), template_pages)

    def _close_vdp_merge_preview(self):
        state = getattr(self, "_vdp_preview_state", None)
        if state and state.get("doc") is not None:
            try:
                state["doc"].close()
            except Exception:
                pass
        self._vdp_preview_state = None
        win = getattr(self, "_vdp_preview_win", None)
        if win is not None:
            try:
                win.destroy()
            except Exception:
                pass
        self._vdp_preview_win = None

    def _show_vdp_merge_preview(self, doc, shown_records, total_records, template_pages):
        self._close_vdp_merge_preview()
        win = tk.Toplevel(self.root)
        win.title("VDP Merge Preview (low-res)")
        win.geometry("900x720")
        win.configure(bg=self.color_white)
        win.transient(self.root)
        self._vdp_preview_win = win
        self._vdp_preview_state = {
            "doc": doc,
            "page": 0,
            "shown_records": shown_records,
            "total_records": total_records,
            "template_pages": max(1, template_pages),
            "photo": None,
        }

        info = tk.Label(win, text="", bg=self.color_white, fg=self.color_navy, font=("Arial", 10, "bold"))
        info.pack(fill="x", padx=12, pady=(10, 4))
        self._vdp_preview_state["info"] = info

        nav = tk.Frame(win, bg=self.color_white)
        nav.pack(fill="x", padx=12, pady=4)
        self._create_btn(nav, "◀ Page", self.color_steel, self.color_white, lambda: self._step_vdp_merge_preview(-1)).pack(side="left")
        self._create_btn(nav, "Page ▶", self.color_steel, self.color_white, lambda: self._step_vdp_merge_preview(1)).pack(side="left", padx=6)
        self._create_btn(nav, "◀ Record", self.color_mint, self.color_navy, lambda: self._step_vdp_merge_preview(-self._vdp_preview_state["template_pages"])).pack(side="left", padx=(12, 0))
        self._create_btn(nav, "Record ▶", self.color_mint, self.color_navy, lambda: self._step_vdp_merge_preview(self._vdp_preview_state["template_pages"])).pack(side="left", padx=6)

        canvas = tk.Canvas(win, bg="#1b1638", highlightthickness=0)
        canvas.pack(fill="both", expand=True, padx=12, pady=8)
        self._vdp_preview_state["canvas"] = canvas
        canvas.bind("<Configure>", lambda e: self._render_vdp_merge_preview_page())
        canvas.bind("<MouseWheel>", lambda e: self._step_vdp_merge_preview(-1 if e.delta > 0 else 1))

        note = "Blank spreadsheet rows are skipped. Final export uses every row that has merge data."
        if shown_records < total_records:
            note = f"Showing first {shown_records} of {total_records} data rows. Final export includes all {total_records}."
        tk.Label(win, text=note, bg=self.color_white, fg=self.color_steel, font=("Arial", 8, "italic")).pack(fill="x", padx=12)
        self._create_btn(win, "Close Preview", self.color_steel, self.color_white, self._close_vdp_merge_preview).pack(fill="x", padx=12, pady=(4, 12))
        win.protocol("WM_DELETE_WINDOW", self._close_vdp_merge_preview)
        self._render_vdp_merge_preview_page()

    def _step_vdp_merge_preview(self, delta):
        state = getattr(self, "_vdp_preview_state", None)
        if not state or state.get("doc") is None:
            return
        total = len(state["doc"])
        if total <= 0:
            return
        state["page"] = max(0, min(total - 1, state["page"] + delta))
        self._render_vdp_merge_preview_page()

    def _render_vdp_merge_preview_page(self):
        state = getattr(self, "_vdp_preview_state", None)
        if not state or state.get("doc") is None or state.get("canvas") is None:
            return
        canvas = state["canvas"]
        doc = state["doc"]
        if len(doc) == 0:
            return
        page_idx = max(0, min(state["page"], len(doc) - 1))
        state["page"] = page_idx
        page = doc[page_idx]
        template_pages = state["template_pages"]
        record_no = page_idx // template_pages + 1
        template_no = page_idx % template_pages + 1
        truncated = ""
        if state["shown_records"] < state["total_records"]:
            truncated = f"  ·  previewing {state['shown_records']} of {state['total_records']} records"
        state["info"].config(
            text=(
                f"Record {record_no} of {state['shown_records']}{truncated}  ·  "
                f"Template page {template_no}/{template_pages}  ·  "
                f"Output page {page_idx + 1} / {len(doc)}"
            )
        )

        canvas.delete("all")
        cw = max(canvas.winfo_width(), 1)
        ch = max(canvas.winfo_height(), 1)
        if cw < 20 or ch < 20:
            return
        pw, ph = page.rect.width, page.rect.height
        scale = min((cw - 24) / max(pw, 1.0), (ch - 24) / max(ph, 1.0), 1.0)
        img = render_page_image(doc, page.number, scale, annots=True)
        state["photo"] = ImageTk.PhotoImage(img)
        ox = (cw - img.width) / 2.0
        oy = (ch - img.height) / 2.0
        canvas.create_image(ox, oy, image=state["photo"], anchor="nw")

    def open_feedback_form(self):
        fb_win = tk.Toplevel(self.root)
        fb_win.title("Submit Feedback"); fb_win.geometry("450x450")
        fb_win.configure(bg=self.color_white); fb_win.transient(self.root); fb_win.grab_set()

        tk.Label(fb_win, text="Help us improve ReadySetPDF!", font=("Arial", 14, "bold"), bg=self.color_white, fg=self.color_navy).pack(pady=(15, 5))
        
        f1 = tk.Frame(fb_win, bg=self.color_white); f1.pack(fill="x", padx=20, pady=5)
        tk.Label(f1, text="Category:", bg=self.color_white, fg=self.color_navy, width=10, anchor="w").pack(side="left")
        type_var = tk.StringVar(value="Bug Report")
        ttk.Combobox(f1, values=["Bug Report", "Feature Request", "General Feedback"], textvariable=type_var, state="readonly", width=25).pack(side="left")

        f2 = tk.Frame(fb_win, bg=self.color_white); f2.pack(fill="x", padx=20, pady=5)
        tk.Label(f2, text="Your Email:", bg=self.color_white, fg=self.color_navy, width=10, anchor="w").pack(side="left")
        email_var = tk.StringVar()
        tk.Entry(f2, textvariable=email_var, bg=self.color_pale, width=30).pack(side="left")

        tk.Label(fb_win, text="Message / Description:", bg=self.color_white, fg=self.color_navy).pack(anchor="w", padx=20, pady=(10, 0))
        msg_box = tk.Text(fb_win, height=10, bg=self.color_pale, fg=self.color_navy, font=("Arial", 10), relief="flat", highlightthickness=1, highlightbackground=self.color_steel)
        msg_box.pack(fill="both", expand=True, padx=20, pady=5)

        def send_data():
            msg = msg_box.get("1.0", "end-1c").strip()
            if not msg:
                messagebox.showwarning("Empty Message", "Please enter a message before submitting.", parent=fb_win)
                return
            btn_submit.config(text="Sending...", state="disabled"); fb_win.update()

            category = type_var.get()
            email = email_var.get().strip()
            payload = {
                "access_key": "3f208f0f-c37c-445e-b2c1-252d16e8c673",
                "subject": f"ReadySetPDF Feedback: {category}",
                "from_name": "ReadySetPDF",
                "category": category,
                "message": msg,
            }
            if email:
                payload["email"] = email
            data = json.dumps(payload).encode("utf-8")

            try:
                req = urllib.request.Request(
                    "https://api.web3forms.com/submit",
                    data=data,
                    headers={
                        "Content-Type": "application/json",
                        "Accept": "application/json",
                        "User-Agent": "ReadySetPDF-Feedback",
                    },
                )
                with urllib.request.urlopen(req, timeout=20) as resp:
                    body = json.loads(resp.read().decode("utf-8", errors="replace") or "{}")
                if not body.get("success"):
                    raise RuntimeError(body.get("message") or "The form service did not accept the message.")
                messagebox.showinfo("Success", "Your feedback has been sent successfully. Thank you!", parent=fb_win)
                fb_win.destroy()
            except urllib.error.HTTPError as exc:
                detail = str(exc)
                try:
                    err_body = json.loads(exc.read().decode("utf-8", errors="replace") or "{}")
                    detail = err_body.get("message") or detail
                except Exception:
                    pass
                messagebox.showerror("Error", f"Failed to send feedback.\n\n{detail}", parent=fb_win)
                btn_submit.config(text="📨 Send Feedback", state="normal")
            except Exception as e:
                messagebox.showerror("Error", f"Failed to send feedback. Please check your internet connection.\n\n{e}", parent=fb_win)
                btn_submit.config(text="📨 Send Feedback", state="normal")

        btn_submit = self._create_btn(fb_win, "📨 Send Feedback", self.color_lime, self.color_navy, send_data)
        btn_submit.pack(pady=15, fill="x", padx=20)

    # --- ENGINE & PIPELINE ---
    def _get_step_display_text(self, step_data):
        stype = step_data["type"]; params = step_data.get("params", {})
        if stype == "Crop Margin": return f"📏 Crop: L:{params.get('left')} T:{params.get('top')} R:{params.get('right')} B:{params.get('bottom')}"
        elif stype == "Resize": return f"📐 Resize: {params.get('preset')}"
        elif stype == "Insert Blank Page":
            pos = params.get('position')
            return f"📄 Insert Blank Page (After Pg {params.get('page_num')})" if pos == "After Page #" else f"📄 Insert Blank Page ({pos})"
        elif stype == "Color Conversion":
            return "🎨 Color: Keep Original" if params.get('mode') == "Keep Original" else f"🎨 Color: {params.get('mode')} ({params.get('dpi')} DPI)"
        elif stype == "Monkey Imposition": return "🔲 Grid: Auto max-fit"
        elif stype == "Grid Imposition":
            if params.get("auto_fit"):
                return "🔲 Grid: Auto max-fit"
            return f"🔲 Grid: {params.get('cols')}x{params.get('rows')}"
        elif stype == "Booklet Spread": return f"📖 Booklet: {params.get('sheet_w')}x{params.get('sheet_h')}"
        elif stype == "Cutter Marks":
            extra = params.get("collate_mark") or "None"
            pages = params.get("pages", "all")
            return f"✂️ Cutter: {pages}" + (f" + {extra}" if extra not in ("None", "") else "")
        elif stype == "Rotate Pages": return f"🔄 Rotate: {params.get('angle')}° ({params.get('pages', 'all')})"
        elif stype == "VDP Mail Merge": return f"🏷️ VDP Mail Merge ({os.path.basename(params.get('csv_path', ''))})"
        elif stype == "OCR Extraction": return f"👁️ OCR Extract: {params.get('mode')} ({params.get('lang')})"
        elif stype == "Unlock PDF": return "🔓 Unlock ReadySetPDF lock"
        elif stype == "Join PDFs":
            if params.get("naming") == "datetime":
                return "📎 Join PDFs: Combined + date & time"
            return "📎 Join PDFs: Combined + first filename"
        elif stype == "Split PDFs": return "📄 Split PDFs: name_p1.pdf"
        return stype

    def add_step_to_queue(self, step_type):
        if not self.files:
            messagebox.showwarning("No Assets", "Load source PDF documents first."); return
        step_data = self._collect_step_from_form(step_type)
        if not step_data:
            return
        display_text = self._get_step_display_text(step_data)

        if self.active_history_index != -1 and self.active_history_index < len(self.action_queue) - 1:
            insert_pos = self.active_history_index + 1
            self.action_queue.insert(insert_pos, step_data)
            self.queue_box.insert(insert_pos, display_text)
            self.active_history_index = insert_pos
        else:
            self.action_queue.append(step_data)
            self.queue_box.insert(tk.END, display_text)
            self.active_history_index = len(self.action_queue) - 1

        self.queue_box.selection_clear(0, tk.END); self.queue_box.selection_set(self.active_history_index)
        self._sync_step_commit_buttons()
        self.render_live_preview()

    def overwrite_selected_step(self, step_type):
        selected = self._selected_step()
        if not selected or selected.get("type") != step_type:
            messagebox.showinfo("Overwrite", "Select a matching step in the stack first.")
            return
        step_data = self._collect_step_from_form(step_type)
        if not step_data:
            return
        idx = self.active_history_index
        self.action_queue[idx] = step_data
        self.queue_box.delete(idx)
        self.queue_box.insert(idx, self._get_step_display_text(step_data))
        self.queue_box.selection_clear(0, tk.END)
        self.queue_box.selection_set(idx)
        self._sync_step_commit_buttons()
        self.render_live_preview()

    def _collect_step_from_form(self, step_type):
        step_data = {"type": step_type}
        if step_type == "Crop Margin":
            step_data["params"] = {
                "left": self.crop_left_var.get(), "top": self.crop_top_var.get(),
                "right": self.crop_right_var.get(), "bottom": self.crop_bottom_var.get()
            }
        elif step_type == "Resize":
            step_data["params"] = {
                "preset": self.resize_preset_var.get(), "w": self.resize_w_var.get(), "h": self.resize_h_var.get(),
                "landscape": self.resize_landscape_var.get(), "stretch": self.resize_stretch_var.get()
            }
        elif step_type == "Insert Blank Page":
            step_data["params"] = {"position": self.blank_pos_var.get(), "page_num": self.blank_page_num_var.get()}
        elif step_type == "Color Conversion":
            step_data["params"] = {"mode": self.color_mode_var.get(), "dpi": self.color_dpi_var.get()}
        elif step_type == "Grid Imposition":
            step_data["params"] = {
                "cols": self.grid_cols_var.get(), "rows": self.grid_rows_var.get(), "sheet_w": self.grid_w_var.get(),
                "sheet_h": self.grid_h_var.get(), "landscape": self.grid_landscape_var.get(), "repeat": self.grid_repeat_var.get(),
                "margin_l": self.grid_margin_l_var.get(), "margin_t": self.grid_margin_t_var.get(), "gutter_h": self.grid_gutter_h_var.get(),
                "gutter_v": self.grid_gutter_v_var.get(), "center": self.grid_center_var.get(), "draw_marks": self.grid_draw_marks_var.get(),
                "mark_dist": self.grid_mark_dist_var.get(), "mark_thick": self.grid_mark_thick_var.get(),
                "mark_overlap": self.grid_mark_overlap_var.get(), "mark_color": self.grid_mark_color_var.get(),
                "autoscale": self.grid_autoscale_var.get(), "aspect": self.grid_aspect_var.get(),
                "auto_fit": self.grid_auto_fit_var.get(), "direction": self.grid_direction_var.get(),
                "order": self.grid_order_var.get(),
                "double_sided": self.grid_double_sided_var.get(), "flip_edge": self.grid_flip_edge_var.get(),
                "anchor": self.grid_anchor_var.get(),
                "art_has_bleed": self.grid_art_has_bleed_var.get(),
                "trim_w": self.grid_trim_w_var.get(), "trim_h": self.grid_trim_h_var.get(),
            }
        elif step_type == "Booklet Spread":
            step_data["params"] = {
                "sheet_w": self.booklet_w_var.get(), "sheet_h": self.booklet_h_var.get(), "landscape": self.booklet_landscape_var.get(),
                "margin_l": self.booklet_margin_l_var.get(), "margin_t": self.booklet_margin_t_var.get(), "center_gutter": self.booklet_center_gutter_var.get(),
                "creep_val": self.booklet_creep_var.get(), "creep_dir": self.booklet_creep_dir_var.get(), "center": self.booklet_center_var.get(),
                "anchor": self.booklet_anchor_var.get(),
                "art_has_bleed": self.booklet_art_has_bleed_var.get(),
                "trim_w": self.booklet_trim_w_var.get(), "trim_h": self.booklet_trim_h_var.get(),
                "draw_marks": self.booklet_draw_marks_var.get(),
                "mark_dist": self.booklet_mark_dist_var.get(), "mark_thick": self.booklet_mark_thick_var.get(),
                "mark_overlap": self.booklet_mark_overlap_var.get(), "mark_color": self.booklet_mark_color_var.get(),
            }
        elif step_type == "Cutter Marks":
            step_data["params"] = {
                "size": self.cutter_size_var.get(), "thick": self.cutter_thick_var.get(), "placement": self.cutter_placement_var.get(),
                "margin": self.cutter_margin_var.get(), "pages": self.cutter_pages_var.get(), "remove_art": self.cutter_remove_art_var.get(),
                "cut_l_marks": self.cutter_l_marks_var.get(), "collate_mark": self.cutter_collate_var.get(),
                "collate_corner": self.cutter_corner_var.get(),
                "mark_color": self.cutter_mark_color_var.get(),
            }
        elif step_type == "Rotate Pages":
            step_data["params"] = {"angle": self.rotate_deg_var.get(), "pages": self.rotate_pages_var.get()}
        elif step_type == "VDP Mail Merge":
            if not self.vdp_mapped_fields:
                messagebox.showwarning("VDP Error", "You must map at least one field."); return None
            step_data["params"] = {
                "csv_path": self.vdp_csv_path_var.get(),
                "fields": list(self.vdp_mapped_fields),
                "generate_count": self.vdp_generate_count_var.get(),
                "template_pdf": self.files[0] if self.files else "",
            }
        elif step_type == "OCR Extraction":
            step_data["params"] = {
                "mode": self.ocr_mode_var.get(),
                "lang": self.ocr_lang_var.get()
            }
        elif step_type == "Unlock PDF":
            step_data["params"] = {"password": self.unlock_pass_var.get()}
        elif step_type == "Join PDFs":
            naming = self.join_name_var.get()
            if naming not in ("first_file", "datetime"):
                naming = "first_file"
            step_data["params"] = {"naming": naming}
        elif step_type == "Split PDFs":
            step_data["params"] = {"naming": "page", "pattern": "{stem}_p{page}.pdf"}
        else:
            return None

        if "params" in step_data:
            step_data["params"]["unit"] = self.global_unit_var.get()
        return step_data

    def _set_str_var(self, var, value, default=""):
        if value is None:
            var.set(default)
        else:
            var.set(str(value))

    def _set_bool_var(self, var, value, default=False):
        if isinstance(value, str):
            var.set(value.strip().lower() in ("1", "true", "yes", "on"))
        elif value is None:
            var.set(bool(default))
        else:
            var.set(bool(value))

    def _apply_step_to_form(self, step):
        stype = step.get("type")
        params = step.get("params") or {}
        if stype == "Crop Margin":
            self._set_str_var(self.crop_left_var, params.get("left"), "0")
            self._set_str_var(self.crop_top_var, params.get("top"), "0")
            self._set_str_var(self.crop_right_var, params.get("right"), "0")
            self._set_str_var(self.crop_bottom_var, params.get("bottom"), "0")
        elif stype == "Resize":
            self._set_str_var(self.resize_preset_var, params.get("preset"), "Letter")
            self._set_str_var(self.resize_w_var, params.get("w"), "8.5")
            self._set_str_var(self.resize_h_var, params.get("h"), "11")
            self._set_bool_var(self.resize_landscape_var, params.get("landscape"))
            self._set_bool_var(self.resize_stretch_var, params.get("stretch"))
        elif stype == "Insert Blank Page":
            self._set_str_var(self.blank_pos_var, params.get("position"), "End of Document")
            self._set_str_var(self.blank_page_num_var, params.get("page_num"), "1")
        elif stype == "Color Conversion":
            self._set_str_var(self.color_mode_var, params.get("mode"), "Grayscale")
            self._set_str_var(self.color_dpi_var, params.get("dpi"), "300")
        elif stype in ("Grid Imposition", "Monkey Imposition"):
            auto_fit = stype == "Monkey Imposition" or bool(params.get("auto_fit"))
            self._set_bool_var(self.grid_auto_fit_var, auto_fit)
            self._set_str_var(self.grid_direction_var, params.get("direction"), "LTR")
            self._set_str_var(self.grid_cols_var, params.get("cols"), "2")
            self._set_str_var(self.grid_rows_var, params.get("rows"), "2")
            self._set_str_var(self.grid_w_var, params.get("sheet_w"), "12")
            self._set_str_var(self.grid_h_var, params.get("sheet_h"), "18")
            self._set_bool_var(self.grid_landscape_var, params.get("landscape"))
            self._set_str_var(self.grid_repeat_var, params.get("repeat"), "1")
            self._set_str_var(self.grid_margin_l_var, params.get("margin_l"), "0")
            self._set_str_var(self.grid_margin_t_var, params.get("margin_t"), "0")
            self._set_str_var(self.grid_gutter_h_var, params.get("gutter_h"), "0")
            self._set_str_var(self.grid_gutter_v_var, params.get("gutter_v"), "0")
            self._set_bool_var(self.grid_center_var, params.get("center"), True)
            self._set_bool_var(self.grid_draw_marks_var, params.get("draw_marks"), True)
            self._set_str_var(self.grid_mark_dist_var, params.get("mark_dist"), "0.125")
            self._set_str_var(self.grid_mark_thick_var, params.get("mark_thick"), "0.007")
            self._set_str_var(self.grid_mark_overlap_var, params.get("mark_overlap"), "0")
            self._set_str_var(self.grid_mark_color_var, params.get("mark_color"), "black")
            self._set_bool_var(self.grid_autoscale_var, params.get("autoscale"), False)
            self._set_bool_var(self.grid_aspect_var, params.get("aspect"), True)
            self._set_str_var(self.grid_order_var, params.get("order"), "Sequential")
            self._set_bool_var(self.grid_double_sided_var, params.get("double_sided"))
            self._set_str_var(self.grid_flip_edge_var, params.get("flip_edge"), "long")
            self._set_str_var(self.grid_anchor_var, params.get("anchor"), "c")
            self._set_bool_var(self.grid_art_has_bleed_var, params.get("art_has_bleed"))
            self._set_str_var(self.grid_trim_w_var, params.get("trim_w"), "")
            self._set_str_var(self.grid_trim_h_var, params.get("trim_h"), "")
            self._sync_grid_auto_fit()
        elif stype == "Booklet Spread":
            self._set_str_var(self.booklet_w_var, params.get("sheet_w"), "18")
            self._set_str_var(self.booklet_h_var, params.get("sheet_h"), "12")
            self._set_bool_var(self.booklet_landscape_var, params.get("landscape"))
            self._set_str_var(self.booklet_margin_l_var, params.get("margin_l"), "0")
            self._set_str_var(self.booklet_margin_t_var, params.get("margin_t"), "0")
            self._set_str_var(self.booklet_center_gutter_var, params.get("center_gutter"), "0")
            self._set_str_var(self.booklet_creep_var, params.get("creep_val"), "0")
            self._set_str_var(self.booklet_creep_dir_var, params.get("creep_dir"), "Outward")
            self._set_bool_var(self.booklet_center_var, params.get("center"), True)
            self._set_str_var(self.booklet_anchor_var, params.get("anchor"), "c")
            self._set_bool_var(self.booklet_art_has_bleed_var, params.get("art_has_bleed"))
            self._set_str_var(self.booklet_trim_w_var, params.get("trim_w"), "")
            self._set_str_var(self.booklet_trim_h_var, params.get("trim_h"), "")
            self._set_bool_var(self.booklet_draw_marks_var, params.get("draw_marks"))
            self._set_str_var(self.booklet_mark_dist_var, params.get("mark_dist"), "0.125")
            self._set_str_var(self.booklet_mark_thick_var, params.get("mark_thick"), "0.007")
            self._set_str_var(self.booklet_mark_overlap_var, params.get("mark_overlap"), "0")
            self._set_str_var(self.booklet_mark_color_var, params.get("mark_color"), "black")
        elif stype == "Cutter Marks":
            self._set_str_var(self.cutter_size_var, params.get("size"), "0.13")
            self._set_str_var(self.cutter_thick_var, params.get("thick"), "0.03")
            self._set_str_var(self.cutter_placement_var, params.get("placement"), "Inside")
            self._set_str_var(self.cutter_margin_var, params.get("margin"), "0")
            self._set_str_var(self.cutter_pages_var, params.get("pages"), "all")
            self._set_bool_var(self.cutter_remove_art_var, params.get("remove_art"))
            self._set_bool_var(self.cutter_l_marks_var, params.get("cut_l_marks"), True)
            self._set_str_var(self.cutter_collate_var, params.get("collate_mark"), "None")
            self._set_str_var(self.cutter_corner_var, params.get("collate_corner"), "Top Left")
            self._set_str_var(self.cutter_mark_color_var, params.get("mark_color"), "black")
        elif stype == "Rotate Pages":
            self._set_str_var(self.rotate_deg_var, params.get("angle"), "90")
            self._set_str_var(self.rotate_pages_var, params.get("pages"), "all")
        elif stype == "VDP Mail Merge":
            self._set_str_var(self.vdp_csv_path_var, params.get("csv_path"), "")
            fields = params.get("fields") or []
            for field in fields:
                if isinstance(field, dict):
                    field["bold"] = style_on(field.get("bold"))
                    field["italic"] = style_on(field.get("italic"))
                    field["underline"] = style_on(field.get("underline"))
            if fields:
                self.vdp_mapped_fields = list(fields)
            step_unit = params.get("unit") or self.global_unit_var.get()
            global_unit = self.global_unit_var.get()
            if step_unit != global_unit:
                prev = getattr(self, "_vdp_syncing", False)
                self._vdp_syncing = True
                try:
                    self._convert_vdp_field_lengths(self.vdp_mapped_fields, step_unit, global_unit)
                    params["unit"] = global_unit
                finally:
                    self._vdp_syncing = prev
            self._vdp_form_unit = global_unit
            self._set_str_var(self.vdp_generate_count_var, params.get("generate_count"), "1")
            self._vdp_sample_row_cache = None
            path = self.vdp_csv_path_var.get()
            if path and os.path.exists(path):
                try:
                    self.vdp_headers = self.extract_spreadsheet_headers(path)
                except Exception:
                    self.vdp_headers = []
            else:
                self.vdp_headers = []
            if hasattr(self, "vdp_header_combo"):
                self.vdp_header_combo.config(values=self.vdp_headers)
                if self.vdp_headers:
                    self.vdp_header_combo.current(0)
                else:
                    self.vdp_header_combo.set("")
            self.refresh_vdp_field_sidebar()
        elif stype == "OCR Extraction":
            self._set_str_var(self.ocr_mode_var, params.get("mode"), "txt")
            self._set_str_var(self.ocr_lang_var, params.get("lang"), "eng")
        elif stype == "Unlock PDF":
            self._set_str_var(self.unlock_pass_var, params.get("password"), "readysetpdf")
        elif stype == "Join PDFs":
            self.join_split_mode_var.set("join")
            naming = params.get("naming") or "first_file"
            self.join_name_var.set("datetime" if naming == "datetime" else "first_file")
            self._sync_join_split_pane()
        elif stype == "Split PDFs":
            self.join_split_mode_var.set("split")
            self.split_name_var.set(params.get("naming") or "page")
            self._sync_join_split_pane()

    def _load_stack_step_into_pane(self, step):
        tab = STEP_TAB_BY_TYPE.get(step.get("type"))
        self._loading_form = True
        try:
            self._apply_step_to_form(step)
            if tab and getattr(self, "current_active_tab", "") != tab:
                self.select_tab(tab)
            elif tab:
                self.current_active_tab = tab
        finally:
            self._loading_form = False
        self._sync_step_commit_buttons()

    def _export_max_dpi(self):
        return parse_max_dpi(self.export_max_dpi_var.get())

    # Bound from engine.py so existing self._execute_pipeline(...) call sites keep working.
    _execute_pipeline = _execute_pipeline

    def _unlock_owner_password(self, steps=None):
        if steps is None:
            end_point = len(self.action_queue) if self.active_history_index == -1 else self.active_history_index + 1
            steps = self.action_queue[:end_point]
        return unlock_password_from_steps(steps)

    def compile_current_stack(self, flattening=False, preview_mode=False, target_file_index=None):
        if not self.files: return None

        files_to_process = self.files
        if target_file_index is not None and 0 <= target_file_index < len(self.files):
            files_to_process = [self.files[target_file_index]]

        end_point = len(self.action_queue) if self.active_history_index == -1 else self.active_history_index + 1
        steps = list(self.action_queue[:end_point])
        if preview_mode:
            ghost = self._live_preview_step()
            if ghost:
                if not steps:
                    if ghost.get("type") in LIVE_PREVIEW_EMPTY_STACK:
                        steps = [ghost]
                elif steps[-1].get("type") == ghost["type"]:
                    steps = list(steps)
                    steps[-1] = ghost

        owner_password = self._unlock_owner_password()
        if steps_include_join_split(steps):
            if any(step.get("type") == "Join PDFs" for step in steps):
                files_to_process = list(self.files)
            return run_join_split_stack(
                self,
                list(files_to_process),
                steps,
                preview_mode=preview_mode,
                page_box_mode=self.page_box_mode_var.get(),
                flattening=flattening,
                max_dpi=self._export_max_dpi(),
                owner_password=owner_password,
                reassemble_for_preview=True,
            )

        active_doc = pdfdoc.open()
        for p in files_to_process:
            try:
                insert_source_file(
                    active_doc, p, max_dpi=self._export_max_dpi(), owner_password=owner_password,
                )
            except UnlockError:
                try:
                    active_doc.close()
                except Exception:
                    pass
                raise
            except Exception:
                continue

        prepare_imported_doc(
            active_doc, self.page_box_mode_var.get(), flattening=flattening, max_dpi=self._export_max_dpi(),
        )
        return self._execute_pipeline(active_doc, steps, preview_mode=preview_mode)

    def _live_preview_step(self):
        tab = getattr(self, "current_active_tab", "")
        step_type = LIVE_PREVIEW_TABS.get(tab)
        if not step_type:
            return None
        if step_type == "Grid Imposition" and not self.grid_auto_fit_var.get():
            if self.parse_locale_number(self.grid_cols_var.get()) is None or self.parse_locale_number(self.grid_rows_var.get()) is None:
                return None
        return self._collect_step_from_form(step_type)

    def _bind_live_preview_traces(self):
        vars_to_watch = [
            self.resize_w_var, self.resize_h_var, self.resize_preset_var,
            self.crop_left_var, self.crop_top_var, self.crop_right_var, self.crop_bottom_var,
            self.grid_w_var, self.grid_h_var, self.grid_cols_var, self.grid_rows_var,
            self.grid_margin_l_var, self.grid_margin_t_var, self.grid_gutter_h_var, self.grid_gutter_v_var,
            self.grid_repeat_var, self.grid_mark_dist_var, self.grid_mark_thick_var, self.grid_preset_var,
            self.grid_mark_overlap_var, self.grid_mark_color_var,
            self.grid_anchor_var, self.grid_flip_edge_var, self.grid_trim_w_var, self.grid_trim_h_var,
            self.grid_order_var, self.grid_direction_var,
            self.rotate_deg_var, self.rotate_pages_var,
            self.cutter_size_var, self.cutter_thick_var, self.cutter_margin_var, self.cutter_pages_var,
            self.cutter_placement_var, self.cutter_collate_var, self.cutter_corner_var,
            self.cutter_mark_color_var,
            self.booklet_w_var, self.booklet_h_var, self.booklet_margin_l_var, self.booklet_margin_t_var,
            self.booklet_center_gutter_var, self.booklet_creep_var, self.booklet_trim_w_var,
            self.booklet_trim_h_var, self.booklet_mark_dist_var, self.booklet_mark_thick_var,
            self.booklet_mark_overlap_var, self.booklet_mark_color_var, self.booklet_creep_dir_var,
            self.booklet_anchor_var,
            self.fold_w_var, self.fold_h_var, self.fold_bleed_var, self.fold_along_var, self.fold_type_var,
            self.color_mode_var, self.color_dpi_var,
        ]
        bools_to_watch = [
            self.resize_landscape_var, self.resize_stretch_var,
            self.grid_landscape_var, self.grid_center_var, self.grid_draw_marks_var,
            self.grid_autoscale_var, self.grid_aspect_var, self.grid_auto_fit_var, self.grid_double_sided_var,
            self.grid_art_has_bleed_var,
            self.booklet_landscape_var, self.booklet_center_var, self.booklet_art_has_bleed_var,
            self.booklet_draw_marks_var,
            self.cutter_remove_art_var, self.cutter_l_marks_var,
            self.fold_landscape_var, self.fold_art_has_bleed_var, self.fold_use_pdf_size_var,
        ]
        for var in vars_to_watch:
            var.trace_add("write", self._on_live_form_change)
        for var in bools_to_watch:
            var.trace_add("write", self._on_live_form_change)
        self.page_box_mode_var.trace_add("write", self._on_page_geometry_change)
        self.export_max_dpi_var.trace_add("write", lambda *_args: self.save_settings())
        self.booklet_creep_var.trace_add("write", self._on_booklet_creep_change)
        self.booklet_creep_dir_var.trace_add("write", self._on_booklet_creep_change)

    def _on_booklet_creep_change(self, *args):
        if getattr(self, "_loading_form", False):
            return
        if getattr(self, "current_active_tab", "") != "Booklet":
            return
        val = self.parse_locale_number(self.booklet_creep_var.get()) or 0.0
        if abs(val) > 1e-9 and self.current_preview_page < 2:
            self.current_preview_page = 10**9

    def _on_live_form_change(self, *args):
        if getattr(self, "_loading_form", False):
            return
        tab = getattr(self, "current_active_tab", "")
        if tab == "Folds":
            job = getattr(self, "_live_preview_job", None)
            if job:
                try:
                    self.root.after_cancel(job)
                except Exception:
                    pass
            self._live_preview_job = self.root.after(180, self._refresh_fold_preview)
            return
        if tab not in LIVE_PREVIEW_TABS:
            return
        job = getattr(self, "_live_preview_job", None)
        if job:
            try:
                self.root.after_cancel(job)
            except Exception:
                pass
        self._live_preview_job = self.root.after(280, self.render_live_preview)

    def parse_recipe_data(self, data):
        """Return (steps, page_box_mode_or_None). Old recipes are a bare step list."""
        if isinstance(data, list):
            return data, None
        if isinstance(data, dict):
            steps = data.get("steps")
            if isinstance(steps, list):
                mode = data.get("page_box_mode") or data.get("page_geometry")
                return steps, (normalize_page_box_mode(mode) if mode else None)
        raise ValueError("Recipe must be a step list or an object with a steps array.")

    def save_recipe(self):
        if not self.action_queue: return
        path = self._pick_save_recipe()
        if path:
            self._remember_dialog_folder("recipe_folder", path)
            try:
                payload = {
                    "app": "ReadySetPDF",
                    "readysetpdf_version": APP_VERSION,
                    "version": APP_VERSION,
                    "unit": self.global_unit_var.get(),
                    "page_box_mode": normalize_page_box_mode(self.page_box_mode_var.get()),
                    "steps": self.action_queue,
                }
                with open(path, 'w') as f: json.dump(payload, f, indent=4)
                messagebox.showinfo("Success", "Recipe saved successfully.")
            except Exception as e: messagebox.showerror("Error", f"Failed to save recipe:\n{e}")

    def _clear_vdp_workspace(self):
        """Drop the mail-merge job so a different recipe cannot keep its boxes on screen."""
        self._close_vdp_merge_preview()
        self.vdp_mapped_fields = []
        self.vdp_selected_index = None
        self.vdp_selected_column = None
        self.vdp_address_block = None
        self.vdp_address_map = {}
        self._vdp_sample_row_cache = None
        self._vdp_place_armed = False
        self._vdp_undo_stack = []
        self._vdp_hover_index = None
        self.vdp_drag = None
        self.vdp_headers = []
        self.vdp_csv_path_var.set("")
        if hasattr(self, "vdp_header_combo"):
            self.vdp_header_combo.config(values=[])
            self.vdp_header_combo.set("")
        self.vdp_hint_var.set("Load a PDF template and a spreadsheet to place merge fields.")
        self.refresh_vdp_field_sidebar()
        if hasattr(self, "vdp_layer_list"):
            self._refresh_vdp_layer_list()
        if hasattr(self, "vdp_canvas"):
            self.render_vdp_layout_preview()

    def load_recipe(self, path=None):
        if not path:
            path = self._pick_recipe_file()
        if path:
            self._remember_dialog_folder("recipe_folder", path)
            try:
                with open(path, "r", encoding="utf-8-sig") as f:
                    data = json.load(f)
                steps, mode = self.parse_recipe_data(data)
                self._install_loaded_recipe(steps, mode)
            except Exception as e:
                messagebox.showerror("Error", f"Failed to load recipe:\n{e}")

    def _install_loaded_recipe(self, steps, mode):
        self.action_queue = steps
        if mode:
            self.page_box_mode_var.set(mode)
        self.queue_box.delete(0, tk.END)
        for step in self.action_queue:
            self.queue_box.insert(tk.END, self._get_step_display_text(step))
        self.current_preview_page = 0
        self.active_history_index = len(self.action_queue) - 1
        self._clear_vdp_workspace()
        if self.active_history_index >= 0:
            self.queue_box.selection_set(self.active_history_index)
            self.queue_box.see(self.active_history_index)
            step = self._selected_step()
            if step:
                self._load_stack_step_into_pane(step)
        self.render_live_preview()
        if hasattr(self, "vdp_canvas"):
            self.render_vdp_layout_preview()

    def show_export_dialog(self):
        if hasattr(self, 'vdp_mapped_fields') and len(self.vdp_mapped_fields) > 0:
            has_vdp_step = any(step.get("type") == "VDP Mail Merge" for step in self.action_queue)
            if not has_vdp_step:
                ans = messagebox.askyesno("Unsaved Mail Merge", 
                    "You mapped a field, but you forgot to click the green 'Add Step to Stack' button!\n\nDo you want me to automatically add it to your steps list before exporting?")
                if ans:
                    self.add_step_to_queue("VDP Mail Merge")
                else:
                    return

        if not self.files:
            messagebox.showwarning("Empty Project", "No input files loaded.")
            return
            
        export_win = tk.Toplevel(self.root)
        export_win.title("Final Production Export"); export_win.geometry("520x560")
        export_win.configure(bg=self.color_white); export_win.transient(self.root); export_win.grab_set()
        tk.Label(export_win, text="Final Output Options", font=("Arial", 14, "bold"), bg=self.color_white, fg=self.color_navy).pack(pady=12)
        
        file_frame = ttk.LabelFrame(export_win, text="File Handling Options", padding=10); file_frame.pack(fill="x", padx=15, pady=5)
        self.export_individual_var = tk.BooleanVar(value=False)
        ttk.Radiobutton(file_frame, text="Merge all assets into a single PDF (Default)", variable=self.export_individual_var, value=False, command=self.toggle_export_opts).pack(anchor="w", pady=2)
        ttk.Radiobutton(file_frame, text="Export as individual PDFs", variable=self.export_individual_var, value=True, command=self.toggle_export_opts).pack(anchor="w", pady=2)

        self.suffix_frame = tk.Frame(file_frame, bg=self.color_white)
        tk.Label(self.suffix_frame, text="Append Suffix:", bg=self.color_white, fg=self.color_navy).pack(side="left", pady=2)
        tk.Entry(self.suffix_frame, textvariable=self.export_suffix_var, width=15, bg=self.color_pale).pack(side="left", padx=5)
        ToolTip(self.suffix_frame, "Text to append to the end of each original file name.", self)
        
        self.toggle_export_opts()

        # NEW: OPTIMIZATION & COMPRESSION OPTIONS FRAME
        opt_frame = ttk.LabelFrame(export_win, text="File Size & Compression", padding=10); opt_frame.pack(fill="x", padx=15, pady=5)
        cb_comp = ttk.Checkbutton(opt_frame, text="⚡ Maximum Stream Deflation & Font Deduplication", variable=self.export_compress_streams_var)
        cb_comp.pack(anchor="w", pady=2)
        ToolTip(cb_comp, "Purges duplicate XObjects, compresses content streams, and strips unused fonts.", self)

        cb_img_opt = ttk.Checkbutton(opt_frame, text="🖼️ Optimize & Compress Image Streams", variable=self.export_optimize_images_var)
        cb_img_opt.pack(anchor="w", pady=2)
        ToolTip(cb_img_opt, "Flattens uncompressed raster images to compact JPEG/PNG streams to prevent file doubling.", self)

        dpi_row = tk.Frame(opt_frame, bg=self.color_white)
        dpi_row.pack(anchor="w", pady=(6, 2), fill="x")
        tk.Label(dpi_row, text="Max resolution:", bg=self.color_white, fg=self.color_navy).pack(side="left")
        dpi_combo = ttk.Combobox(
            dpi_row, textvariable=self.export_max_dpi_var, width=12,
            values=["Original", "300", "600", "1200"],
        )
        dpi_combo.pack(side="left", padx=6)
        ToolTip(
            dpi_combo,
            "Original sends the file's own pixels to the RIP, including 1200 DPI and Illustrator private image data. "
            "Choose 300, 600, 1200, or type another number to downsample only images above that PPI. "
            "Images already below the number are left alone.",
            self,
        )

        stamp_frame = ttk.LabelFrame(export_win, text="Visual Proofing Options", padding=10); stamp_frame.pack(fill="x", padx=15, pady=5)
        cb_stamp = ttk.Checkbutton(stamp_frame, text="Apply Production Proof Watermark *", variable=self.apply_stamp_var); cb_stamp.pack(anchor="w")
        tk.Label(stamp_frame, text="Watermark Text:", bg=self.color_white, fg=self.color_navy).pack(anchor="w", pady=(2,0))
        tk.Entry(stamp_frame, textvariable=self.stamp_text_var, font=("Arial", 10), fg="red", bg=self.color_pale).pack(fill="x", pady=2)
        
        sec_frame = ttk.LabelFrame(export_win, text="Document Security Lock", padding=10); sec_frame.pack(fill="x", padx=15, pady=5)
        cb_lock1 = ttk.Checkbutton(sec_frame, text="🔒 Print Lock (Disable Physical Printing) *", variable=self.lock_print_var); cb_lock1.pack(anchor="w", pady=1)
        ToolTip(
            cb_lock1,
            "Print Lock asks viewers not to print. This is a permission flag ReadySetPDF writes.\nThe file still opens. A PDF that will not open until a password is typed stays locked.",
            self,
        )
        cb_lock2 = ttk.Checkbutton(sec_frame, text="🔒 Edit Lock (Disable Extraction/Modifications) *", variable=self.lock_edit_var); cb_lock2.pack(anchor="w", pady=1)
        ToolTip(
            cb_lock2,
            "Edit Lock asks viewers not to copy or change the file. This is a permission flag ReadySetPDF writes.\nThe file still opens. A PDF that will not open until a password is typed stays locked.",
            self,
        )
        
        self._create_btn(export_win, "💾 Choose Path & Save", self.color_steel, self.color_white, lambda: self.execute_final_save(export_win)).pack(pady=15, fill="x", padx=15)

    def toggle_export_opts(self):
        if hasattr(self, 'suffix_frame') and self.suffix_frame.winfo_exists():
            if self.export_individual_var.get():
                self.suffix_frame.pack(anchor="w", padx=20, pady=2)
            else:
                self.suffix_frame.pack_forget()

    def execute_final_save(self, window):
        is_individual = self.export_individual_var.get()
        do_compress = self.export_compress_streams_var.get()
        do_img_opt = self.export_optimize_images_var.get()
        
        save_flags = {
            "garbage": 4 if do_compress else 1,
            "deflate": do_compress,
            "deflate_images": do_img_opt,
            "deflate_fonts": do_compress,
            "clean": True
        }

        end_point = len(self.action_queue) if self.active_history_index == -1 else self.active_history_index + 1
        steps = list(self.action_queue[:end_point])
        if steps_include_join_split(steps):
            self._save_join_split_outputs(window, steps, save_flags)
            return

        if is_individual:
            out_dir = filedialog.askdirectory(title="Select Folder to Save Individual PDFs")
            if not out_dir: return
            window.destroy()
            
            success_count = 0
            end_point = len(self.action_queue) if self.active_history_index == -1 else self.active_history_index + 1
            suffix = self.export_suffix_var.get().strip()
            owner_password = self._unlock_owner_password(self.action_queue[:end_point])
            
            for p in self.files:
                active_doc = pdfdoc.open()
                try:
                    insert_source_file(
                        active_doc, p, max_dpi=self._export_max_dpi(), owner_password=owner_password,
                    )
                except UnlockError as exc:
                    try:
                        active_doc.close()
                    except Exception:
                        pass
                    messagebox.showerror("Unlock", str(exc))
                    continue
                prepare_imported_doc(
                    active_doc, self.page_box_mode_var.get(), flattening=True, max_dpi=self._export_max_dpi(),
                )
                
                final_doc = self._execute_pipeline(active_doc, self.action_queue[:end_point], preview_mode=False)
                if not final_doc: continue
                
                if self.apply_stamp_var.get():
                    final_doc = apply_proof_stamp(final_doc, self.stamp_text_var.get())
                
                base_name = os.path.splitext(os.path.basename(p))[0]
                out_path = os.path.join(out_dir, f"{base_name}{suffix}.pdf")
                
                try:
                    save_production_pdf(
                        final_doc, out_path, save_flags,
                        lock_print=self.lock_print_var.get(),
                        lock_edit=self.lock_edit_var.get(),
                        owner_pw=self.custom_owner_pw_var.get(),
                    )
                    final_doc.close()
                    success_count += 1
                except Exception as e: messagebox.showerror("Save Failure", str(e))
                
            messagebox.showinfo("Success", f"{success_count} individual files successfully processed and saved to:\n{out_dir}")

        else:
            base_origin_name = os.path.splitext(os.path.basename(self.files[0]))[0]
            suggested_filename = f"{base_origin_name}_readysetpdf.pdf"
            out_path = filedialog.asksaveasfilename(defaultextension=".pdf", initialfile=suggested_filename, filetypes=[("PDF Files", "*.pdf")])
            if not out_path: return
            window.destroy()
            
            try:
                final_doc = self.compile_current_stack(flattening=True, preview_mode=False)
            except UnlockError as exc:
                messagebox.showerror("Unlock", str(exc))
                return
            if not final_doc: return
            
            if self.apply_stamp_var.get():
                final_doc = apply_proof_stamp(final_doc, self.stamp_text_var.get())
            try:
                save_production_pdf(
                    final_doc, out_path, save_flags,
                    lock_print=self.lock_print_var.get(),
                    lock_edit=self.lock_edit_var.get(),
                    owner_pw=self.custom_owner_pw_var.get(),
                )
                final_doc.close()
                messagebox.showinfo("Success", f"Secured production layout successfully generated:\n{out_path}")
            except Exception as e: messagebox.showerror("Save Failure", str(e))

    def _save_join_split_outputs(self, window, steps, save_flags):
        if not self.files:
            messagebox.showwarning("Empty Project", "No input files loaded.")
            return
        out_dir = filedialog.askdirectory(parent=window, title="Select Folder for Join / Split PDFs")
        if not out_dir:
            return
        window.destroy()
        try:
            pairs = run_join_split_stack(
                self,
                list(self.files),
                steps,
                preview_mode=False,
                page_box_mode=self.page_box_mode_var.get(),
                flattening=True,
                max_dpi=self._export_max_dpi(),
                owner_password=self._unlock_owner_password(steps),
                reassemble_for_preview=False,
            )
        except UnlockError as exc:
            messagebox.showerror("Unlock", str(exc))
            return
        if not pairs:
            messagebox.showwarning("No Assets", "Load source PDF documents first.")
            return
        written = []
        blocked = list(self.files)
        try:
            for item in pairs:
                doc = item.get("doc")
                if doc is None or len(doc) == 0:
                    continue
                if self.apply_stamp_var.get():
                    doc = apply_proof_stamp(doc, self.stamp_text_var.get())
                    item["doc"] = doc
                out_path = output_path_avoiding_sources(out_dir, item.get("stem"), blocked)
                blocked.append(out_path)
                save_production_pdf(
                    doc, out_path, save_flags,
                    lock_print=self.lock_print_var.get(),
                    lock_edit=self.lock_edit_var.get(),
                    owner_pw=self.custom_owner_pw_var.get(),
                )
                written.append(os.path.basename(out_path))
        except Exception as exc:
            messagebox.showerror("Save Failure", str(exc))
            return
        finally:
            for item in pairs:
                doc = item.get("doc")
                if doc is None:
                    continue
                try:
                    doc.close()
                except Exception:
                    pass
        if not written:
            messagebox.showwarning("Save Failure", "No pages were written.")
            return
        preview = "\n".join(written[:12])
        if len(written) > 12:
            preview += f"\n… {len(written) - 12} more"
        messagebox.showinfo("Success", f"Saved {len(written)} file(s) to:\n{out_dir}\n\n{preview}")

    def render_live_preview(self):
        if not self._widget_alive(getattr(self, "preview_canvas", None)):
            return
        self._schedule_monitor_chrome_reflow()
        try:
            self.preview_canvas.delete("all")
            if self.preview_doc: 
                self.preview_doc.close()
                self.preview_doc = None
                
            if not self.files:
                self.preview_file_label.config(text="File: 0 / 0")
                self.preview_page_label.config(text="Page: 0 / 0")
                self.btn_prev_file.config(state="disabled")
                self.btn_next_file.config(state="disabled")
                if getattr(self, "current_active_tab", "") == "Folds":
                    layout = self._current_fold_layout()
                    self.preview_doc = pdfdoc.open()
                    blank = self.preview_doc.new_page(width=layout["sheet_w"], height=layout["sheet_h"])
                    blank.draw_rect(blank.rect, color=(1, 1, 1), fill=(1, 1, 1))
                    self.history_status_label.config(text="Viewing: Fold die-line guide", fg=self.color_navy)
                else:
                    self.history_status_label.config(text="Viewing: Original Baseline", fg=self.color_steel)
                    self._sync_vdp_preview_if_open()
                    return
            else:
                show_one = getattr(self, "_preview_selected_file", False) and not self.preview_merge_var.get()
                join_now = self._join_in_viewed_steps() and not show_one
                if self.preview_merge_var.get() or len(self.files) <= 1 or join_now:
                    self.btn_prev_file.config(state="disabled")
                    self.btn_next_file.config(state="disabled")
                    if join_now and len(self.files) > 1:
                        self.preview_file_label.config(text="File: ALL (Joined)")
                    elif len(self.files) > 1:
                        self.preview_file_label.config(text="File: ALL (Merged)")
                    else:
                        self.preview_file_label.config(text="File: 1 / 1")
                else:
                    self.btn_prev_file.config(state="normal")
                    self.btn_next_file.config(state="normal")
                    self.preview_file_label.config(text=f"File: {self.current_preview_file_index + 1} / {len(self.files)}")
                    self._select_asset_row(self.current_preview_file_index)

                if self.active_history_index == -1: 
                    self.active_history_index = len(self.action_queue) - 1 if self.action_queue else -1
                    
                target_idx = None if (self.preview_merge_var.get() or join_now) else self.current_preview_file_index
                self.preview_doc = self.compile_current_stack(flattening=False, preview_mode=True, target_file_index=target_idx)
                
                if not self.action_queue or self.active_history_index == -1: 
                    self.history_status_label.config(text="Viewing: Original Baseline", fg=self.color_steel)
                else: 
                    status = f"Viewing Step State Slice: [ {self.queue_box.get(self.active_history_index)} ]"
                    sel = self._selected_step()
                    pane_type = LIVE_PREVIEW_TABS.get(getattr(self, "current_active_tab", ""), "")
                    if sel and pane_type and sel.get("type") != pane_type:
                        status += f"  ·  {self.current_active_tab} pane is not in this preview — Add it, or click that step"
                    self.history_status_label.config(text=status, fg=self.color_navy)

            if not self.preview_doc or len(self.preview_doc) == 0: 
                return
            if self.current_preview_page >= len(self.preview_doc): 
                self.current_preview_page = max(0, len(self.preview_doc) - 1)
                
            page = self.preview_doc[self.current_preview_page]
            zoom_str = self.preview_zoom_var.get()
            if "1.5x" in zoom_str:
                zoom_factor = 1.5
            elif "2.0x" in zoom_str:
                zoom_factor = 2.0
            elif "3.0x" in zoom_str:
                zoom_factor = 3.0
            else:
                zoom_factor = 1.0
            
            self.root.update_idletasks()
            c_width, c_height = self._preview_viewport_size()

            pw = max(1.0, page.rect.width)
            ph = max(1.0, page.rect.height)
            self.preview_page_w_pt = pw
            self.preview_page_h_pt = ph
            band = self.ruler_band if self.show_measurements_var.get() else 4
            edge_pad = 6
            if "Fit Height" in zoom_str:
                base_scale = (c_height - band - edge_pad) / ph
            else:
                base_scale = (c_width - band - edge_pad) / pw
            self.preview_final_scale = max(0.05, base_scale * zoom_factor)
            self._preview_rendered_size = (int(c_width), int(c_height))
            
            pil_img = render_page_image(
                self.preview_doc,
                self.current_preview_page,
                self.preview_final_scale,
                annots=True,
            )
            self.preview_image = ImageTk.PhotoImage(image=pil_img)
            
            self.preview_img_w, self.preview_img_h = pil_img.size
            label_pad = 16 if self.show_measurements_var.get() else edge_pad
            region_w = max(c_width, band + self.preview_img_w + edge_pad)
            region_h = max(c_height, band + self.preview_img_h + label_pad)
            self.preview_canvas.config(scrollregion=(0, 0, region_w, region_h))
            self.preview_pos_x = band + self.preview_img_w / 2.0
            self.preview_pos_y = band + self.preview_img_h / 2.0
            self.preview_canvas.xview_moveto(0)
            self.preview_canvas.yview_moveto(0)
            
            self.preview_canvas.create_rectangle(
                self.preview_pos_x - (self.preview_img_w / 2), 
                self.preview_pos_y - (self.preview_img_h / 2), 
                self.preview_pos_x + (self.preview_img_w / 2), 
                self.preview_pos_y + (self.preview_img_h / 2), 
                fill="white", outline=""
            )
            
            self.preview_canvas.create_image(self.preview_pos_x, self.preview_pos_y, image=self.preview_image)
            self.preview_page_label.config(text=f"Page: {self.current_preview_page + 1} / {len(self.preview_doc)}")
            if getattr(self, "current_active_tab", "") == "Booklet":
                creep = self.parse_locale_number(self.booklet_creep_var.get()) or 0.0
                if abs(creep) > 1e-9 and self.current_preview_page < 2:
                    self.history_status_label.config(
                        text=self.history_status_label.cget("text") + "  ·  Cover has 0 creep — page forward for inner sheets"
                    )
            
            if hasattr(self, 'draw_vdp_overlays'):
                self.draw_vdp_overlays()
            self.draw_fold_overlays()
            
            self.draw_measurements(pw, ph)
            self._sync_vdp_preview_if_open()
            
        except Exception as e:
            label = getattr(self, "history_status_label", None)
            if self._widget_alive(label):
                label.config(text=f"Engine Crash: {str(e)}", fg="red")

    def _ruler_unit_label(self):
        unit = self.global_unit_var.get()
        if unit == "inches":
            return "in"
        if unit == "mm":
            return "mm"
        return "pt"

    def _format_edge_measure(self, pts):
        unit = self.global_unit_var.get()
        val = self.points_to_global_unit(max(0.0, pts))
        if unit == "inches":
            return f"{val:.3f} in  ({self._inch_fraction_label(val)})"
        if unit == "mm":
            return f"{val:.1f} mm"
        return f"{val:.1f} pt"

    def _inch_fraction_label(self, inches):
        sign = "-" if inches < 0 else ""
        inches = abs(inches)
        whole = int(inches)
        sixteenths = int(round((inches - whole) * 16.0))
        if sixteenths == 16:
            whole += 1
            sixteenths = 0
        if sixteenths == 0:
            return f"{sign}{whole}\""
        g = math.gcd(sixteenths, 16)
        num, den = sixteenths // g, 16 // g
        if whole:
            return f"{sign}{whole} {num}/{den}\""
        return f"{sign}{num}/{den}\""

    def _iter_ruler_ticks(self, length_pt):
        """Yield (position_in_points, kind) with kind major/mid/minor."""
        unit = self.global_unit_var.get()
        scale = max(float(self.preview_final_scale or 1.0), 0.01)
        if unit == "mm":
            minor_u, mid_u, major_u, u_to_pt = 1.0, 5.0, 10.0, 72.0 / 25.4
        elif unit == "points":
            minor_u, mid_u, major_u, u_to_pt = 6.0, 18.0, 72.0, 1.0
        else:
            minor_u, mid_u, major_u, u_to_pt = 1.0 / 16.0, 0.25, 1.0, 72.0
        while minor_u * u_to_pt * scale < 4.0 and minor_u < major_u - 1e-9:
            if unit == "inches":
                minor_u *= 2.0
            elif unit == "mm":
                minor_u = 5.0 if minor_u < 5.0 else 10.0
            else:
                minor_u *= 2.0
        step_pt = minor_u * u_to_pt
        if step_pt <= 0:
            return
        i = 0
        while True:
            pos = i * step_pt
            if pos > length_pt + 0.35:
                break
            units = i * minor_u
            if abs(round(units / major_u) * major_u - units) < 1e-6:
                kind = "major"
            elif abs(round(units / mid_u) * mid_u - units) < 1e-6:
                kind = "mid"
            else:
                kind = "minor"
            yield pos, kind
            i += 1
        if abs(length_pt - (i - 1) * step_pt) > 0.4:
            yield length_pt, "major"

    def _major_tick_label(self, pos_pt):
        unit = self.global_unit_var.get()
        val = self.points_to_global_unit(pos_pt)
        if unit == "inches":
            if abs(val - round(val)) < 0.02:
                return str(int(round(val)))
            return f"{val:.2f}".rstrip("0").rstrip(".")
        if unit == "mm":
            if abs(val - round(val)) < 0.05:
                return str(int(round(val)))
            return f"{val:.1f}"
        if abs(val - round(val)) < 0.2:
            return str(int(round(val)))
        return f"{val:.0f}"

    def draw_measurements(self, pw, ph):
        self.preview_canvas.delete("measurements")
        self.preview_canvas.delete("ruler_hover")
        if not self.show_measurements_var.get():
            return
        if self.preview_img_w == 0 or self.preview_img_h == 0:
            return

        self.preview_page_w_pt = pw
        self.preview_page_h_pt = ph
        u_label = self._ruler_unit_label()
        x0 = self.preview_pos_x - (self.preview_img_w / 2.0)
        y0 = self.preview_pos_y - (self.preview_img_h / 2.0)
        x1 = self.preview_pos_x + (self.preview_img_w / 2.0)
        y1 = self.preview_pos_y + (self.preview_img_h / 2.0)
        band = self.ruler_band
        tick_c = self.color_lime
        text_c = self.color_white
        tag = "measurements"

        self.preview_canvas.create_rectangle(x0 - band, y0 - band, x1 + 4, y0, fill="#24324f", outline="", tags=tag)
        self.preview_canvas.create_rectangle(x0 - band, y0, x0, y1 + 4, fill="#24324f", outline="", tags=tag)
        self.preview_canvas.create_rectangle(x0 - band, y0 - band, x0, y0, fill="#1b2740", outline=self.color_steel, tags=tag)
        self.preview_canvas.create_text(
            x0 - band / 2.0, y0 - band / 2.0, text=u_label, fill=self.color_lime, font=("Arial", 7, "bold"), tags=tag,
        )

        for pos, kind in self._iter_ruler_ticks(pw):
            x = x0 + pos * self.preview_final_scale
            if x < x0 - 0.5 or x > x1 + 0.5:
                continue
            length = 10 if kind == "major" else 7 if kind == "mid" else 4
            self.preview_canvas.create_line(x, y0, x, y0 - length, fill=tick_c, width=1, tags=tag)
            if kind == "major":
                self.preview_canvas.create_text(
                    x, y0 - length - 1, text=self._major_tick_label(pos),
                    fill=text_c, font=("Arial", 6), anchor="s", tags=tag,
                )

        for pos, kind in self._iter_ruler_ticks(ph):
            y = y0 + pos * self.preview_final_scale
            if y < y0 - 0.5 or y > y1 + 0.5:
                continue
            length = 10 if kind == "major" else 7 if kind == "mid" else 4
            self.preview_canvas.create_line(x0, y, x0 - length, y, fill=tick_c, width=1, tags=tag)
            if kind == "major":
                self.preview_canvas.create_text(
                    x0 - length - 1, y, text=self._major_tick_label(pos),
                    fill=text_c, font=("Arial", 6), anchor="e", tags=tag,
                )

        self.preview_canvas.create_line(x0, y0, x1, y0, fill=tick_c, width=1, tags=tag)
        self.preview_canvas.create_line(x0, y0, x0, y1, fill=tick_c, width=1, tags=tag)
        self.preview_canvas.create_text(
            x1 - 3, y0 - 2, text=self._format_media_label(pw), fill=self.color_mint,
            font=("Arial", 7, "bold"), anchor="se", tags=tag,
        )
        self.preview_canvas.create_text(
            x0, y1 + 6, text=self._format_media_label(ph), fill=self.color_mint,
            font=("Arial", 7, "bold"), anchor="n", tags=tag,
        )

    def _format_media_label(self, pts):
        unit = self._ruler_unit_label()
        val = self.points_to_global_unit(pts)
        if unit == "mm":
            return f"{val:.1f} {unit}"
        if unit == "pt":
            return f"{val:.0f} {unit}"
        return f"{val:.3f} {unit}"

    def _clear_ruler_hover(self, event=None):
        try:
            self.preview_canvas.delete("ruler_hover")
        except Exception:
            pass

    def _on_preview_motion(self, event):
        if not self.show_measurements_var.get():
            self._clear_ruler_hover()
            return
        if not getattr(self, "preview_img_w", 0) or not getattr(self, "preview_final_scale", 0):
            return
        pw = getattr(self, "preview_page_w_pt", 0.0) or 0.0
        ph = getattr(self, "preview_page_h_pt", 0.0) or 0.0
        if pw < 1 or ph < 1:
            return
        cx = self.preview_canvas.canvasx(event.x)
        cy = self.preview_canvas.canvasy(event.y)
        x0 = self.preview_pos_x - (self.preview_img_w / 2.0)
        y0 = self.preview_pos_y - (self.preview_img_h / 2.0)
        x1 = self.preview_pos_x + (self.preview_img_w / 2.0)
        y1 = self.preview_pos_y + (self.preview_img_h / 2.0)
        band = self.ruler_band
        if cx < x0 - band or cy < y0 - band or cx > x1 + 10 or cy > y1 + 10:
            self._clear_ruler_hover()
            return
        pdf_x = max(0.0, min(pw, (cx - x0) / self.preview_final_scale))
        pdf_y = max(0.0, min(ph, (cy - y0) / self.preview_final_scale))
        hx = x0 + pdf_x * self.preview_final_scale
        hy = y0 + pdf_y * self.preview_final_scale
        self.preview_canvas.delete("ruler_hover")
        tag = "ruler_hover"
        hair = self.color_lime
        self.preview_canvas.create_line(hx, y0, hx, hy, fill=hair, width=1, dash=(3, 2), tags=tag)
        self.preview_canvas.create_line(x0, hy, hx, hy, fill=hair, width=1, dash=(3, 2), tags=tag)
        self.preview_canvas.create_line(hx, y0 - 10, hx, y0, fill=hair, width=2, tags=tag)
        self.preview_canvas.create_line(x0 - 10, hy, x0, hy, fill=hair, width=2, tags=tag)
        left_txt = f"Left  {self._format_edge_measure(pdf_x)}"
        top_txt = f"Top   {self._format_edge_measure(pdf_y)}"
        vx0 = self.preview_canvas.canvasx(0)
        vy0 = self.preview_canvas.canvasy(0)
        vx1 = self.preview_canvas.canvasx(self.preview_canvas.winfo_width())
        vy1 = self.preview_canvas.canvasy(self.preview_canvas.winfo_height())
        box_w, box_h = 188, 38
        bx = hx + 14
        by = hy + 14
        if bx + box_w > vx1 - 6:
            bx = hx - box_w - 12
        if by + box_h > vy1 - 6:
            by = hy - box_h - 12
        if bx < vx0 + 6:
            bx = vx0 + 6
        if by < vy0 + 6:
            by = vy0 + 6
        self.preview_canvas.create_rectangle(
            bx, by, bx + box_w, by + box_h,
            fill=self.color_pale, outline=self.color_navy, width=1, tags=tag,
        )
        self.preview_canvas.create_text(
            bx + 8, by + 10, text=left_txt, fill=self.color_navy,
            font=("Arial", 8, "bold"), anchor="w", tags=tag,
        )
        self.preview_canvas.create_text(
            bx + 8, by + 26, text=top_txt, fill=self.color_navy,
            font=("Arial", 8, "bold"), anchor="w", tags=tag,
        )

    def draw_fold_overlays(self):
        self.preview_canvas.delete("fold_overlay")
        if getattr(self, "current_active_tab", "") != "Folds":
            return
        if not getattr(self, "preview_img_w", 0):
            return
        layout = self._current_fold_layout()
        origin_x = self.preview_pos_x - self.preview_img_w / 2.0
        origin_y = self.preview_pos_y - self.preview_img_h / 2.0
        if self.fold_art_has_bleed_var.get():
            target_w, target_h = layout["sheet_w"], layout["sheet_h"]
            offx = offy = 0.0
        else:
            trim = layout["trim"]
            target_w, target_h = trim.width, trim.height
            offx, offy = trim.x0, trim.y0
        s = min(self.preview_img_w / max(target_w, 1.0), self.preview_img_h / max(target_h, 1.0))
        origin_x += (self.preview_img_w - target_w * s) / 2.0
        origin_y += (self.preview_img_h - target_h * s) / 2.0

        def to_canvas(x, y):
            return origin_x + (x - offx) * s, origin_y + (y - offy) * s

        def box(rect, outline, width=2, dash=None):
            x0, y0 = to_canvas(rect.x0, rect.y0)
            x1, y1 = to_canvas(rect.x1, rect.y1)
            kwargs = {"outline": outline, "width": width, "tags": "fold_overlay"}
            if dash:
                kwargs["dash"] = dash
            self.preview_canvas.create_rectangle(x0, y0, x1, y1, **kwargs)

        if self.fold_art_has_bleed_var.get():
            box(layout["bleed_rect"], "#e040fb", 1)
        box(layout["trim"], "#00e5ff", 2)
        for x1, y1, x2, y2 in layout["fold_lines"]:
            a = to_canvas(x1, y1)
            b = to_canvas(x2, y2)
            self.preview_canvas.create_line(a[0], a[1], b[0], b[1], fill="#43a047", width=2, dash=(6, 3), tags="fold_overlay")
        for item in layout["labels"]:
            rect = item["rect"]
            cx, cy = to_canvas((rect.x0 + rect.x1) / 2.0, (rect.y0 + rect.y1) / 2.0)
            self.preview_canvas.create_text(
                cx, cy, text=item["text"], fill="#1b5e20", font=("Arial", 9, "bold"), tags="fold_overlay",
            )

    def navigate_file(self, direction):
        show_one = getattr(self, "_preview_selected_file", False) and not self.preview_merge_var.get()
        if not self.files or self.preview_merge_var.get():
            return
        if self._join_in_viewed_steps() and not show_one:
            return
        target = self.current_preview_file_index + direction
        if 0 <= target < len(self.files):
            self._preview_selected_file = True
            self.current_preview_file_index = target
            self.current_preview_page = 0
            self._select_asset_row(target)
            self.render_live_preview()

    def navigate_preview(self, direction):
        if not self.preview_doc: 
            return
        target = self.current_preview_page + direction
        if 0 <= target < len(self.preview_doc):
            self.current_preview_page = target
            self.render_live_preview()

    def draw_vdp_overlays(self):
        if not hasattr(self, 'preview_img_w') or self.preview_img_w == 0: return
        self.preview_canvas.delete("vdp_overlay")
        
        if getattr(self, 'current_active_tab', '') != "VDP":
            return
        
        def _draw(x_in, y_in, w_in, h_in, color, label, dash=None, rotate=0):
            try:
                x = self.to_points(x_in) * self.preview_final_scale
                y = self.to_points(y_in) * self.preview_final_scale
                w = self.to_points(w_in) * self.preview_final_scale
                h = self.to_points(h_in) * self.preview_final_scale
                
                x0 = (self.preview_pos_x - self.preview_img_w / 2.0) + x
                y0 = (self.preview_pos_y - self.preview_img_h / 2.0) + y
                x1, y1 = x0 + w, y0 + h
                angle = field_rotation({"rotate": rotate})
                
                kwargs = {"outline": color, "width": 2, "tags": "vdp_overlay"}
                if dash: kwargs["dash"] = dash
                if angle < 0.5:
                    self.preview_canvas.create_rectangle(x0, y0, x1, y1, **kwargs)
                    label_x, label_y = x0, y0
                else:
                    cx, cy = (x0 + x1) / 2.0, (y0 + y1) / 2.0
                    corners = []
                    for px, py in ((x0, y0), (x1, y0), (x1, y1), (x0, y1)):
                        rx, ry = self._rotate_offset(px - cx, py - cy, angle)
                        corners.extend((cx + rx, cy + ry))
                    self.preview_canvas.create_polygon(corners, fill="", **kwargs)
                    label_x, label_y = corners[0], corners[1]
                
                self.preview_canvas.create_rectangle(label_x, label_y, label_x + len(str(label))*7 + 10, label_y + 16, fill="white", outline=color, tags="vdp_overlay")
                self.preview_canvas.create_text(label_x + 4, label_y + 8, text=str(label), fill=color, anchor="w", font=("Arial", 9, "bold"), tags="vdp_overlay")
            except Exception: pass

        for field in self.vdp_mapped_fields:
            if self._vdp_field_on_current_page(field):
                _draw(
                    field.get("x", 0), field.get("y", 0), field.get("w", 2.0), field.get("h", 0.5),
                    "#27ae60", f"<<{field.get('column', 'Field')}>>", rotate=field.get("rotate", 0),
                )
            
        show_ghost = bool(self.vdp_mapped_fields) or getattr(self, "_vdp_place_armed", False)
        if self.vdp_selected_index is not None and 0 <= self.vdp_selected_index < len(self.vdp_mapped_fields):
            show_ghost = self._vdp_field_on_current_page(self.vdp_mapped_fields[self.vdp_selected_index])
        if show_ghost:
            try:
                _draw(self.vdp_x_var.get(), self.vdp_y_var.get(), self.vdp_w_var.get(), self.vdp_h_var.get(), "#2980b9", f"<<{self.vdp_col_var.get() or 'Current Target'}>>", dash=(4,4), rotate=self.vdp_rotate_var.get())
            except ValueError:
                pass

    def handle_history_selection(self, event):
        selected = self.queue_box.curselection()
        if not selected: 
            return
        self.active_history_index = selected[0]
        self.current_preview_page = 0
        step = self._selected_step()
        if step and step.get("type") == "Join PDFs":
            self._preview_selected_file = False
        if step:
            self._load_stack_step_into_pane(step)
        self._sync_step_commit_buttons()
        self.render_live_preview()

    def move_queue_step(self, direction):
        selected = self.queue_box.curselection()
        if not selected: 
            return
        old_idx = selected[0]
        new_idx = old_idx + direction
        if 0 <= new_idx < len(self.action_queue):
            self.action_queue[old_idx], self.action_queue[new_idx] = self.action_queue[new_idx], self.action_queue[old_idx]
            texts = self.queue_box.get(0, tk.END)
            self.queue_box.delete(0, tk.END)
            for idx, text in enumerate(texts):
                if idx == old_idx: 
                    self.queue_box.insert(tk.END, texts[new_idx])
                elif idx == new_idx: 
                    self.queue_box.insert(tk.END, texts[old_idx])
                else: 
                    self.queue_box.insert(tk.END, text)
            self.queue_box.selection_set(new_idx)
            self.active_history_index = new_idx
            self.render_live_preview()

    def remove_queue_step(self):
        selected = self.queue_box.curselection()
        if not selected: 
            return
        idx = selected[0]
        self.action_queue.pop(idx)
        self.queue_box.delete(idx)
        self.active_history_index = max(0, idx - 1) if self.action_queue else -1
        if self.active_history_index != -1: 
            self.queue_box.selection_set(self.active_history_index)
        self.render_live_preview()

    def clear_queue(self):
        self.action_queue.clear()
        self.queue_box.delete(0, tk.END)
        self.active_history_index = -1
        self.render_live_preview()

    def export_as_images(self):
        if not self.preview_doc: 
            return
        folder = filedialog.askdirectory(title="Select Destination Directory")
        if not folder: 
            return
        for idx in range(len(self.preview_doc)):
            img = render_page_image(self.preview_doc, idx, 2.0, annots=True)
            img.save(os.path.join(folder, f"ReadySetPDF_Proof_Spread_{idx+1}.png"))
        messagebox.showinfo("Proofs Generated", "PNG mockups generated.")
        
    def run_sanitizer(self):
        filepath = filedialog.askopenfilename(title="Select Corrupt PDF to Sanitize", filetypes=[("PDF Files", "*.pdf")])
        if not filepath:
            return
            
        try:
            src_doc = pdfdoc.open(filepath)
            clean_doc = pdfdoc.open()

            for page in src_doc:
                r = page.rect
                new_p = clean_doc.new_page(width=r.width, height=r.height)
                new_p.show_pdf_page(new_p.rect, src_doc, page.number, clip=page.rect)

            out_dir = os.path.dirname(filepath)
            base_name = os.path.splitext(os.path.basename(filepath))[0]
            out_path = os.path.join(out_dir, f"{base_name}_sanitized.pdf")

            clean_doc.save(out_path, garbage=4, deflate=True, clean=True)
            clean_doc.close()
            src_doc.close()

            messagebox.showinfo("Sanitization Complete", f"File successfully rebuilt!\n\nSaved as: {base_name}_sanitized.pdf\n\nPlease load this new clean version into your Assets Manager.")

        except Exception as e:
            messagebox.showerror("Sanitizer Failed", f"The engine could not process the file:\n{str(e)}")

    def _pick_recipe_file(self):
        folder = self._dialog_folder("recipe_folder")
        chosen = None
        if os.name == "nt":
            try:
                hwnd = int(self.root.winfo_id())
            except Exception:
                hwnd = 0
            chosen = _windows_pick_files(
                hwnd, "Load Recipe", initial_dir=folder, filters=_RECIPE_FILE_FILTERS, multi=False,
            )
        if chosen is None:
            kwargs = {
                "parent": self.root,
                "title": "Load Recipe",
                "filetypes": [("JSON Recipe", "*.json")],
            }
            if folder:
                kwargs["initialdir"] = folder
            try:
                chosen = filedialog.askopenfilename(**kwargs)
            except Exception as exc:
                messagebox.showerror("Load Recipe", f"Could not open the file picker.\n{exc}", parent=self.root)
                return ""
            path = str(chosen or "")
            if path:
                self._remember_dialog_folder("recipe_folder", path)
            return path
        if not chosen:
            return ""
        path = str(chosen[0])
        self._remember_dialog_folder("recipe_folder", path)
        return path

    def _pick_save_recipe(self):
        folder = self._dialog_folder("recipe_folder")
        chosen = None
        if os.name == "nt":
            try:
                hwnd = int(self.root.winfo_id())
            except Exception:
                hwnd = 0
            chosen = _windows_pick_files(
                hwnd, "Save Recipe", initial_dir=folder, filters=_RECIPE_FILE_FILTERS, multi=False, save=True,
            )
        if chosen is None:
            kwargs = {
                "parent": self.root,
                "title": "Save Recipe",
                "defaultextension": ".json",
                "filetypes": [("JSON Recipe", "*.json")],
            }
            if folder:
                kwargs["initialdir"] = folder
            try:
                chosen = filedialog.asksaveasfilename(**kwargs)
            except Exception as exc:
                messagebox.showerror("Save Recipe", f"Could not open the file picker.\n{exc}", parent=self.root)
                return ""
            path = str(chosen or "")
            if path:
                self._remember_dialog_folder("recipe_folder", path)
            return path
        if not chosen:
            return ""
        path = str(chosen[0])
        if path and not path.lower().endswith(".json"):
            path += ".json"
        self._remember_dialog_folder("recipe_folder", path)
        return path

    def load_pdfs(self):
        files = self._pick_asset_files()
        if files:
            self._accept_input_paths(files)

    def _pick_asset_files(self):
        """Open a multi-select file dialog. Drag-and-drop already accepts more than one file."""
        chosen = None
        if os.name == "nt":
            try:
                hwnd = int(self.root.winfo_id())
            except Exception:
                hwnd = 0
            chosen = _windows_pick_files(
                hwnd, "Add Files", initial_dir=self._dialog_folder("asset_folder"),
            )
        if chosen is None:
            kwargs = {
                "parent": self.root,
                "title": "Add Files",
                "filetypes": [
                    ("PDF & Images", "*.pdf *.png *.jpg *.jpeg *.tif *.tiff"),
                    ("PDF", "*.pdf"),
                    ("Images", "*.png *.jpg *.jpeg *.tif *.tiff"),
                    ("All files", "*.*"),
                ],
            }
            folder = self._dialog_folder("asset_folder")
            if folder:
                kwargs["initialdir"] = folder
            try:
                chosen = filedialog.askopenfilenames(**kwargs)
            except Exception as exc:
                messagebox.showerror("Add Files", f"Could not open the file picker.\n{exc}", parent=self.root)
                return []
        if not chosen:
            return []
        if isinstance(chosen, str):
            try:
                chosen = list(self.root.tk.splitlist(chosen))
            except Exception:
                chosen = [chosen]
        return [str(path) for path in chosen if str(path).strip()]

    def _accept_input_paths(self, paths):
        added = False
        errors = []
        allowed = (".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff")
        incoming = [path for path in paths if str(path).lower().endswith(allowed)]
        if incoming:
            self._remember_dialog_folder("asset_folder", incoming[0])
        limited = False
        if not licensing.allows_multiple_files(self.license_state):
            if self.files:
                messagebox.showinfo(
                    "Free",
                    "Free includes one file at a time.",
                    parent=self.root,
                )
                open_license_dialog(self)
                return
            if len(incoming) > 1:
                incoming = incoming[:1]
                limited = True
        for path in incoming:
            try:
                ready = prepare_input(path)
            except IntakeError as exc:
                errors.append(str(exc))
                continue
            if ready and ready not in self.files:
                self.files.append(ready)
                added = True
        if added:
            self.refresh_file_list()
        if limited:
            messagebox.showinfo(
                "Free",
                "Free includes one file at a time. Only the first file was added.",
                parent=self.root,
            )
            open_license_dialog(self)
        if errors:
            messagebox.showerror("Could not open file", "\n\n".join(errors), parent=self.root)

    def _register_file_drop(self, widget):
        try:
            widget.drop_target_register(DND_FILES)
            widget.dnd_bind("<<Drop>>", self.drop_files)
        except Exception:
            pass

    def _parse_drop_paths(self, data):
        raw = data if isinstance(data, str) else str(data or "")
        parts = []
        try:
            parts = list(self.root.tk.splitlist(raw))
        except Exception:
            parts = []
        if not parts and raw.strip():
            parts = [raw]
        paths = []
        exts = (".pdf", ".png", ".jpg", ".jpeg", ".tif", ".tiff", ".json")
        for part in parts:
            p = normalize_input_path(part)
            if p.lower().endswith(exts):
                paths.append(p)
        return paths

    def drop_files(self, event):
        paths = self._parse_drop_paths(getattr(event, "data", ""))
        recipes = [path for path in paths if path.lower().endswith(".json")]
        assets = [path for path in paths if not path.lower().endswith(".json")]
        if assets:
            self._accept_input_paths(assets)
        if not recipes:
            return
        self.load_recipe(recipes[0])
        if len(recipes) > 1:
            messagebox.showinfo(
                "Recipe",
                "Loaded the first JSON recipe.\nDrop one recipe at a time to load another.",
                parent=self.root,
            )

    def refresh_file_list(self):
        self.file_list.delete(0, tk.END)
        for f in self.files: 
            self.file_list.insert(tk.END, os.path.basename(f))
        self.current_preview_page = 0
        if self.current_preview_file_index >= len(self.files):
            self.current_preview_file_index = max(0, len(self.files) - 1)
        self.active_history_index = len(self.action_queue) - 1 if self.action_queue else -1
        self._refresh_page_geometry_summary()
        if hasattr(self, "_refresh_join_split_example"):
            self._refresh_join_split_example()
        self.render_live_preview()

    def clear_files(self):
        self.files.clear()
        self.file_list.delete(0, tk.END)
        self.current_preview_file_index = 0
        self._refresh_page_geometry_summary()
        self.clear_queue()

    def add_bg_task(self, task_name):
        if task_name and task_name not in self.background_tasks:
            self.background_tasks.append(task_name)
        self._refresh_engine_summary()

    def remove_bg_task(self, task_name):
        while task_name in self.background_tasks:
            self.background_tasks.remove(task_name)
        self._refresh_engine_summary()

if __name__ == "__main__":
    app = ReadySetPDFApp()
    app.root.update()
    app.render_live_preview()
    app.root.mainloop()
