"""ReadySetPDF license and trial files.

    %APPDATA%\\ReadySetPDF\\trial.json
    %APPDATA%\\ReadySetPDF\\license.json

A Pro license (edition "pro", or a file that lists all six packs) stays on.
With no license, the first 30 days from trial.json unlock every pack.
After that, only the free core stays on.
"""

import hashlib
import hmac
import json
import os
import urllib.error
import urllib.request
from datetime import date, datetime, timedelta, timezone

APP_NAME = "ReadySetPDF"
TRIAL_FILENAME = "trial.json"
LICENSE_FILENAME = "license.json"
TRIAL_DAYS = 30
RENEWAL_NOTICE_DAYS = 30
TEST_PRO_KEY = "RSP-TEST-PRO"
MASTER_ADMIN_KEY = "RSP-ADMIN-MASTER-9999"
MAX_DEVICE_ACTIVATIONS = 3

LS_STORE_ID = "IDF1401742"
LS_STORE_DOMAIN = "readysetpdf1.lemonsqueezy.com"
LS_MONTHLY_PRODUCT_ID = "1407665"
LS_YEARLY_PRODUCT_ID = "1407666"
LS_MONTHLY_VARIANT_ID = "2197610"
LS_YEARLY_VARIANT_ID = "2197615"
# Public checkout links use the share slug, not the numeric variant id.
LS_MONTHLY_CHECKOUT_ID = "e2520fe5-0535-42cd-908e-e4aa13be87b0"
LS_YEARLY_CHECKOUT_ID = "eab55f46-16d5-4b95-92d0-0168e9147296"
LS_API_KEY = (
    "eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9."
    "eyJhdWQiOiI5NGQ1OWNlZi1kYmI4LTRlYTUtYjE3OC1kMjU0MGZjZDY5MTkiLCJqdGkiOiI0Zjg3NWNiZjkzZTAzMDAzNjI2Y2M0OTdiNWNhZmRlMTIxMjMyNmUxMWRkNDNhMTRjYTMwYzU2YjM3ymViNThiODZmNmQzNWE4NDQxYmU5MCIsImlhdCI6MTc5MDk3ODI4NC42ODI1LCJuYmYiOjE3OTA5NzgyODQuNjgyNTAyLCJleHAiOjE4MDY2MjQwMDAuMDI1ODk0LCJzdWIiOiI4MDc1NDE0Iiwic2NvcGVzIjpbXX0."
    "mNep_cjEbQbt--4moDp2HRqDpQHv8XDZgQ23MDXtzZV2mpQRMwJbGKzyYFYbYkLYbZGQB5BKJqE7SVZQwm7HnD29cw0AQB44qaIdRWs7ly0xXArfGfWfBDpy-0e08LTMSdnMDAY2VMf3vBMFHvNs7_PezuTufGcLYVFhboTNydE7wDkRyeIRbg3JEHYvkjuuV0jzmOGS6O1OCuLkZ8MPaw-AA8U4wBk7DYWIEOS6WSOgHzEiG7RyGdSLIdeOAUabbHQSMMh1Y1AmbKKMjCeSigByWU8oPkiRpzzZ7naUgnDo2VZjGXD0WKG4WL6_sTrL048p3nfLq0U04YcYCvbVxLkiOU0NG0uN0CH55TyC2GCggUYKQ8I0mMjHeFAlnJsqeJHTunj3zMPT57J8ISFFX7OIihCWO0a_QMO5UkunMdWA8o9Yx6pvbFxVl8cyEwmZ2k6cpDZSMhT6AL-i0uW87osVfwtDmppFasy_LLNRug8DW49EraOgeBE7WmzXka0rJ-Mm-4XRK8JtwDsUx0x129q9ve_M0qD5CNqgZj_3y-DilbQzuV7iTozpb5DrHeRlIng0msyf73OXrmv9VcV3YkmzWm_Em2KN_4U2VyUacYM8orewSxsL_rAWTOeX6Y1mnR1LSGST_amYu2ap4mzFiQoZFa3En7QCea4Oo2oQRTo"
)
LS_ACTIVATE_URL = "https://api.lemonsqueezy.com/v1/licenses/activate"
LS_VALIDATE_URL = "https://api.lemonsqueezy.com/v1/licenses/validate"
LS_DEACTIVATE_URL = "https://api.lemonsqueezy.com/v1/licenses/deactivate"
VALIDATE_URL = LS_VALIDATE_URL
_CHECKOUT_BASE = f"https://{LS_STORE_DOMAIN}"
MONTHLY_CHECKOUT_URL = f"{_CHECKOUT_BASE}/checkout/buy/{LS_MONTHLY_CHECKOUT_ID}"
YEARLY_CHECKOUT_URL = f"{_CHECKOUT_BASE}/checkout/buy/{LS_YEARLY_CHECKOUT_ID}"
CHECKOUT_URL = os.environ.get("READYSETPDF_CHECKOUT_URL", _CHECKOUT_BASE)
_OFFLINE_SECRET = b"ReadySetPDF.offline.enterprise.v1"
ACTIVATED_MESSAGE = "License activated. Pro is unlocked on this computer."
ADMIN_MESSAGE = "Admin license accepted. Pro is unlocked on this computer."
VALID_MESSAGE = "License checked. Pro is unlocked on this computer."
DEVICE_LIMIT_MESSAGE = (
    "This license is already active on 3 computers. "
    "Deactivate one in Lemon Squeezy, then try again."
)

# Paid tools. Resize, Crop, Rotate, Cutter, Unlock, and Folds stay free.
PACKS = ("vdp", "color", "hotfolder", "ocr", "booklet", "monkey", "grid", "preflight")
# Older license files named one impose pack and a separate preflight pack.
LEGACY_PACKS = ("vdp", "impose", "hotfolder", "preflight", "color", "ocr")

# Tool-tab key -> pack. Tabs not listed are always on.
TOOL_PACK = {
    "VDP": "vdp",
    "Color": "color",
    "Automation": "hotfolder",
    "OCR": "ocr",
    "Booklet": "booklet",
    "Grid": "grid",
    "Preflight": "preflight",
}

FREE_TOOLS = "Free: Resize, Crop, Rotate, Cutter, Join / Split, Unlock, Folds"
PRO_TOOLS = "Pro: Mail Merge, Color, Automation, OCR, Preflight, Booklet, Grid"
PAID_TIERS = ("pro_monthly", "yearly")


def app_dir():
    root = os.environ.get("APPDATA")
    if not root:
        root = os.path.join(os.path.expanduser("~"), "AppData", "Roaming")
    return os.path.join(root, APP_NAME)


def trial_path():
    return os.path.join(app_dir(), TRIAL_FILENAME)


def license_path():
    return os.path.join(app_dir(), LICENSE_FILENAME)


def _all_on():
    return {pack: True for pack in PACKS}


def _all_off():
    return {pack: False for pack in PACKS}


def _parse_date(value):
    text = str(value or "").strip()
    if not text:
        return None
    text = text[:10]
    try:
        return datetime.strptime(text, "%Y-%m-%d").date()
    except ValueError:
        return None


def _read_json(path):
    with open(path, "r", encoding="utf-8") as handle:
        data = json.load(handle)
    return data


def ensure_trial():
    """Create trial.json with today's date only when the file is missing.

    An existing file is never rewritten, even if it is empty or unreadable.
    """
    path = trial_path()
    os.makedirs(os.path.dirname(path), exist_ok=True)
    if os.path.exists(path):
        return path
    started = date.today()
    payload = json.dumps({
        "started": started.isoformat(),
        "expires": (started + timedelta(days=TRIAL_DAYS)).isoformat(),
    }, indent=2) + "\n"
    try:
        with open(path, "x", encoding="utf-8") as handle:
            handle.write(payload)
    except FileExistsError:
        pass
    return path


def _trial_start():
    path = trial_path()
    if not os.path.isfile(path):
        return None
    try:
        data = _read_json(path)
    except Exception:
        return None
    if isinstance(data, str):
        return _parse_date(data)
    if isinstance(data, dict):
        for key in ("started", "start", "date", "trial_start"):
            found = _parse_date(data.get(key))
            if found is not None:
                return found
    return None


def _trial_days_left(started):
    if started is None:
        return 0
    elapsed = (date.today() - started).days
    if elapsed < 0:
        elapsed = 0
    remaining = TRIAL_DAYS - elapsed
    return remaining if remaining > 0 else 0


def _listed_packs(data):
    raw = data.get("packs")
    if raw is None:
        raw = data.get("features")
    names = set()
    if isinstance(raw, dict):
        for key, enabled in raw.items():
            if enabled:
                names.add(str(key).strip().lower())
    elif isinstance(raw, (list, tuple)):
        names = {str(item).strip().lower() for item in raw}
    return names


def _license_expiry(data):
    """Return the expiry date, or None when this license does not expire.

    A missing, blank, or unreadable date stays open-ended so an existing Pro
    file cannot lock the machine.
    """
    if "expires" in data:
        raw = data.get("expires")
    elif "expires_at" in data:
        raw = data.get("expires_at")
    else:
        return None
    if raw is None or str(raw).strip() == "":
        return None
    return _parse_date(raw)


def _normalize_plan(value, expires):
    plan = str(value or "").strip().lower()
    if plan in ("yearly", "annual", "year"):
        return "yearly"
    if plan in ("monthly", "month"):
        return "monthly"
    if plan in ("perpetual", "lifetime", "permanent"):
        return "perpetual"
    if expires is None:
        return "perpetual"
    return "term"


def read_pro_license():
    """Return the active Pro record, or None when this file is not active Pro.

    Edition "pro", or a file that lists all six packs, stays Pro.
    No expiry (or a blank expiry) is perpetual and never locks this machine.
    A dated license stays Pro through its expiry date, then drops off.
    """
    path = license_path()
    if not os.path.isfile(path):
        return None
    try:
        data = _read_json(path)
    except Exception:
        return None
    if not isinstance(data, dict):
        return None
    edition = str(data.get("edition") or "").strip().lower()
    tier = str(data.get("tier") or "").strip().lower()
    status = str(data.get("status") or "").strip().lower()
    if status in ("invalid", "expired", "disabled", "revoked"):
        return None
    listed = _listed_packs(data)
    full_set = all(pack in listed for pack in PACKS) or all(pack in listed for pack in LEGACY_PACKS)
    paid_tier = tier in PAID_TIERS or tier in ("monthly", "annual", "pro")
    if status in ("valid", "active") and paid_tier:
        edition = "pro"
    if edition != "pro" and not full_set:
        return None
    expires = _license_expiry(data)
    if expires is not None and expires < date.today():
        return None
    days_left = None if expires is None else (expires - date.today()).days
    stored_plan = _normalize_plan(data.get("plan"), expires)
    if stored_plan == "perpetual":
        plan = "perpetual"
    elif tier in ("pro_monthly", "monthly"):
        plan = "monthly"
    elif tier in ("yearly", "annual"):
        plan = "yearly"
    else:
        plan = stored_plan
    return {
        "packs": _all_on(),
        "plan": plan,
        "days_left": days_left,
        "tier": "pro_monthly" if plan == "monthly" else "yearly",
    }


def load_state():
    """Ensure a first-run trial file exists, then describe what is unlocked.

    A Pro license wins over the trial. Creating trial.json never turns Pro off.
    """
    ensure_trial()
    licensed = read_pro_license()
    if licensed is not None:
        return {
            "status": "pro",
            "plan": licensed["plan"],
            "days_left": licensed["days_left"],
            "packs": licensed["packs"],
        }
    remaining = _trial_days_left(_trial_start())
    if remaining > 0:
        return {
            "status": "trial",
            "plan": None,
            "days_left": remaining,
            "packs": _all_on(),
        }
    return {
        "status": "free",
        "plan": None,
        "days_left": 0,
        "packs": _all_off(),
    }


def tool_unlocked(tool_key, state=None):
    pack = TOOL_PACK.get(tool_key)
    if not pack:
        return True
    state = state if state is not None else load_state()
    return bool(state.get("packs", {}).get(pack))


def _span_phrase(days):
    days = int(days or 0)
    if days <= 0:
        return "ends today"
    if days == 1:
        return "1 day left"
    return f"{days} days left"


def footer_text(state):
    """Short status for the bottom-right corner."""
    status = state.get("status")
    if status == "trial":
        return f"Trial · {_span_phrase(state.get('days_left'))}"
    if status != "pro":
        return "Free"
    plan = state.get("plan") or "perpetual"
    days = state.get("days_left")
    if plan == "monthly":
        if days is None:
            return "Pro · Monthly"
        return f"Pro · Monthly · {_span_phrase(days)}"
    if plan == "yearly":
        if days is not None and days <= RENEWAL_NOTICE_DAYS:
            return f"Pro · Yearly · {_span_phrase(days)}"
        return "Pro · Yearly"
    if days is not None and days <= RENEWAL_NOTICE_DAYS:
        return f"Pro · {_span_phrase(days)}"
    return "Pro · Licensed"


def status_line(state):
    status = state.get("status")
    if status == "pro":
        plan = state.get("plan") or "perpetual"
        days = state.get("days_left")
        if plan == "yearly":
            if days is not None and days <= RENEWAL_NOTICE_DAYS:
                return f"Status: Pro · Yearly ({_span_phrase(days)})"
            return "Status: Pro · Yearly"
        if plan == "monthly":
            if days is None:
                return "Status: Pro · Monthly"
            return f"Status: Pro · Monthly ({_span_phrase(days)})"
        if days is not None and days <= RENEWAL_NOTICE_DAYS:
            return f"Status: Pro ({_span_phrase(days)})"
        return "Status: Pro"
    if status == "trial":
        n = int(state.get("days_left") or 0)
        unit = "day" if n == 1 else "days"
        return f"Status: Trial ({n} {unit} left)"
    return "Status: Free"


def status_sentence(state):
    status = state.get("status")
    if status == "trial":
        return "All tools unlocked for 30 days."
    if status != "pro":
        return "Core tools only. One file at a time. Enter a license to unlock Pro."
    plan = state.get("plan") or "perpetual"
    days = state.get("days_left")
    if plan == "monthly" and days is not None:
        return f"Pro is active. {_span_phrase(days).capitalize()} on this monthly license."
    if plan == "yearly" and days is not None and days <= RENEWAL_NOTICE_DAYS:
        return f"Pro is active. {_span_phrase(days).capitalize()} on this yearly license."
    if days is not None and days <= RENEWAL_NOTICE_DAYS and plan != "perpetual":
        return f"Pro is active. {_span_phrase(days).capitalize()} on this license."
    return "Pro is active. All tools unlocked."


def allows_multiple_files(state=None):
    """Free Core is one file. Trial and paid tiers can open more than one."""
    state = state if state is not None else load_state()
    return state.get("status") in ("trial", "pro")


def _write_json(path, payload):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    temporary = path + ".tmp"
    with open(temporary, "w", encoding="utf-8") as handle:
        json.dump(payload, handle, indent=2)
        handle.write("\n")
    os.replace(temporary, path)


def _read_license_record():
    path = license_path()
    if not os.path.isfile(path):
        return None
    try:
        data = _read_json(path)
    except Exception:
        return None
    return data if isinstance(data, dict) else None


def issue_offline_key(tier="yearly", expires=None):
    """Build a manually issued offline key. expires is YYYY-MM-DD or None."""
    tier = "pro_monthly" if str(tier).strip().lower() in ("monthly", "pro_monthly") else "yearly"
    exp = "none" if not expires else str(expires)[:10]
    body = f"{tier}|{exp}".encode("utf-8")
    sig = hmac.new(_OFFLINE_SECRET, body, hashlib.sha256).hexdigest()[:20]
    return f"RSP-ENT.{tier}.{exp}.{sig}"


def _keys_match(left, right):
    a = str(left or "").strip()
    b = str(right or "").strip()
    if len(a) != len(b) or not a:
        return False
    return hmac.compare_digest(a, b)


def _is_master_admin(key):
    return _keys_match(key, MASTER_ADMIN_KEY)


def _offline_grant(key):
    text = str(key or "").strip()
    if _is_master_admin(text):
        return {"tier": "yearly", "expires": None, "plan": "perpetual", "source": "admin"}
    if text == TEST_PRO_KEY:
        return {"tier": "yearly", "expires": None, "plan": "perpetual"}
    parts = text.split(".")
    if len(parts) != 4 or parts[0] != "RSP-ENT":
        return None
    _, tier, exp, sig = parts
    if tier not in PAID_TIERS:
        return None
    body = f"{tier}|{exp}".encode("utf-8")
    expected = hmac.new(_OFFLINE_SECRET, body, hashlib.sha256).hexdigest()[:20]
    try:
        matches = hmac.compare_digest(sig, expected)
    except (TypeError, ValueError):
        return None
    if not matches:
        return None
    expires = None if exp == "none" else _parse_date(exp)
    if exp != "none" and expires is None:
        return None
    if expires is not None and expires < date.today():
        return None
    return {"tier": tier, "expires": expires, "plan": "monthly" if tier == "pro_monthly" else "yearly"}


def _instance_name():
    return os.environ.get("COMPUTERNAME") or os.environ.get("HOSTNAME") or "ReadySetPDF"


def _as_int(value):
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _tier_from_names(meta):
    text = " ".join([
        str((meta or {}).get("variant_name") or ""),
        str((meta or {}).get("product_name") or ""),
    ]).lower()
    if "month" in text:
        return "pro_monthly"
    return "yearly"


def _tier_from_meta(meta):
    meta = meta or {}
    variant = str(meta.get("variant_id") or "").strip()
    product = str(meta.get("product_id") or "").strip()
    if variant == LS_MONTHLY_VARIANT_ID or product == LS_MONTHLY_PRODUCT_ID:
        return "pro_monthly"
    if variant == LS_YEARLY_VARIANT_ID or product == LS_YEARLY_PRODUCT_ID:
        return "yearly"
    return _tier_from_names(meta)


def _ls_headers():
    return {
        "Authorization": f"Bearer {LS_API_KEY}",
        "Accept": "application/json",
        "Content-Type": "application/json",
    }


def _ls_error(data, fallback):
    if not isinstance(data, dict):
        return fallback
    detail = data.get("error") or data.get("message") or ""
    return str(detail).strip() or fallback


def _is_device_limit_error(detail):
    text = str(detail or "").lower()
    return "activation limit" in text or ("limit" in text and "activat" in text)


def _ls_post(url, payload):
    """POST JSON to Lemon Squeezy. Raises ConnectionError when the server cannot be reached."""
    body = json.dumps(payload).encode("utf-8")
    request = urllib.request.Request(url, data=body, headers=_ls_headers(), method="POST")
    try:
        with urllib.request.urlopen(request, timeout=20) as response:
            raw = response.read().decode("utf-8")
    except urllib.error.HTTPError as exc:
        raw = exc.read().decode("utf-8", errors="replace")
        try:
            data = json.loads(raw) if raw else {}
        except json.JSONDecodeError as err:
            raise ConnectionError(f"License server returned {exc.code}.") from err
        if isinstance(data, dict) and (data.get("error") or data.get("valid") is False or data.get("activated") is False):
            return data
        if exc.code in (401, 403):
            raise ConnectionError("License server rejected the API credentials.")
        raise ConnectionError(_ls_error(data, f"License server returned {exc.code}."))
    except urllib.error.URLError as exc:
        raise ConnectionError("Could not reach the license server.") from exc
    try:
        data = json.loads(raw) if raw else {}
    except json.JSONDecodeError as exc:
        raise ConnectionError("License server sent an unreadable response.") from exc
    if not isinstance(data, dict):
        raise ConnectionError("License server sent an unreadable response.")
    return data


def _result_from_license(data, key, accepted):
    if not isinstance(data, dict) or not accepted:
        detail = _ls_error(data, "That license key is not valid.")
        if _is_device_limit_error(detail):
            detail = DEVICE_LIMIT_MESSAGE
        return {"valid": False, "error": detail}
    lic = data.get("license_key") or {}
    status = str(lic.get("status") or "active").strip().lower()
    if status in ("expired", "disabled", "inactive"):
        return {"valid": False, "error": "That license key is not active."}
    expires = _parse_date(str(lic.get("expires_at") or "")[:10])
    if expires is not None and expires < date.today():
        return {"valid": False, "error": "That license key has expired."}
    usage = _as_int(lic.get("activation_usage"))
    meta = data.get("meta") or {}
    tier = _tier_from_meta(meta)
    instance = data.get("instance") or {}
    instance_id = instance.get("id") or data.get("instance_id")
    return {
        "valid": True,
        "tier": tier,
        "expires": expires,
        "plan": "monthly" if tier == "pro_monthly" else "yearly",
        "key": key,
        "error": "",
        "instance_id": None if instance_id is None else str(instance_id),
        "variant_id": str(meta.get("variant_id") or ""),
        "product_id": str(meta.get("product_id") or ""),
        "activation_usage": usage,
        "activation_limit": _as_int(lic.get("activation_limit")),
    }


def _license_from_response(data, key):
    accepted = isinstance(data, dict) and bool(data.get("valid"))
    return _result_from_license(data, key, accepted)


def activate_lemonsqueezy(key):
    """Create a device activation. Raises ConnectionError when the server cannot be reached."""
    text = str(key or "").strip()
    if not text:
        return {"valid": False, "error": "Enter a license key."}
    data = _ls_post(LS_ACTIVATE_URL, {
        "license_key": text,
        "instance_name": _instance_name(),
    })
    result = _result_from_license(data, text, bool(data.get("activated")))
    usage = result.get("activation_usage")
    if result.get("valid") and usage is not None and usage > MAX_DEVICE_ACTIVATIONS:
        instance_id = result.get("instance_id") or (data.get("instance") or {}).get("id")
        if instance_id:
            _release_extra_activation(text, instance_id)
        return {"valid": False, "error": DEVICE_LIMIT_MESSAGE}
    return result


def _release_extra_activation(key, instance_id):
    """Drop an activation that pushed this key past the 3-computer limit."""
    try:
        _ls_post(LS_DEACTIVATE_URL, {
            "license_key": key,
            "instance_id": str(instance_id),
        })
    except ConnectionError:
        pass


def validate_lemonsqueezy(key, instance_id=None):
    """Check a key, and this computer's activation when an instance id is saved.

    Raises ConnectionError when the server cannot be reached.
    """
    text = str(key or "").strip()
    if not text:
        return {"valid": False, "error": "That license key is not valid."}
    payload = {"license_key": text}
    if instance_id:
        payload["instance_id"] = str(instance_id)
    data = _ls_post(LS_VALIDATE_URL, payload)
    result = _license_from_response(data, text)
    if not result.get("instance_id") and instance_id:
        result["instance_id"] = str(instance_id)
    return result


def _save_license(key, tier, status, expires, plan, source, instance_id=None, extra=None):
    paid = status == "valid" and tier in PAID_TIERS
    payload = {
        "license_key": key,
        "tier": tier if paid else "free",
        "status": status,
        "validated_at": datetime.now(timezone.utc).replace(microsecond=0).isoformat(),
        "expires": None if expires is None else (expires.isoformat() if hasattr(expires, "isoformat") else str(expires)[:10]),
        "source": source,
        "edition": "pro" if paid else "free",
        "plan": plan if paid else "free",
        "packs": list(PACKS) if paid else [],
        "instance_name": _instance_name(),
        "store_id": LS_STORE_ID,
    }
    if instance_id:
        payload["instance_id"] = str(instance_id)
    if isinstance(extra, dict):
        for field in ("variant_id", "product_id", "activation_usage", "activation_limit"):
            if extra.get(field) not in (None, ""):
                payload[field] = extra.get(field)
    try:
        _write_json(license_path(), payload)
    except OSError as exc:
        raise OSError(f"Could not save {license_path()}\n{exc}") from exc
    return payload


def _store_online_result(key, result, instance_id=None):
    plan = "monthly" if result["tier"] == "pro_monthly" else "yearly"
    saved_instance = result.get("instance_id") or instance_id
    return _save_license(
        key,
        result["tier"],
        "valid",
        result.get("expires"),
        plan,
        "lemonsqueezy",
        instance_id=saved_instance,
        extra=result,
    )


def _activate_offline(text, offline, success_message):
    source = offline.get("source") or "offline"
    try:
        _save_license(text, offline["tier"], "valid", offline["expires"], offline["plan"], source)
    except OSError as exc:
        return False, str(exc)
    return True, success_message


def activate(key):
    """Activate a key and store it. The admin key and offline keys skip the network.

    Returns (ok, message). A successful Lemon Squeezy activation is saved under AppData
    and reused on the next launch. Entering the same key again re-checks this computer
    instead of taking another device slot.
    """
    text = str(key or "").strip()
    if not text:
        return False, "Enter a license key."
    if _is_master_admin(text):
        return _activate_offline(
            text,
            {"tier": "yearly", "expires": None, "plan": "perpetual", "source": "admin"},
            ADMIN_MESSAGE,
        )
    offline = _offline_grant(text)
    if text == TEST_PRO_KEY or text.startswith("RSP-ENT."):
        if offline is None:
            return False, "That license key is not valid."
        return _activate_offline(text, offline, ACTIVATED_MESSAGE)
    saved = _read_license_record() or {}
    saved_key = str(saved.get("license_key") or "").strip()
    saved_instance = str(saved.get("instance_id") or "").strip()
    if saved_key == text and saved_instance and str(saved.get("status") or "").lower() in ("valid", "active"):
        try:
            existing = validate_lemonsqueezy(text, saved_instance)
        except ConnectionError as exc:
            return False, str(exc)
        except Exception as exc:
            return False, f"Could not reach the license server.\n{exc}"
        if existing.get("valid"):
            try:
                _store_online_result(text, existing, saved_instance)
            except OSError as exc:
                return False, str(exc)
            return True, "This computer is already activated. Pro is unlocked."
        if not _is_device_limit_error(existing.get("error")) and "instance" not in str(existing.get("error") or "").lower():
            return False, existing.get("error") or "That license key is not valid."
    try:
        result = activate_lemonsqueezy(text)
    except ConnectionError as exc:
        return False, str(exc)
    except Exception as exc:
        return False, f"Could not reach the license server.\n{exc}"
    if not result.get("valid"):
        return False, result.get("error") or "That license key is not valid."
    try:
        _store_online_result(text, result)
    except OSError as exc:
        return False, str(exc)
    return True, ACTIVATED_MESSAGE


def refresh_saved_license():
    """Re-check the saved key. An unreachable server leaves the saved license in place."""
    data = _read_license_record()
    if not data:
        return False, "No license key is saved."
    key = str(data.get("license_key") or "").strip()
    if not key:
        return False, "No license key is saved."
    offline = _offline_grant(key)
    if offline is not None:
        source = offline.get("source") or "offline"
        try:
            _save_license(key, offline["tier"], "valid", offline["expires"], offline["plan"], source)
        except OSError as exc:
            return False, str(exc)
        if source == "admin":
            return True, ADMIN_MESSAGE
        return True, "Offline key. Saved on this computer."
    instance_id = str(data.get("instance_id") or "").strip() or None
    try:
        result = validate_lemonsqueezy(key, instance_id)
    except ConnectionError as exc:
        return False, str(exc)
    except Exception as exc:
        return False, f"Could not reach the license server.\n{exc}"
    if not result.get("valid"):
        try:
            _save_license(
                key, "free", "invalid", None, "free", "lemonsqueezy",
                instance_id=instance_id,
            )
        except OSError as exc:
            return False, str(exc)
        return False, result.get("error") or "That license key is not valid."
    try:
        _store_online_result(key, result, instance_id)
    except OSError as exc:
        return False, str(exc)
    return True, VALID_MESSAGE


def validate_on_startup():
    """Check a saved Lemon Squeezy license when the app opens.

    Returns an error string when a saved license is no longer valid.
    Admin and offline keys stay local. A connection failure keeps the saved license.
    """
    data = _read_license_record()
    if not data:
        return None
    key = str(data.get("license_key") or "").strip()
    if not key or _offline_grant(key) is not None:
        return None
    if str(data.get("source") or "") in ("admin", "offline"):
        return None
    previous = str(data.get("status") or "").strip().lower()
    was_pro = previous in ("valid", "active") or str(data.get("edition") or "").strip().lower() == "pro"
    instance_id = str(data.get("instance_id") or "").strip() or None
    try:
        result = validate_lemonsqueezy(key, instance_id)
    except ConnectionError:
        return None
    except Exception:
        return None
    if not result.get("valid"):
        try:
            _save_license(
                key, "free", "invalid", None, "free", "lemonsqueezy",
                instance_id=instance_id,
            )
        except OSError as exc:
            return str(exc)
        if not was_pro:
            return None
        return result.get("error") or "That license key is not valid."
    try:
        _store_online_result(key, result, instance_id)
    except OSError as exc:
        return str(exc)
    return None
